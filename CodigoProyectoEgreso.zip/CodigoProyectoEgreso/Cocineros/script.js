const iconoLogin = document.querySelector('.IconoLogin');
document.addEventListener("DOMContentLoaded", function (data) {
    fetch('../sesion/controlExistenciaUsuario.php')
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                window.location.href = "../Cliente/index/index.html"
            } else if (data.usuario.tipo === "Cocinero") {
                const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));

                //para cerrar sesion (el li creado antes 2
                cerrarSesion.addEventListener("click", function (event) {
                    event.preventDefault()
                    fetch('../Cliente/sesion/cerrarSesion.php')
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                window.location.href = "../Cliente/index/index.html"
                            } else {
                                Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                            }
                        })
                })

            }
        })
})
const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
document.addEventListener("DOMContentLoaded", function (data) {
    data.preventDefault();
    const contenedor = document.getElementById("contenedorComandas");
    contenedor.innerHTML = ``;
    const div = document.createElement("div");
    div.classList.add("comanda-hecha");
    fetch('pedidos.php')
        .then(res => res.json())
        .then(data => {
            if (data.success && Array.isArray(data.success) && data.success.length > 0) {
                data.success.forEach(element => {
                    const div = document.createElement("div"); // ← crea un div nuevo para cada pedido
                    div.classList.add("comanda-hecha");

                    div.innerHTML = `
            <p id="idPedido" name="idPedido"><strong>ID Pedido:</strong> ${element.ID_pedido}</p>
            <p id="fechaPedido" name="fechaPedido"><strong>Fecha:</strong> ${element.fechaPedido}</p>
            <p id="mesas" name="mesas"><strong>Mesa:</strong> ${element.numeroMesa ?? element.ID_mesa}</p>
            <p id="mozo" name="mozo"><strong>Mozo:</strong> ${element.nombreMozo ?? element.ID_mozo} ${element.apellidoMozo ?? ''}</p>
            <p id="plato" name="plato"><strong>Platos:</strong> ${element.platos ?? '-'}</p>
            <p id="descripcion" name="descripcion"><strong>Descripción:</strong> ${element.especificaciones ?? '—'}</p>
            <p id="puntosCompra" name="puntosCompra"><strong>Puntos Compra:</strong> ${element.puntosCompra ?? 0}</p>
            <p id="estado" name="estado"><strong>Estado:</strong> En preparación</p>
            <button class="btn-preparado">Marcar como Preparado</button>
        `;

                    contenedor.appendChild(div);
                });
            } else {
                const div = document.createElement("div");
                div.innerHTML = `<h2>No hay pedidos</h2>`;
                contenedor.appendChild(div);
            }

        })
})