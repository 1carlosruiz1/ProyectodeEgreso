const iconoLogin = document.querySelector('.IconoLogin');
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.error) {
        window.location.href = "../Cliente/index/index.html"
      } else if (data.usuario.tipo === "Cocinero") {
        const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));

        //para cerrar sesion (el li creado antes 2
        cerrarSesion.addEventListener("click", function (event) {
          event.preventDefault()
          fetch('../Cliente/sesion/cerrarSesion.php')
            .then(res => res.json())
            .then(data => {
              if (data.success) {
                window.location.href = "../Cliente/index/index.html"
              } else {
                Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
              }
            })
        })

      }else{
        window.location.href = "../Cliente/index/index.html"
      }
    })
})
const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
cargar();
  function cargar(){

    const contenedor = document.getElementById("contenedorComandas");
    contenedor.innerHTML = ``;
    const div = document.createElement("div");
    div.classList.add("comanda-hecha");
    fetch('pedidos.php')
      .then(res => res.json())
      .then(data => {

        if (data.success) {
          
          data.success.forEach(element => {
            const div = document.createElement("div");
            div.classList.add("comanda-hecha");
          
            div.innerHTML += `
        <p id="fechaPedido"><strong>Hora:</strong> ${element.horaPedido}</p>
        <p id="cliente"><strong>Cliente:</strong> ${element.cliente ?? '-'}</p>
        <p id="mozo"><strong>Mozo:</strong> ${element.nombreMozo ?? '-'}</p>
        <p id="mesas"><strong>Mesa:</strong> ${element.numeroMesa ?? '-'}</p>
        <p id="mesas"><strong>Delivery: </strong> ${element.repartidor ?? '-'}</p>
        <p id="descripcion"><strong>Descripción:</strong> ${element.especificaciones ?? '-'}</p>`
        const divPlatos = document.createElement("div");
            divPlatos.innerHTML = `
    <p><strong>Platos:</strong> ${
      element.platos.length ? element.platos.map(p => `${p.nombrePlato}(${p.cantidad ?? '1'})`).join(', ')
        : '-'
    }</p>
  `;
  div.appendChild(divPlatos);
            div.innerHTML +=`
        <button class="btn-preparado" onclick=Terminado(${element.ID_pedido})>Marcar como Preparado</button>
      `;

            contenedor.appendChild(div);
          });
        }
        else if (data.vacio) {
          const div = document.createElement("div");
          div.innerHTML = `<h2>${data.vacio}</h2>`;
          contenedor.appendChild(div);
        } else {
          const div = document.createElement("div");
          div.innerHTML = `<h3>Error: </h3>${data.error}`;
          contenedor.appendChild(div);
        }

      })

  }
  myInterval = setInterval(cargar, 30000);  

function Terminado(idPedido){
    clearInterval(myInterval); // pausa la recarga automática al hacer clic en el botón
  fetch(`pedidoListo.php?ID_pedido=${idPedido}`)
  .then(res => res.json())
  .then(data => {
    
    if(data.success){
      Swal.fire("El pedido ha sido marcado como preparado.")
      .then(() => {
           myInterval = setInterval(cargar, 30000);
        cargar();
      });
      
    } else {
      Swal.fire("Error al marcar el pedido como preparado.")
      .then(() => {
           myInterval = setInterval(cargar, 30000);
        cargar();
      });
    }
  })

}

function cargarTitulo() {
  fetch("../cargarDatos.php")
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {
        const tituloDiv = document.querySelector(".TituloP h1");
        if (tituloDiv) {
          tituloDiv.textContent = data.success.nombre;
        }
      }
    })
}
cargarTitulo()