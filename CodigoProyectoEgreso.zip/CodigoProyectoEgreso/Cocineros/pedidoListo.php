<?php
require "conexion.php";
try {
    $stmt = $con->prepare("
        UPDATE Pedido
        SET cocinado = true
        WHERE ID_pedido = ?
    ");
    $stmt->execute([$_GET['ID_pedido']]);

    echo json_encode(["success" => "Pedido marcado como preparado"]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}