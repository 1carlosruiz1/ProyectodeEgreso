<?php
include "conexion.php";
try {
    $stmt = $con->prepare("
    SELECT 
        P.ID_pedido,
        P.fechaPedido,
        P.especificaciones,
        P.fechaEsperada,
        M.numeroMesa,
        U.nombre AS nombreMozo,
        U.apellido AS apellidoMozo,
        GROUP_CONCAT(Pl.nombrePlato SEPARATOR ', ') AS platos
    FROM Pedido P
    JOIN Mesa M 
        ON P.ID_mesa = M.ID_mesa
    JOIN Empleado E 
        ON P.ID_mozo = E.ID_empleado
    JOIN Usuario U 
        ON E.ID_empleado = U.ID_usuario
    LEFT JOIN SeCompone SC 
        ON P.ID_pedido = SC.ID_pedido
    LEFT JOIN Plato Pl 
        ON SC.ID_plato = Pl.ID_plato
    GROUP BY 
        P.ID_pedido, 
        P.fechaPedido, 
        P.especificaciones, 
        P.fechaEsperada, 
        M.numeroMesa, 
        U.nombre, 
        U.apellido
");

    $stmt->execute([]);
    $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(["success" => $res]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}