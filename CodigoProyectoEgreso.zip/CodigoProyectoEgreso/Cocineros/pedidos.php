<?php
include "conexion.php";
try {
    $stmt = $con->prepare("
        SELECT * 
        FROM Pedido 
        WHERE DATE(fechaEsperada) = CURDATE()
    ");
    $stmt->execute();
    $res = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$res) {
        echo json_encode(["vacio" => "No hay pedidos para hoy"]);
        exit;
    }

    foreach ($res as &$pedido) { //El operador & hace que $pedido no sea una copia, sino una referencia directa al elemento actual dentro de $res.
        $stmtPlatos = $con->prepare("
            SELECT Pl.nombrePlato, SC.cantidad 
            FROM Plato Pl
            JOIN SeCompone SC ON Pl.ID_plato = SC.ID_plato
            WHERE SC.ID_pedido = ?
        ");

        $stmtPlatos->execute([$pedido['ID_pedido']]);
        $platos = $stmtPlatos->fetchAll(PDO::FETCH_ASSOC);
        $pedido['platos'] = $platos ?: []; // ← ahora es un array, no un string
    }
foreach ($res as &$cliente) {
    $stmtCliente = $con->prepare("
        SELECT U.nombre AS nombreCliente
        FROM Usuario U
        JOIN Pedido P ON U.ID_usuario = P.ID_cliente
        WHERE P.ID_pedido = ?
    ");
    $stmtCliente->execute([$cliente['ID_pedido']]);
    $nombre = $stmtCliente->fetch(PDO::FETCH_ASSOC);

    // Guardar el nombre del cliente (si existe)
    $cliente['cliente'] = $nombre ? $nombre['nombreCliente'] : '-';
}

    foreach ($res as &$pedido) {
    // Convertir fechaPedido a solo HH:MM para q quede ams comodo
    $pedido['horaPedido'] = date("H:i", strtotime($pedido['fechaPedido']));
}

    echo json_encode(["success" => $res]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
