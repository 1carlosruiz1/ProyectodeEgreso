<?php
require "conexion.php";
try {
    $stmt = $con->prepare("SELECT * FROM Plato ORDER BY nombrePlato ASC");
    $stmt->execute();
    $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(["success" => $res]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
