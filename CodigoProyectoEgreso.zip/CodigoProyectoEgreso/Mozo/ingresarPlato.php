<?php
require "conexion.php";
$ID_plato = $_POST["plato"];
$ID_mesa = $_POST["mesas"];
$descripcion = $_POST["descripcion"];
$email = $_POST["email"] ?? '';
$fechaPedido = date("Y-m-d H:i:s");

try {
    $stmt = $con->prepare("INSERT INTO Pedido (fechaPedido, especificaciones, ID_mesa, puntosCompra, ID_cliente, ID_mozo)");
    $stmt->execute([$fechaPedido, $descripcion, $ID_mesa,]);
    $id_pedido = $con->lastInsertId();


    $conteo = array_count_values($ID_plato);
    foreach ($conteo as $ID_PlatoUnico => $cantidad) {

        $stmt = $con->prepare("INSERT INTO SeCompone (ID_pedido, ID_plato, cantidad) VALUES (?, ?, ?)");
        $stmt->execute([$id_pedido, $ID_PlatoUnico, $cantidad]);
    }
    echo json_encode(["success" => "Pedido enviado"]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}