<?php
require "conexion.php";
$ID_plato=$_POST["plato"];
$ID_mesa=$_POST["mesas"];
$descripcion=$_POST["descripcion"];
$email=$_POST["email"] ?? '';
$fechaPedido = date("Y-m-d H:i:s");

try{
    $stmt=$con->prepare("INSERT INTO Pedido (fechaPedido, especificaciones, ID_mesa, puntosCompra, ID_cliente, ID_mozo)");
    $stmt->execute([$fechaPedido, $descripcion, $ID_mesa, ]);
    $last_id = $con->lastInsertId();
    foreach($last_id as $ID_Pedido){
        
    }
}