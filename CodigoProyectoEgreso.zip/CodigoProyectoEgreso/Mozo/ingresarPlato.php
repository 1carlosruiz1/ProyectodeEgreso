<?php
require "conexion.php";
session_start();
header('Content-Type: application/json');

$ID_mozo = $_SESSION["usuario"]["ID"];
$ID_mesa = $_POST["mesas"];
$descripcion = $_POST["descripcion"];
$email = $_POST["email"] ?? '';
$fechaPedido = date("Y-m-d H:i:s");
$platos = $_POST["platos"];
$cantidades = $_POST["cantidades"];
$totalPlatos = array_sum($_POST['cantidades']);
$puntos = $totalPlatos * 10;

if(empty($cantidades)){
echo json_encode(["cantidades"=>"Envie por lo menos 1 plato"]);
exit;
}
$id_cliente = null;
if (!empty($email)) {
    $stmt = $con->prepare("SELECT ID_usuario FROM Usuario where email=?");
    $stmt->execute([$email]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $id_cliente = $row ? $row['ID_usuario'] : null;
}
try {
    $stmt = $con->prepare("INSERT INTO Pedido (fechaPedido, especificaciones, ID_mesa, puntosCompra, ID_cliente, ID_mozo) VALUES (?,?,?,?,?,?)");
    $stmt->execute([$fechaPedido, $descripcion, $ID_mesa, $puntos, $id_cliente, $ID_mozo]);
    $id_pedido = $con->lastInsertId();

    foreach ($cantidades as $ID_PlatoUnico => $cantidad) {

        $stmt = $con->prepare("INSERT INTO SeCompone (ID_pedido, ID_plato, cantidad) VALUES (?, ?, ?)");
        $stmt->execute([$id_pedido, $ID_PlatoUnico, $cantidad]);
    }
    echo json_encode(["success" => "Pedido enviado"]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}