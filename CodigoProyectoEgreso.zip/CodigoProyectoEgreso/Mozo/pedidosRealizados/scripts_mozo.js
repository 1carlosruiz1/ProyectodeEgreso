const iconoLogin = document.querySelector('.IconoLogin');
let nombreUsuario = "";
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        if (data.usuario.tipo === "Mozo") {
          // Si está logueado 
          dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
          const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
          //para cerrar sesion (el li creado antes 2
          cerrarSesion.addEventListener("click", function (event) {
            event.preventDefault()
            fetch('../sesion/cerrarSesion.php')
              .then(res => res.json())
              .then(data => {
                if (data.success) {
                  window.location.href = "../Cliente/index/index.html"
                } else {
                  Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                }
              })
          })

        } else {
          window.location.href = "../../Cliente/index/index.html"
        }
      } else {
        window.location.href = "../../Cliente/index/index.html"
      }

    })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas

function cargarDatos() {
fetch('datos.php')
  .then(res => res.json())
  .then(data => {
    console.log(data);
    
    const listaWeb = document.getElementById("lista-web");
    const listaResto = document.getElementById("lista-resto");

    // Web
    data.pedidosWeb.forEach(p => {
      const li = document.createElement("li");
          li.classList.add('opcion');
          li.innerHTML="";
      li.innerHTML = `
        <strong>Pedido #${p.ID_pedido ?? "-"}</strong> — ${p.cliente ?? "-"}<br>
        ${p.especificaciones || '(sin detalles)'}<br>
        <em>${p.estado}</em>
      `;
      listaWeb.appendChild(li);
    });

    // Restaurante
    data.pedidosRestaurante.forEach(p => {
      const li = document.createElement("li");
      li.classList.add('opcion');
      li.innerHTML = `
        <strong>Pedido #${p.ID_pedido ?? "-"}</strong> — Mesa ${p.numeroMesa ?? "-" }<br>
        Cliente: ${p.nombreCliente}<br>
        Mozo: ${p.nombreMozo}<br>
      `;
      listaResto.appendChild(li);
    });
  });

}
cargarDatos()

function cargarTitulo() {
  fetch("../../cargarDatos.php")
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {
        const tituloDiv = document.querySelector(".TituloP h1");
        if (tituloDiv) {
          tituloDiv.textContent = data.success.nombre;
        }
      }
    })
}
cargarTitulo()