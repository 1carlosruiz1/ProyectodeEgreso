<?php
require "../conexion.php";

try {
    $stmt = $con->prepare("SELECT 
    p.ID_pedido,
    p.fechaPedido,
    p.especificaciones,
    p.puntosCompra,
    p.fechaEsperada,
    p.cocinado,
    m.numeroMesa,
    CONCAT(u.nombre, ' ', u.apellido) AS nombreMozo,
    CONCAT(cu.nombre, ' ', cu.apellido) AS nombreCliente
    FROM Pedido p
    JOIN Mesa m ON p.ID_mesa = m.ID_mesa
    JOIN Empleado e ON p.ID_mozo = e.ID_empleado
    JOIN Usuario u ON e.ID_empleado = u.ID_usuario
    JOIN Cliente c ON p.ID_cliente = c.ID_cliente
    JOIN Usuario cu ON c.ID_cliente = cu.ID_usuario
    LEFT JOIN Entrega en ON p.ID_pedido = en.ID_pedido
    WHERE p.ID_mozo IS NOT NULL AND en.ID_entrega IS NULL
    ");
    $stmt->execute();
    $pedidosRestaurante = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $con->prepare("SELECT 
    p.ID_pedido,
    p.fechaPedido,
    p.especificaciones,
    p.puntosCompra,
    p.fechaEsperada,
    p.cocinado,
    CONCAT(u.nombre, ' ', u.apellido) AS nombreCliente,
    e2.ID_entrega,
    CONCAT(u2.nombre, ' ', u2.apellido) AS delivery
    FROM Pedido p
    JOIN Cliente c ON p.ID_cliente = c.ID_cliente
    JOIN Usuario u ON c.ID_cliente = u.ID_usuario
    LEFT JOIN Entrega e2 ON p.ID_pedido = e2.ID_pedido
    LEFT JOIN Empleado em ON e2.ID_delivery = em.ID_empleado
    LEFT JOIN Usuario u2 ON em.ID_empleado = u2.ID_usuario
    LEFT JOIN Entrega en ON p.ID_pedido = en.ID_pedido
    WHERE p.ID_mozo IS NULL AND en.ID_entrega IS NULL
    ");
    $stmt->execute();
    $pedidosWeb = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "success" => true,
        "pedidosRestaurante"=>$pedidosRestaurante,
        "pedidosWeb" => $pedidosWeb
    ]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}