<?php
require "../sesion/conexion.php";
$email = $_POST['email'];
if (!$email) {
    echo json_encode(["vacio" => "El email es obligatorio."]);
    exit;
}
try {
    $stmt = $con->prepare("
    SELECT U.ID_usuario AS ID_cliente, U.nombre, U.apellido, U.email
    FROM Usuario U
    JOIN Cliente C ON U.ID_usuario = C.ID_cliente
    WHERE U.estado = 1 AND U.email = ?
");
    $stmt->execute([$email]);
    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$cliente) {
        echo json_encode(["email" => "Cliente no encontrado"]);
        exit;
    }

    // Ahora traemos las etiquetas junto con el mozo que la agregó
    $stmt = $con->prepare("
    SELECT 
        Eti.ID_etiqueta, Eti.tipo, Eti.comentario, Eti.fecha,
        E.ID_usuario, E.nombre AS nombreMozo, E.apellido AS apellidoMozo
    FROM Etiqueta Eti
    LEFT JOIN Agrega A ON Eti.ID_etiqueta = A.ID_etiqueta
    LEFT JOIN Usuario E ON A.ID_mozo = E.ID_usuario
    WHERE Eti.ID_cliente = ?
    ORDER BY Eti.fecha DESC
");
    $stmt->execute([$cliente["ID_cliente"]]);
    $etiquetas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Devolvemos todo junto en JSON
    echo json_encode([
        "success" => $cliente,
        "etiquetas" => $etiquetas
    ]);


} catch (PDOException $e) {
    echo json_encode(["error: " . $e->getMessage()]);
}