<?php
require "conexion.php";
date_default_timezone_set('America/Montevideo'); // asegúrate de usar la hora local
$horaActual = date('H:i:s');
$fechaActual = date('Y-m-d');
try {
    $stmt = $con->prepare("SELECT * FROM Mesa");
    $stmt->execute();
    $mesas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $resultado = [];

    foreach ($mesas as $mesa) {
        $ID_mesa = $mesa["ID_mesa"];

        $stmt = $con->prepare("
        SELECT 
            r.ID_reserva,
            r.horaInicio,
            r.horaFin,
            c.ID_cliente,
            u.nombre,
            u.apellido
        FROM Reserva r
        JOIN Cliente c ON r.ID_cliente = c.ID_cliente
        JOIN Usuario u ON c.ID_cliente = u.ID_usuario
        WHERE r.ID_mesa = ?
        AND r.cancelado = 0
        AND DATE(r.fechaReserva) = ?
        AND TIMESTAMP(r.fechaReserva, r.horaFin) > NOW() -- aún no terminó
        AND TIMESTAMP(r.fechaReserva, r.horaInicio) < DATE_ADD(NOW(), INTERVAL 1 HOUR) -- empieza dentro de 1h o ya empezó
        "); 
        $stmt->execute([$ID_mesa, $fechaActual]);

        $reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $resultado[] = [
            "ID_mesa" => $mesa["ID_mesa"],
            "numeroMesa" => $mesa["numeroMesa"],
            "reservas" => $reservas
        ];
    }

    echo json_encode([
        "success" => true,
        "mesas" => $resultado
    ]);

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>