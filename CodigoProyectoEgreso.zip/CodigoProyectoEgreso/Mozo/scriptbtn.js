verInfo()
function verInfo() {
    var divMesas = document.getElementById("infoMesas");
    fetch('verInfo.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                divMesas.innerHTML = "";

                data.mesas.forEach(mesa => {
                    // Crear tarjeta para cada mesa
                    let mesaHtml = `
                        <div class="reserva-card">
                            <h3>Mesa ${mesa.numeroMesa}</h3>
                    `;
                    var numMesa = document.getElementById("mesas");
                    numMesa.innerHTML += `<option value="${mesa.ID_mesa}">Mesa ${mesa.numeroMesa}</option>`;
                    if (mesa.reservas.length > 0) {
                        mesa.reservas.forEach(r => {
                            mesaHtml += `
                                <p><strong>Horario:</strong> ${r.horaInicio} - ${r.horaFin}</p>
                                <p><strong>Cliente:</strong> ${r.nombre} ${r.apellido}</p>
                                <hr>
                            `;
                        });
                    } else {
                        mesaHtml += `<p><em>Sin reservas</em></p>`;
                    }

                    mesaHtml += `</div>`;
                    divMesas.innerHTML += mesaHtml;
                });
            } else {
                Swal.fire({
                    icon: "warning",
                    title: "Error",
                    text: "Error: " + data.error,
                    confirmButtonText: 'Entendido'
                });
            }
        });
}
verPlatos()
function verPlatos() {
    fetch("verPlatos.php")
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                var platoSelect = document.getElementById("plato");
                platoSelect.innerHTML = ""; // limpiar antes de cargar
                data.success.forEach(element => {
                    platoSelect.innerHTML += `
                        <option value="${element.ID_plato}" 
                                data-nombre="${element.nombrePlato}">
                            ${element.nombrePlato}
                        </option>`;
                });
            }
        });
}
const listaPlatos = document.getElementById("lista-platos");
const formPedido = document.getElementById("formPedido");

// Agregar plato
document.querySelector(".NuevoPlato").addEventListener("click", function () {
    const platoSelect = document.getElementById("plato");
    const id = platoSelect.value;
    const nombre = platoSelect.options[platoSelect.selectedIndex].dataset.nombre;

    if (id && !document.querySelector(`input[name='platos[]'][value='${id}']`)) {
        // Crear li dentro de la lista ya existente
        const li = document.createElement("li");
        li.classList.add("plato-item");
        li.setAttribute("data-id", id);
        li.innerHTML = `
            ${nombre}
            <input type="number" 
                   name="cantidades[${id}]" 
                   class="cantidadPlato" 
                   placeholder="Cantidad" 
                   required 
                   min="1" step="1">
            <button type="button" class="btnEliminar" data-id="${id}">Quitar</button>
        `;
        listaPlatos.appendChild(li);

        // Hidden input para enviar IDs al backend
        const hidden = document.createElement("input");
        hidden.type = "hidden";
        hidden.name = "platos[]";
        hidden.value = id;
        hidden.id = `hidden-plato-${id}`;
        formPedido.appendChild(hidden);
    }
});

// Event delegation para eliminar
listaPlatos.addEventListener("click", function (e) {
    if (e.target.classList.contains("btnEliminar")) {
        const id = e.target.dataset.id;

        // Eliminar el li
        const li = listaPlatos.querySelector(`.plato-item[data-id='${id}']`);
        if (li) li.remove();

        // Eliminar el hidden
        const hidden = document.getElementById(`hidden-plato-${id}`);
        if (hidden) hidden.remove();
    }
});

// Envío del formulario
formPedido.addEventListener("submit", function (e) {
    e.preventDefault();
    const formData = new FormData(formPedido);
    fetch("ingresarPlato.php", { method: "POST", body: formData })
        .then(res => res.json())
        .then(data => {
            Swal.fire({
                icon: data.success ? "success" : "warning",
                title: data.success ? "Éxito" : "Error",
                text: data.success ? "Pedido enviado" : "Error: " + data.error,
                confirmButtonText: 'Entendido'
            });
        });
});
