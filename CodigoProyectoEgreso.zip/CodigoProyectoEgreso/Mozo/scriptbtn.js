const iconoLogin = document.querySelector('.IconoLogin');
let nombreUsuario = "";
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        if (data.usuario.tipo === "Mozo") {
          // Si está logueado 
          dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
          const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
          //para cerrar sesion (el li creado antes 2
          cerrarSesion.addEventListener("click", function (event) {
            event.preventDefault()
            fetch('../sesion/cerrarSesion.php')
              .then(res => res.json())
              .then(data => {
                if (data.success) {
                  window.location.href = "../Cliente/index/index.html"
                } else {
                  Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                }
              })
          })

        } else {
          window.location.href = "../../Cliente/index/index.html"
        }
      } else {
        window.location.href = "../../Cliente/index/index.html"
      }

    })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas
verMesa()
setInterval(verMesa, 60000)
function verMesa() {
  var divMesas = document.getElementById("infoMesas");
  fetch('verInfo.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        divMesas.innerHTML = "";

        data.mesas.forEach(mesa => {
          // Crear opción en el select
          const numMesa = document.getElementById("mesas");
          numMesa.innerHTML += `<option value="${mesa.ID_mesa}">Mesa ${mesa.numeroMesa}</option>`;

          // Estructura visual de la tarjeta
          let mesaHtml = `
    <div class="reserva-card">
      <div class="reserva-header">
        <h3>Mesa ${mesa.numeroMesa}</h3>
        <span class="estado ${mesa.reservas.length > 0 ? 'ocupada' : 'libre'}">
          ${mesa.reservas.length > 0 ? 'Reservada' : 'Libre'}
        </span>
      </div>
      <div class="reserva-body">
  `;

          if (mesa.reservas.length > 0) {
            mesa.reservas.forEach(r => {
              mesaHtml += `
        <div class="reserva-info">
          <p><strong>Horario:</strong> ${r.horaInicio} - ${r.horaFin}</p>
          <p><strong>Cliente:</strong> ${r.nombre} ${r.apellido}</p>
        </div>
      `;
            });
          } else {
            mesaHtml += `<p class="sin-reservas"><em>Sin reservas</em></p>`;
          }

          mesaHtml += `
      </div>
    </div>
  `;

          divMesas.innerHTML += mesaHtml;
        });

      } else {
        Swal.fire({
          icon: "warning",
          title: "Error",
          text: "Error: " + data.error,
          confirmButtonText: 'Entendido'
        });
      }
    });
}

verPlatos()
function verPlatos() {
  fetch("verPlatos.php")
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        var platoSelect = document.getElementById("plato");
        platoSelect.innerHTML = "";
        data.success.forEach(element => {
          platoSelect.innerHTML += `
                        <option value="${element.ID_plato}" 
                                data-nombre="${element.nombrePlato}">
                            ${element.nombrePlato}
                        </option>`;
        });
      }
    });
}
const listaPlatos = document.getElementById("lista-platos");
const formPedido = document.getElementById("formPedido");


// Agregar plato
document.querySelector(".NuevoPlato").addEventListener("click", function () {
  const platoSelect = document.getElementById("plato");
  const id = platoSelect.value;
  const nombre = platoSelect.options[platoSelect.selectedIndex].dataset.nombre;

  if (id && !document.querySelector(`input[name='platos[]'][value='${id}']`)) {
    // Crear li dentro de la lista ya existente
    const li = document.createElement("li");
    li.classList.add("plato-item");
    li.setAttribute("data-id", id);
    li.innerHTML = `
            ${nombre}
            <input type="number" 
                   name="cantidades[${id}]" 
                   class="cantidadPlato" 
                   placeholder="Cantidad" 
                   required 
                   min="1" step="1">
            <button type="button" class="btnEliminar" data-id="${id}">Quitar</button>
        `;
    listaPlatos.appendChild(li);

    // Hidden input para enviar IDs al backend
    const hidden = document.createElement("input");
    hidden.type = "hidden";
    hidden.name = "platos[]";
    hidden.value = id;
    hidden.id = `hidden-plato-${id}`;
    formPedido.appendChild(hidden);
  }
});

// Event delegation para eliminar
listaPlatos.addEventListener("click", function (e) {
  if (e.target.classList.contains("btnEliminar")) {
    const id = e.target.dataset.id;

    // Eliminar el li
    const li = listaPlatos.querySelector(`.plato-item[data-id='${id}']`);
    if (li) li.remove();

    // Eliminar el hidden
    const hidden = document.getElementById(`hidden-plato-${id}`);
    if (hidden) hidden.remove();
  }
});

formPedido.addEventListener("submit", function (e) {
  e.preventDefault();
  const platosAgregados = document.querySelectorAll("input[name='platos[]']");
  if (platosAgregados.length === 0) {
    Swal.fire({
      icon: "warning",
      title: "Atención",
      text: "Debe agregar al menos un plato antes de enviar el pedido.",
      confirmButtonText: "Entendido"
    });
    return; // Detiene el envío
  }
  Swal.fire({
    icon: "info",
    title: "Atención",
    text: "Enviar pedido?",
    confirmButtonText: 'Enviar'
  }).then((result) => {
    if (result.isConfirmed) {
      const formData = new FormData(formPedido);
      fetch("ingresarPlato.php", { method: "POST", body: formData })
        .then(res => res.text())
        .then(data => {
          console.log(data);

          if (data.success) {
            Swal.fire({
              icon: "success",
              title: "Éxito",
              text: "Pedido enviado",
              confirmButtonText: 'Entendido'
            });
          } else if (data.cantidades) {
            Swal.fire({
              icon: "info",
              title: "Atención",
              text: data.cantidades,
              confirmButtonText: 'Entendido'
            });
          } else {
            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Error: " + data.error,
              confirmButtonText: 'Entendido'
            });
          }

        })
    } else if (result.isDismissed) {
    }
  });

});


function cargarTitulo() {
  fetch("../cargarDatos.php")
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {
        const tituloDiv = document.querySelector(".TituloP h1");
        if (tituloDiv) {
          tituloDiv.textContent = data.success.nombre;
        }
      }
    })
}
cargarTitulo()