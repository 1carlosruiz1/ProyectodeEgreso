verInfo()
function verInfo() {
    var divMesas = document.getElementById("infoMesas");
    fetch('verInfo.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                divMesas.innerHTML = "";

                data.mesas.forEach(mesa => {
                    // Crear tarjeta para cada mesa
                    let mesaHtml = `
                        <div class="reserva-card">
                            <h3>Mesa ${mesa.numeroMesa}</h3>
                    `;
                    var numMesa = document.getElementById("mesas");
                    numMesa.innerHTML += `<option value="${mesa.ID_mesa}">Mesa ${mesa.numeroMesa}</option>`;
                    if (mesa.reservas.length > 0) {
                        mesa.reservas.forEach(r => {
                            mesaHtml += `
                                <p><strong>Horario:</strong> ${r.horaInicio} - ${r.horaFin}</p>
                                <p><strong>Cliente:</strong> ${r.nombre} ${r.apellido}</p>
                                <hr>
                            `;
                        });
                    } else {
                        mesaHtml += `<p><em>Sin reservas</em></p>`;
                    }

                    mesaHtml += `</div>`;
                    divMesas.innerHTML += mesaHtml;
                });
            } else {
                Swal.fire({
                    icon: "warning",
                    title: "Error",
                    text: "Error: " + data.error,
                    confirmButtonText: 'Entendido'
                });
            }
        });
}
verPlatos()
function verPlatos() {
    fetch("verPlatos.php")
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                data.success.forEach(element => {
                    var plato = document.getElementById("plato");
                    plato.innerHTML += `<option value="${element.ID_plato}">${element.nombrePlato}</option>`;
                })
            }

        })
}
document.getElementById("btnEnviar").addEventListener("submit", function (element) {
    element.preventDefault();
    const formData = new FormData(document.getElementById("formPedido"));
    fetch("ingresarPlato.php", {
        method: "POST",
        body: formData
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    icon: "success",
                    title: "Exito",
                    text: "Pedido enviado",
                    confirmButtonText: 'Entendido'
                });
            } else {
                Swal.fire({
                    icon: "warning",
                    title: "Error",
                    text: "Error: " + data.error,
                    confirmButtonText: 'Entendido'
                });
            }
        })
});