<?php
session_start();
require "conexion.php";
date_default_timezone_set('America/Montevideo');

$ID_cliente = $_POST["ID_cliente"];
$comentario = $_POST["comentario"];
$fecha = date('Y-m-d');
$tipo = $_POST["selectEtiqueta"];

if (!isset($ID_cliente) || !isset($comentario) || !isset($tipo)) {
    echo json_encode(["vacio" => "Debe completar todos los campos"]);
    exit;
}
try {
    $stmt = $con->prepare("INSERT INTO Etiqueta (ID_cliente, fecha, comentario, tipo) VALUES (?,?,?,?)");
    $stmt->execute([$ID_cliente, $fecha, $comentario, $tipo]);
    $res = $con->lastInsertId();

    $stmt=$con->prepare("INSERT into Agrega (ID_mozo, ID_etiqueta) VALUES (?,?)");
    $stmt->execute([$_SESSION["usuario"]["ID"], $res]);
    echo json_encode(["success"=>"Etiqueta agregada"]);

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
