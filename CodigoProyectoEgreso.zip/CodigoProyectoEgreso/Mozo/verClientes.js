var ID_cliente = null;
function verClientes(formData) {
    fetch("verClientes.php", {
        method: "POST",
        body: formData
    })
        .then(res => res.json())
        .then(data => {
            console.log(data);

            const clienteSelect = document.getElementById("infoCliente");
            clienteSelect.innerHTML = "";

            if (data.success) {
                ID_cliente=data.success.ID_cliente;
                const cliente = data.success;
                const clienteSelect = document.getElementById("infoCliente");

                clienteSelect.innerHTML = `
                <p>Nombre: ${cliente.nombre} ${cliente.apellido}</p>
                <p>Email: ${cliente.email}</p>
            `;

                if (data.etiquetas.length === 0) {
                    clienteSelect.innerHTML += '<p>No tiene Etiquetas</p>';
                } else {
                    clienteSelect.innerHTML += `<br><h2>Etiquetas</h2><hr>`;
                    data.etiquetas.forEach(etiqueta => {
                        clienteSelect.innerHTML += `
                <p>Tipo: ${etiqueta.tipo}</p>
                <p>Realizada el: ${etiqueta.fecha}</p>
                <p>Comentario: ${etiqueta.comentario}</p>
                <p>Realizado por: ${etiqueta.mozo_nombre || 'Sin mozo'} ${etiqueta.mozo_apellido || ''}</p>
                <hr>
            `;
                    });
                }
            } else if (data.email) {
                clienteSelect.innerHTML += `
                        <p> ${data.email} </p>
                        `;
            } else if (data.error) {
                clienteSelect.innerHTML += `
                        <p> Error: ${data.error} </p>
                        `;
            } else if (data.vacio) {
                Swal.fire({
                    icon: "info",
                    title: "Información",
                    text: "Se requiere un email para buscar al cliente.",
                    confirmButtonText: 'Entendido'
                });
            }

        });
}

function agregarEtiquetas(form) {

    fetch("agregarEtiqueta.php", {
        method: "POST",
        body: form
    })
        .then(res => res.json())
        .then(data => {
            console.log(data);

            if (data.success) {
                Swal.fire({
                    icon: "success",
                    title: "Etiqueta agregada",
                    text: "La etiqueta se agregó correctamente.",
                    confirmButtonText: 'Entendido'
                });
            } else if (data.vacio) {
                Swal.fire({
                    icon: "error",
                    title: "Error",
                    text: data.vacio,
                    confirmButtonText: 'Entendido'
                });
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Error",
                    text: data.error || "No se pudo agregar la etiqueta.",
                    confirmButtonText: 'Entendido'
                });
            }
        });
}

document.getElementById("formCliente").addEventListener("submit", function (e) {
    e.preventDefault();
    const formData = new FormData(this);
    verClientes(formData);
});

document.getElementById("formEtiquetas").addEventListener("submit", function (e) {
    e.preventDefault();
    var formData = new FormData(this);
    if (!ID_cliente) {
        Swal.fire({
            icon: "warning",
            title: "Error",
            text: "Busque un cliente antes de agregarle una etiqueta",
            confirmButtonText: 'Entendido'
        })
        return
    }
    formData.append("ID_cliente", ID_cliente);
    agregarEtiquetas(formData);
})