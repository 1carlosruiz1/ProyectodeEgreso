const iconoLogin = document.querySelector('.IconoLogin');
let nombreUsuario = "";
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        if (data.usuario.tipo === "Mozo") {
          // Si está logueado 
          dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
          const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
          //para cerrar sesion (el li creado antes 2
          cerrarSesion.addEventListener("click", function (event) {
            event.preventDefault()
            fetch('../sesion/cerrarSesion.php')
              .then(res => res.json())
              .then(data => {
                if (data.success) {
                  window.location.href = "../Cliente/index/index.html"
                } else {
                  Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                }
              })
          })

        } else {
          window.location.href = "../../Cliente/index/index.html"
        }

      } else {
        window.location.href = "../../Cliente/index/index.html"
      }
    })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas


var ID_cliente = null;
function verClientes(formData) {
  fetch("verClientes.php", {
    method: "POST",
    body: formData
  })
    .then(res => res.json())
    .then(data => {
      console.log(data);

      const clienteSelect = document.getElementById("infoCliente");
      clienteSelect.innerHTML = "";

      if (data.success) {
        ID_cliente = data.success.ID_cliente;
        const cliente = data.success;
        const clienteSelect = document.getElementById("infoCliente");

        clienteSelect.innerHTML = `
                <p>Nombre: ${cliente.nombre} ${cliente.apellido}</p>
                <p>Email: ${cliente.email}</p>
            `;

        if (data.etiquetas.length === 0) {
          clienteSelect.innerHTML += '<p>No tiene Etiquetas</p>';
        } else {
          clienteSelect.innerHTML += `<br><h2>Etiquetas</h2><hr>`;
          data.etiquetas.forEach(etiqueta => {
            clienteSelect.innerHTML += `
                <p>Tipo: ${etiqueta.tipo}</p>
                <p>Realizada el: ${etiqueta.fecha}</p>
                <p>Comentario: ${etiqueta.comentario}</p>
                <p>Realizado por: ${etiqueta.mozo_nombre || 'Sin mozo'} ${etiqueta.mozo_apellido || ''}</p>
                <hr>
            `;
          });
        }
      } else if (data.email) {
        clienteSelect.innerHTML += `
                        <p> ${data.email} </p>
                        `;
      } else if (data.error) {
        clienteSelect.innerHTML += `
                        <p> Error: ${data.error} </p>
                        `;
      } else if (data.vacio) {
        Swal.fire({
          icon: "info",
          title: "Información",
          text: "Se requiere un email para buscar al cliente.",
          confirmButtonText: 'Entendido'
        });
      }

    });
}

function agregarEtiquetas(form) {

  fetch("agregarEtiqueta.php", {
    method: "POST",
    body: form
  })
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {
        Swal.fire({
          icon: "success",
          title: "Etiqueta agregada",
          text: "La etiqueta se agregó correctamente.",
          confirmButtonText: 'Entendido'
        });
      } else if (data.vacio) {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: data.vacio,
          confirmButtonText: 'Entendido'
        });
      } else {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: data.error || "No se pudo agregar la etiqueta.",
          confirmButtonText: 'Entendido'
        });
      }
    });
}

document.getElementById("formCliente").addEventListener("submit", function (e) {
  e.preventDefault();
  const formData = new FormData(this);
  verClientes(formData);
});

document.getElementById("formEtiquetas").addEventListener("submit", function (e) {
  e.preventDefault();
  var formData = new FormData(this);
  if (!ID_cliente) {
    Swal.fire({
      icon: "warning",
      title: "Error",
      text: "Busque un cliente antes de agregarle una etiqueta",
      confirmButtonText: 'Entendido'
    })
    return
  }
  formData.append("ID_cliente", ID_cliente);
  agregarEtiquetas(formData);
})

function cargarTitulo() {
  fetch("../cargarDatos.php")
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {
        const tituloDiv = document.querySelector(".TituloP h1");
        if (tituloDiv) {
          tituloDiv.textContent = data.success.nombre;
        }
      }
    })
}
cargarTitulo()