<?php
header('Content-Type: application/json');
require 'sesion/conexion.php'; 

try {
    // Traemos los datos del restaurante (ID_restaurante = 1)
    $stmt = $con->prepare("SELECT nombre, historia, horarios, mision, vision, valores, telefono FROM Restaurante WHERE ID_restaurante = 1");
    $stmt->execute();
    $restaurante = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($restaurante) {
        echo json_encode(['success' => $restaurante]);
    } else {
        echo json_encode(['vacio' => 'No se encontró el restaurante.']);
    }

} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
