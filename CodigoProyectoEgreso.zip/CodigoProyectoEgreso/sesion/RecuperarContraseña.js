const formRecuperar=document.getElementById("formRecuperar");

document.getElementById("iconoLogin").addEventListener("click",function(event){
window.location.href="login.html";
})

formRecuperar.addEventListener("submit", function(event){
  event.preventDefault();
  var formData=new FormData(formRecuperar);
  Swal.fire({
    title: 'Enviando...',
    text: 'Estamos enviando el correo de recuperación',
    allowOutsideClick: false,
    allowEscapeKey: false,
    didOpen: () => {
      Swal.showLoading(); 
    }
  });
  fetch('recuperarContraseña.php', {
      method:'POST',
      body: formData
  })

  .then(res=> res.json())
  .then(data => {
    console.log(data  );
    
    if(data.success){
       Swal.fire({
        icon: 'success',
        title: 'Email Enviado',
        text: 'Código de recuperación enviado a su Email',
        confirmButtonText: 'Entendido'
      }).then(() => {
        Swal.fire({
        icon: 'success',
        title: 'Cuenta',
        text: 'Se serrará su sesión actual, cambie la contraseña y vuelva a ingresar',
        confirmButtonText: 'Entendido'
      }).then(() => {
        fetch("../Cliente/sesion/cerrarSesion.php");
        window.location.href = "../Cliente/index/index.html";
      });
      });
    }else if(data.email){
      Swal.fire({
            icon: 'warning',
            title: 'Error: ',
            text: 'El email presentado no está registrado',
            confirmButtonText: 'Entendido'
          });

    }else{
      Swal.fire({
            icon: 'warning',
            title: 'Error: ',
            text: data.error,
            confirmButtonText: 'Entendido'
          });
    }
  })
})

function cargarTitulo(){
  fetch("../cargarDatos.php")
  .then(res => res.json())
  .then(data => {
    console.log(data);
    
    if (data.success) {
      const tituloDiv = document.querySelector(".TituloP h1");
      if (tituloDiv) {
        tituloDiv.textContent = data.success.nombre;
      }
              const telefono = document.querySelector(".footer-phone-number");
        if (telefono) { telefono.textContent = data.success.telefono; }
        
    }
  })
}
cargarTitulo()