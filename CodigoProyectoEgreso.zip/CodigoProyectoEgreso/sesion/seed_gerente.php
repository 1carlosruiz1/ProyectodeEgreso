<?php
// seed_gerente.php — ejecutalo una sola vez desde tu entorno (o desde un script de "seed")
require "conexion.php"; // debe definir $con (PDO)

$nombre = "Gerente";
$apellido = "";
$email = "gerente@gmail.com";
$passwordClaro = "1234qwer"; // cambiar en producción

try {
    // 1) Hash en PHP
    $hash = password_hash($passwordClaro, PASSWORD_DEFAULT);

    // 2) Insertar en Usuario
    $sql = "INSERT INTO Usuario (nombre, apellido, email, contraseña) VALUES (?, ?, ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->execute([$nombre, $apellido, $email, $hash]);
    $idUsuario = $con->lastInsertId();

    // 3) Insertar en Empleado usando el ID del usuario
    $sql2 = "INSERT INTO Empleado (ID_empleado, tipo) VALUES (?, ?)";
    $stmt2 = $con->prepare($sql2);
    $stmt2->execute([$idUsuario, 'Gerente']);

    echo "Gerente creado. ID: $idUsuario\n";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}