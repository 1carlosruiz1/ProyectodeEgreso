<?php
// seed_empleados.php
require "conexion.php"; // debe definir $con (PDO)

$empleados = [
    ['nombre' => 'Gerente', 'apellido' => '', 'email' => 'gerente@gmail.com', 'tipo' => 'Gerente'],
    ['nombre' => 'Mozo', 'apellido' => '', 'email' => 'mozo@gmail.com', 'tipo' => 'Mozo'],
    ['nombre' => 'Cocinero', 'apellido' => '', 'email' => 'cocinero@gmail.com', 'tipo' => 'Cocinero'],
    ['nombre' => 'ChefEjecutiva', 'apellido' => '', 'email' => 'chefejecutiva@gmail.com', 'tipo' => 'ChefEjecutiva'],
    ['nombre' => 'Delivery', 'apellido' => '', 'email' => 'delivery@gmail.com', 'tipo' => 'Delivery'],
];

$passwordClaro = "1";

try {
    foreach ($empleados as $e) {
        // 1) Hashear contraseña
        $hash = password_hash($passwordClaro, PASSWORD_DEFAULT);

        // 2) Insertar en Usuario
        $sql = "INSERT INTO Usuario (nombre, apellido, email, contraseña) VALUES (?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->execute([$e['nombre'], $e['apellido'], $e['email'], $hash]);
        $idUsuario = $con->lastInsertId();

        // 3) Insertar en Empleado
        $sql2 = "INSERT INTO Empleado (ID_empleado, tipo) VALUES (?, ?)";
        $stmt2 = $con->prepare($sql2);
        $stmt2->execute([$idUsuario, $e['tipo']]);

        echo "Empleado {$e['tipo']} creado (ID usuario: $idUsuario, email: {$e['email']})<br>";
    }
} catch (PDOException $ex) {
    echo "Error: " . $ex->getMessage();
}
