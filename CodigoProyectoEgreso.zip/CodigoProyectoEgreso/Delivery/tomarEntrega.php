<?php
require "conexion.php";
session_start();
$ID_entrega = $_GET['ID_entrega'];
$ID_delivery = $_SESSION['ID_delivery'];

try {
$sql = "UPDATE entregas SET ID_delivery = ? WHERE ID_entrega = ?";
$stmt = $con->prepare($sql);
$stmt->execute([$ID_delivery, $ID_entrega]);
echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error al tomar la entrega: ' . $e->getMessage()]);
}