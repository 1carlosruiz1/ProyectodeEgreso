function cargarDatos() {
    fetch('verDatos.php')
        .then(response => response.json())
        .then(data => {
            const tbody = document.querySelector('#tablaDatos tbody');
            tbody.innerHTML = '';

            if (!data.success || data.success.length === 0) {
                const fila = document.createElement('tr');
                fila.innerHTML = `<td colspan="7" style="text-align:center;">No hay pedidos cocinados</td>`;
                tbody.appendChild(fila);
                return;
            }

            data.success.forEach(pedido => {
                const fila = document.createElement('tr');

                fila.innerHTML = `
          <td>${pedido.ID_pedido}</td>
          <td>${pedido.fechaEsperada}</td>
          <td>${pedido.nombreCliente} ${pedido.apellidoCliente}</td>
          <td>${pedido.nombreDelivery} ${pedido.apellidoDelivery}</td>
          <td>${pedido.telefono ?? '-'}</td>
          <td>
            <button onclick="mostrarMapa(${pedido.latitud}, ${pedido.longitud})">
                Ver mapa
            </button>
            </td>
          <td>
            <button class="btn-entregado" onclick="marcarEntregado(${pedido.ID_pedido})">
              Marcar como entregado
            </button>
          </td>
        `;

                tbody.appendChild(fila);
            });
        })
        .catch(error => {
            console.error('Error al cargar los datos:', error);
        });
}

function marcarEntregado(id) {
    Swal.fire({
        title: '¿Marcar como entregado?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, marcar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch(`marcarEntregado.php?ID_pedido=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire('¡Listo!', 'El pedido ha sido marcado como entregado.', 'success');
                        cargarDatos();
                    } else {
                        Swal.fire('Error', 'No se pudo marcar el pedido como entregado.'+ data.error);
                    }
                })
        }
    });
        }
        cargarDatos();


        function mostrarMapa(lat, lng) {
            const modal = document.getElementById('mapaModal');
            modal.style.display = 'block';

            // limpiar mapa anterior si lo hubiera
            document.getElementById('mapa').innerHTML = '';

            const mapa = L.map('mapa').setView([lat, lng], 15);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19
            }).addTo(mapa);

            L.marker([lat, lng]).addTo(mapa)
                .bindPopup('Ubicación de entrega')
                .openPopup();
        }

        function cerrarMapa() {
            document.getElementById('mapaModal').style.display = 'none';
        }