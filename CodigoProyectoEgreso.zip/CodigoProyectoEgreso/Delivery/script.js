const iconoLogin = document.querySelector('.IconoLogin');
document.addEventListener("DOMContentLoaded", function (data) {
    fetch('../sesion/controlExistenciaUsuario.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (data.usuario.tipo === "Delivery") {
                    // Si está logueado 
                    dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
                    const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
                    //para cerrar sesion (el li creado antes 2
                    cerrarSesion.addEventListener("click", function (event) {
                        event.preventDefault()
                        fetch('../Cliente/sesion/cerrarSesion.php')
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    window.location.href = "../Cliente/index/index.html"
                                } else {
                                    Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                                }
                            })
                    })
                } else {
                    window.location.href = "../Cliente/index/index.html"
                }
            } else {
                window.location.href = "../Cliente/index/index.html"
            }
        })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
    clearTimeout(hideTimeout);
    dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
    hideTimeout = setTimeout(() => {
        dropdown.style.display = 'none';
    }, 120);
});

dropdown.addEventListener('mouseenter', () => {
    clearTimeout(hideTimeout);
    dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
    dropdown.style.display = 'none';
});

function crearOpcion(texto) {
    const li = document.createElement('li');
    li.textContent = texto;
    li.classList.add('dropdown-opcion');

    li.addEventListener('mouseenter', () => {
        li.classList.add('dropdown-opcion-hover');
    });

    li.addEventListener('mouseleave', () => {
        li.classList.remove('dropdown-opcion-hover');
    });

    return li;
}
// //hasta acá lo q va en todas las paginas

var divProncipal = document.getElementById('general');
function pedidosAceptados() {
    fetch('verDatos.php')
        .then(response => response.json())
        .then(data => {
            var tablaDatos = document.createElement('table');
            if (data.success.length === 0) {
                tablaDatos.innerHTML = `<h2>No tiene pedidos</h2>`;
                divProncipal.appendChild(tablaDatos);
                return;
            }

            data.success.forEach(pedido => {

                tablaDatos.innerHTML = `
          <td>${pedido.ID_pedido}</td>
          <td>${pedido.fechaEsperada}</td>
          <td>${pedido.nombreCliente} ${pedido.apellidoCliente}</td>
          <td>${pedido.nombreDelivery} ${pedido.apellidoDelivery}</td>
          <td>${pedido.telefono ?? '-'}</td>
          <td>
            <button onclick="mostrarMapa(${pedido.latitud}, ${pedido.longitud})">
                Ver mapa
            </button>
            </td>
          <td>
            <button class="btn-entregado" onclick="marcarEntregado(${pedido.ID_pedido})">
              Marcar como entregado
            </button>
          </td>
        `;

                divProncipal.appendChild(tablaDatos);
            });
        })
}
pedidosAceptados();

function cargarDatos() {
    fetch('todosLosDatos.php')
        .then(response => response.json())
        .then(data => {
            
            var tablaDatos = document.createElement('table');
            if (data.success.length === 0) {
                tablaDatos.innerHTML = `<h3>No hay más pedidos</h3>`;
                divProncipal.appendChild(tablaDatos);
                return;
            }

            data.success.forEach(pedido => {
                tablaDatos.innerHTML = `
                <h2>Pedidos disponibles</h2>
          <td>${pedido.fechaEsperada}</td>
          <td>${pedido.telefono ?? '-'}</td>
          <td>
          <p>Ubiciación</p>
            <button onclick="mostrarMapa(${pedido.latitud}, ${pedido.longitud})">
                Ver mapa
            </button>
            </td>
          <td>
            <button class="btn-entregado" onclick="tomarEntrega(${pedido.ID_entrega})">
              Tomar entrega
            </button>
          </td>
        `;

                divProncipal.appendChild(tablaDatos);
            });
        })
}
cargarDatos();
function marcarEntregado(id) {
    Swal.fire({
        title: '¿Marcar como entregado?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, marcar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch(`marcarEntregado.php?ID_pedido=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire('¡Listo!', 'El pedido ha sido marcado como entregado.', 'success');
                        pedidosAceptados();
                    } else {
                        Swal.fire('Error', 'No se pudo marcar el pedido como entregado.' + data.error);
                    }
                })
        }
    });
}



function mostrarMapa(lat, lng) {
    const modal = document.getElementById('mapaModal');
    modal.style.display = 'block';

    // limpiar mapa anterior si lo hubiera
    document.getElementById('mapa').innerHTML = '';

    const mapa = L.map('mapa').setView([lat, lng], 15);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19
    }).addTo(mapa);

    L.marker([lat, lng]).addTo(mapa)
        .bindPopup('Ubicación de entrega')
        .openPopup();
}

function cerrarMapa() {
    document.getElementById('mapaModal').style.display = 'none';
}

function tomarEntrega(idEntrega) {
    Swal.fire({
        title: '¿Tomar esta entrega?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, tomar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch(`tomarEntrega.php?ID_entrega=${idEntrega}`)
                .then(response => response.text())
                .then(data => {
                    
                    if (data.success) {
                        Swal.fire('¡Listo!', 'Has tomado la entrega.', 'success');
                        cargarDatos();
                        pedidosAceptados();
                    } else {
                        Swal.fire('Error', 'No se pudo tomar la entrega.' + data.error);
                    }
                })
        }
    });
}

function cargarTitulo() {
  fetch("../cargarDatos.php")
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {
        const tituloDiv = document.querySelector(".TituloP h1");
        if (tituloDiv) {
          tituloDiv.textContent = data.success.nombre;
        }
      }
    })
}
cargarTitulo()