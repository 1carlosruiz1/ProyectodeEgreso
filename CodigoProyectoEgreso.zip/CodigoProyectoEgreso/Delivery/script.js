function cargarDatos() {
    fetch('verDatos.php')
        .then(response => response.json())
        .then(data => {
            const tabla = document.createElement('tablaDatos');
            tabla.innerHTML = '';
            data.forEach(item => {
                const fila = document.createElement('tr');
                fila.innerHTML = `
                    <td><p>Usuario</p>${item.ubicacionUsuario}</td>
                    <td><p>Ubicación</p>${item.ubicacionUsuario}</td>
                    button class="btn btn-primary" onclick="Entregado(${item.id})">Confirmar entrega</button>
                `;
                tabla.appendChild(fila);
            });
            document.getElementById('tablaDatos').innerHTML = tabla.innerHTML;
        })
        .catch(error => console.error('Error al cargar los datos:', error));
}