<?php
require "conexion.php";

try{
    $stmt = $con->prepare("
  SELECT * FROM Entrega
  WHERE ID_delivery IS NULL");
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(["success" => $result]);
}catch(PDOException $e){
    echo json_encode(["error" => $e->getMessage()]);
}