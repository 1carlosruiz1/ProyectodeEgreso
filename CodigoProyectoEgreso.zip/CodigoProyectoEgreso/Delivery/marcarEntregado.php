<?php
include "conexion.php";
$id_pedido = $_GET['ID_pedido'];
try {
    $sql = "UPDATE Entrega SET confirmacionDelivery = true WHERE ID_pedido = ?";
    $stmt = $con->prepare($sql);
    $stmt->execute([$id_pedido]);
    echo json_encode(["success" => true]);
} catch (PDOException $e) {
    echo json_encode(["Error: " . $e->getMessage()]);
}