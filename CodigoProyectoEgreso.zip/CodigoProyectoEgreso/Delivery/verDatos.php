<?php
include "conexion.php";
try {
    $stmt = $conn->prepare("SELECT * FROM Entrega");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode(["success" => $result]);

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}