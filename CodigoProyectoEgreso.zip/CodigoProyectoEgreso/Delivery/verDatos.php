<?php
include "conexion.php";
try {
    $stmt = $con->prepare("
  SELECT 
    P.ID_pedido,
    P.fechaEsperada,
    CUser.nombre AS nombreCliente,
    CUser.apellido AS apellidoCliente,
    DUser.nombre AS nombreDelivery,
    DUser.apellido AS apellidoDelivery,
    E.latitud,
    E.longitud,
    E.telefono,
    E.confirmacionDelivery,
    E.confirmacionCliente
  FROM Entrega E
  INNER JOIN Pedido P ON E.ID_pedido = P.ID_pedido
  LEFT JOIN Cliente C ON P.ID_cliente = C.ID_cliente
  LEFT JOIN Usuario CUser ON C.ID_cliente = CUser.ID_usuario
  LEFT JOIN Empleado D ON E.ID_delivery = D.ID_empleado
  LEFT JOIN Usuario DUser ON D.ID_empleado = DUser.ID_usuario
  WHERE P.cocinado = 1 AND E.confirmacionDelivery = 0 AND E.confirmacionCliente = 0
");



    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(["success" => $result]);

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}