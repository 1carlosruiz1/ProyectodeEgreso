const iconoLogin = document.querySelector('.IconoLogin');
const iconoCarrito = document.getElementById('iconoCarrito');
//logue automatico 
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        let tipo = data.usuario.tipo;
        if (tipo === "Gerente") {
          window.location.href = "../../Gerente/Administracion/Administracion.html";
        } else if (tipo === "ChefEjecutiva") {
          window.location.href = "../../ChefEjecutiva/edicionPlatos/edicionPlatos.html";
        } else if (tipo === "Cocinero") {
          window.location.href = "../../Cocineros/kdscocinero.html";
        } else if (tipo === "Delivery") {
          window.location.href = "../../Delivery/index.html";
        } else if (tipo === "Mozo") {
          window.location.href = "../../Mozo/kds.html";
        }
        // Si está logueado
        dropdown.appendChild(crearOpcion(`Bienvenido, ${data.usuario.nombre}`));
        const misReservas = dropdown.appendChild(crearOpcion("Mis Reservas"));
        const favoritos = dropdown.appendChild(crearOpcion("Favoritos"));
        const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
        const historialCompras = dropdown.appendChild(crearOpcion("Historial "));

        historialCompras.addEventListener("click", function (event) {
          window.location.href = "/CodigoProyectoEgreso/Cliente/historial/historial.html"
        })
        //para cerrar sesion (usando el boton creade en el logueo)

        cerrarSesion.addEventListener("click", function (event) {
          event.preventDefault()
          fetch('../sesion/cerrarSesion.php')
            .then(res => res.json())
            .then(data => {
              if (data.success) {
                window.location.href = "index.html"
              } else {
                Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
              }
            })
        })

        //para ver las reservas (usando el boton creade en el logueo)
        misReservas.addEventListener("click", function (event) {
          window.location.href = "../SistemaDeReservas/MisReservas.html"
        })
      } else {
Swal.fire({
  title: '¡Bienvenido a nuestro restaurante!',
  html: `
    <p>Para acceder a todas nuestras funciones —realizar pedidos, ver el menú completo y acumular puntos— 
    primero debes iniciar sesión.</p>
  `,
  icon: 'info',
  confirmButtonText: 'Iniciar sesión',
  confirmButtonColor: '#3085d6',
  background: '#fffdf8',
  color: '#333',
  showClass: {
    popup: 'animate__animated animate__fadeInDown'
  },
  hideClass: {
    popup: 'animate__animated animate__fadeOutUp'
  }
}).then((result) => {
  if (result.isConfirmed) {
    window.location.href = "../../sesion/login.html";
  }
});

        // No logueado

        dropdown.appendChild(crearOpcion("Iniciar sesión"));

        ['Perfil', 'Mis Reservas', 'Favoritos'].forEach(opcion => {
          const li = document.createElement('li');
          li.textContent = opcion;
          li.classList.add('dropdown-opcion');
          li.addEventListener('mouseenter', () => {
            li.classList.add('dropdown-opcion-hover');
          });
          li.addEventListener('mouseleave', () => {
            li.classList.remove('dropdown-opcion-hover');
          });
          dropdown.appendChild(li);
        });

        // Para el dropdown:
        dropdown.classList.add('dropdown-menu');
      } //fin del else q es por si no hay usuario registrado
    })
})

//para q solo te mande al loguin si no estas logueado el logo
iconoLogin.addEventListener("click", async e => { //el async y await es como decir: espera a que temrine la operacion 
  e.preventDefault();
  const res = await fetch("../sesion/controlExistenciaUsuario.php");
  const { success } = await res.json();
  if (!success) {
    location.href = "../../sesion/login.html"

  } else {
    location.href = "../perfil/perfil.html"
  }
});
//para q solo te mande al loguin si no estas logueado el carrito!!
iconoCarrito.addEventListener("click", async e => {
  e.preventDefault();
  const res = await fetch("../sesion/controlExistenciaUsuario.php");
  const { success } = await res.json();
  if (success) location.href = "../carrito/carrito.html";
});


const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

iconoLogin.style.position = 'relative';
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}

verComentarios()
function verComentarios() {
  fetch('selectComentarios.php')
    .then(res => res.json())
    .then(data => {
      const divComentario = document.getElementById("divComentario");
      divComentario.innerHTML = "";

      if (data.success) {
        data.success.forEach(element => {
          divComentario.innerHTML += `
            <div class="comentario-item">
              <div class="comentario-header">
                <span class="puntaje">${element.puntaje}/10</span>
                <span class="usuario-fecha">${element.nombreUsuario} - ${element.fechaComentario}</span>
              </div>
              <p class="comentario-texto">${element.infoComentario}</p>
            </div>
          `;
        });
      } else if (data.vacio) {
        divComentario.innerHTML += `
          <div class="comentario-item">
            <h1>${data.vacio}</h1>
          </div>
        `;
      } else {
        divComentario.innerHTML += `
          <div class="comentario-item">
            <h1>${data.error}</h1>
          </div>
        `;
      }
    })
}


document.getElementById("insertComentario").addEventListener("submit", function (e) {
  e.preventDefault();

  const formData = new FormData(document.getElementById("insertComentario"))
  fetch("insertComentario.php", {
    method: "POST",
    body: formData
  })
    .then(res => res.json())
    .then(data => {
      if (data.vacio) {
        Swal.fire({
          icon: "warning",
          title: "Error",
          text: data.vacio,
          confirmButtonText: 'Entendido'
        })
      } else if(data.puntaje){
        Swal.fire({
          icon: "warning",
          title: "Error",
          text: data.puntaje,
          confirmButtonText: 'Entendido'
        })
        
      }else if(data.maximo){
        Swal.fire({
          icon: "warning",
          title: "Error",
          text: data.maximo,
          confirmButtonText: 'Entendido'
        })
        
      }else if (data.success) {
        Swal.fire({
          icon: "success",
          title: "exito",
          text: "Comentario subido exitosamente",
          confirmButtonText: 'Entendido'
        })
          .then(() => {
            verComentarios()
          })

      } else if (data.error) {
        Swal.fire({
          icon: "error",
          title: "error",
          text: "Hubo un problema: " + data.error,
          confirmButtonText: 'Entendido'
        })
      }
    })
})