<?php
require "../sesion/conexion.php";
session_start();

$infoComentario = $_POST["info"];
$puntaje = $_POST["puntaje"];
if (empty($infoComentario) || empty($puntaje)) {
    echo json_encode(["vacio" => "Ambos campos deben estar llenos"]);
    exit;
}

// Limitar puntaje a máximo 10
$puntaje = min($puntaje, 10);
$fechaComentario = date("Y-m-d");

try {
    $stmt = $con->prepare("
        INSERT INTO Comentario (ID_cliente, infoComentario, puntaje, fechaComentario)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$_SESSION['usuario']['ID'], $infoComentario, $puntaje, $fechaComentario]);
    
    echo json_encode(["success" => true]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
