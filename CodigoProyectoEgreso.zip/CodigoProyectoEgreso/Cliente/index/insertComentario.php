<?php
require "../sesion/conexion.php";
session_start();
$infoComentario = $_POST["info"];
$puntaje = $_POST["puntaje"];

if (empty($infoComentario) || empty($puntaje)) {
    echo json_encode(["vacio" => "Ambos campos deben de estar llenos"]);
    exit;
}
try {
    $stmt = $con->prepare("INSERT INTO Comentario (ID_cliente, infoComentario, puntaje) VALUES (?,?,?)");
    $stmt->execute([$_SESSION['usuario']['ID'], $infoComentario, $puntaje]);
    echo json_encode(["success" => true]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}