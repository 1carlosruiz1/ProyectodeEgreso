<?php
require "../sesion/conexion.php";
session_start();

if(!isset($_SESSION["usuario"])){
    echo json_encode(["session"=>"Debe iniciar sesion para hacer comentarios"]);
    exit;
}
$infoComentario = $_POST["info"];
$puntaje = $_POST["puntaje"];
if (empty($infoComentario) || empty($puntaje)) {
    echo json_encode(["vacio" => "Ambos campos deben estar llenos"]);
    exit;
}
if($puntaje<1 || $puntaje>10){
    echo json_encode(["puntaje"=>"puntaje inválido"]);
    exit;
}

// Limitar puntaje a máximo 10
$puntaje = min($puntaje, 10);
$fechaComentario = date("Y-m-d");

try {
    $stmt=$con->prepare("SELECT * FROM Comentario WHERE ID_cliente = ?");
    $stmt->execute([$_SESSION["usuario"]["ID"]]);
    if($stmt->rowCount()> 19){
        echo json_encode(["maximo"=> "No puede comentar mas de 20 veces"]);
    exit;
    }
    $stmt = $con->prepare("
        INSERT INTO Comentario (ID_cliente, infoComentario, puntaje, fechaComentario)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$_SESSION['usuario']['ID'], $infoComentario, $puntaje, $fechaComentario]);
    
    echo json_encode(["success" => true]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
