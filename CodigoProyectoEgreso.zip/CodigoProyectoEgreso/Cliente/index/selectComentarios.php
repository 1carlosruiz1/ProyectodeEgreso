<?php
require "../sesion/conexion.php";
try {
    $stmt = $con->prepare("SELECT * FROM Comentario");
    $stmt->execute();
    $res = $stmt->fetchAll();
    if ($res) {
        echo json_encode(["success" => $res]);
    } else {
        echo json_encode(["vacio" => "No hay comentarios todavía :("]);
    }

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
