<?php
require "../sesion/conexion.php";

try {
    $stmt = $con->prepare("
                SELECT 
            c.puntaje,  
            c.infoComentario, 
            c.fechaComentario, 
            u.nombre AS nombreUsuario
        FROM Comentario c
        JOIN Cliente cl ON c.ID_cliente = cl.ID_cliente
        JOIN Usuario u ON cl.ID_cliente = u.ID_usuario
        ORDER BY c.fechaComentario DESC
    ");
    $stmt->execute();
    $comentarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($comentarios && count($comentarios) > 0) {
        echo json_encode(["success" => $comentarios]);
    } else {
        echo json_encode(["vacio" => "No hay comentarios todavía :("]);
    }

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
