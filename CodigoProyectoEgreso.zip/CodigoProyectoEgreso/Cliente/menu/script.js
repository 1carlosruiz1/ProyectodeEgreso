const iconoLogin = document.querySelector('.IconoLogin');
let nombreUsuario = "";
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
                  if (data.success) {
                if (data.usuario.tipo == "Cliente") {
                    // Si está logueado
                    dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
                    const misReservas = dropdown.appendChild(crearOpcion("Mis Reservas"));
                    const favoritos = dropdown.appendChild(crearOpcion("Favoritos"));
                    const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
                    const historialCompras = dropdown.appendChild(crearOpcion("Historial "));

                    historialCompras.addEventListener("click", function (event) {
                        window.location.href = "/CodigoProyectoEgreso/Cliente/historial/historial.html"
                    })
                    //para cerrar sesion (usando el boton creade en el logueo)

                    cerrarSesion.addEventListener("click", function (event) {
                        event.preventDefault()
                        fetch('../sesion/cerrarSesion.php')
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    window.location.href = "../index/index.html"
                                } else {
                                    Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                                }
                            })
                    })
                    //para ver las reservas (usando el boton creade en el logueo)
                    misReservas.addEventListener("click", function (event) {
                        window.location.href = "MisReservas.html"
                    })
                } else {
                }
            } else {
            }
    })
})
document.getElementById("iconoCarrito").addEventListener("click", async e => { //el async y await es como decir: espera a que temrine la operacion 
  e.preventDefault();
  const res = await fetch("../../sesion/controlExistenciaUsuario.php");
  const { success } = await res.json();
  if (success) location.href = "../carrito/carrito.html";
});

document.getElementById("iconoLogin").addEventListener("click", async e => { //el async y await es como decir: espera a que temrine la operacion 
  e.preventDefault();
  const res = await fetch("../../sesion/controlExistenciaUsuario.php");
  const { success } = await res.json();
  if (!success) {
    location.href = "../../sesion/login.html"

  } else {
    location.href = "../perfil/perfil.html"
  }
});

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas
cargarMenu()
var card = document.getElementById("menu-container"); //div del html
function cargarMenu() {
  fetch('datos.php')
    .then(res => res.json())
    .then(data => {

      if (data.vacio) {
        card.innerHTML = `<h1>No hay platos disponibles en este momento</h1>`;
      } else if (data.success) {
        card.innerHTML='';
        data.platos.forEach(element => {
          const precioFinal = element.precio - (element.precio * element.promocion / 100);

          // Verificamos si hay promoción
          const promoTexto = precioFinal < element.precio
            ? `<p class='promo-texto'>🔥 PROMOCIÓN - ${element.promocion}% OFF</p>`
            : "";

          // el : de arriba es como un "si no" tipo else, se llama operador ternario
          card.innerHTML += `
    <div class="menu-card">
      <h2 class='menu-card-title'>${element.nombrePlato}</h2>
      <img src="../../IMG/fotosPlatos/${element.ID_plato}.png" alt='fotoPlato'>
      <div class="menu-card-content">
        ${promoTexto}
        <p class='menu-card-price'>Precio: $${precioFinal.toFixed(2)}</p>
        <p class='tiempo-preparacion'>Preparación: ${element.tiempoPreparacion} minutos</p>
        <a href="menuGrande.html?id=${element.ID_plato}">
          <button class="menu-card-btn">Ver más</button>
        </a>
        <button class="menu-card-btn" onclick="agregarAlCarrito(${element.ID_plato})">Agregar al carrito</button>
        <button onclick="favoritos(${element.ID_plato})" class="menu-card-btn">Agregar a fav</button>
      </div>
    </div>
  `;
        });

      } else {
        card.innerHTML = `<h1>Error: ${data.error}</h1>`;
      }
    });
}


function agregarAlCarrito(idPlato) {
  if (nombreUsuario) {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

    let item = carrito.find(producto => producto.idPlato === idPlato);

    if (item) {
      item.cantidad++;
    } else {
      carrito.push({ idPlato: idPlato, cantidad: 1 });
    }

    localStorage.setItem("carrito", JSON.stringify(carrito));

    Swal.fire({
      icon: "success",
      title: "Comida agregada",
      text: "Comida agregada al carrito",
      confirmButtonText: 'Entendido'
    });
  } else {
    Swal.fire({
      icon: "warning",
      title: "Atencion",
      text: "Debe de estar logueado para hacer compras",
      confirmButtonText: 'Entendido'
    });
  }

}



document.getElementById("btnDescarga").addEventListener("click", () => {
  window.open("descarga.php", "_blank");
});

function favoritos(id) {
  fetch('agregarFavoritos.php?id=' + id) //el ?id es el q depsues se pone en GET[id]
    .then(res => res.json())
    .then(data => {

      if (data.session) {
        Swal.fire({
          icon: 'warning',
          title: 'Antención',
          text: 'Debe estar logueado para tener favoritos',
          confirmButtonText: 'Entendido'
        });

      } else if (data.success) {
        Swal.fire({
          icon: 'success',
          title: 'Exito',
          text: 'Plato agregado a favoritos',
          confirmButtonText: 'Entendido'
        });

      } else {
        Swal.fire({
          icon: 'warning',
          title: 'Atención',
          text: data.error,
          confirmButtonText: 'Entendido'
        });

      }
    })
}

const busqueda = document.getElementById('busqueda');
var divBusqueda = document.getElementById("divBusqueda");

busqueda.addEventListener('keypress', (event) => {
  const palabra = busqueda.value;
  fetch("busquedaMenu.php?b=" + palabra)
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        card.innerHTML = '  ';
        data.success.forEach(element => {
          const precioFinal = element.precio - (element.precio * element.promocion / 100);

          // Verificamos si hay promoción
          const promoTexto = precioFinal < element.precio
            ? `<p class='promo-texto'>🔥 PROMOCIÓN - ${element.promocion}% OFF</p>`
            : "";

          // el : de arriba es como un "si no" tipo else, se llama operador ternario
          card.innerHTML += `
    <div class="menu-card">
      <h2 class='menu-card-title'>${element.nombrePlato}</h2>
      <img src="../../IMG/fotosPlatos/${element.ID_plato}.png" alt='fotoPlato'>
      <div class="menu-card-content">
        ${promoTexto}
        <p class='menu-card-price'>Precio: $${precioFinal.toFixed(2)}</p>
        <p class='tiempo-preparacion'>Preparación: ${element.tiempoPreparacion} minutos</p>
        <a href="menuGrande.html?id=${element.ID_plato}">
          <button class="menu-card-btn">Ver más</button>
        </a>
        <button class="menu-card-btn" onclick="agregarAlCarrito(${element.ID_plato})">Agregar al carrito</button>
        <button onclick="favoritos(${element.ID_plato})" class="menu-card-btn">Agregar a fav</button>
      </div>
    </div>
  `;
        });
      }
    })
});
function cargarTitulo() {
  fetch("../../cargarDatos.php")
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {
        const tituloDiv = document.querySelector(".TituloP h1");
        if (tituloDiv) {
          tituloDiv.textContent = data.success.nombre;
        }
        const telefono = document.querySelector(".footer-phone-number");
        if (telefono) { telefono.textContent = data.success.telefono; }
      }
    })
}
cargarTitulo()