const menu = document.getElementById('menu-container');
const iconoLogin = document.querySelector('.IconoLogin');

document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        // Si está logueado 
        dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
        const misReservas=dropdown.appendChild(crearOpcion("Mis Reservas"));
        dropdown.appendChild(crearOpcion("Favoritos"));
        const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));

        //para cerrar sesion (el li creado antes 2
        cerrarSesion.addEventListener("click", function (event) {
          event.preventDefault()
          fetch('../../sesion/cerrarSesion.php')
            .then(res => res.json())
            .then(data => {
              if (data.success) {
                window.location.href = "../index/index.html"
              } else {
                Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
              }
            })
        })
        //para ver las reservas (usando el boton creade en el logueo)
        misReservas.addEventListener("click", function (event) {
          window.location.href = "../SistemaDeReservas/MisReservas.html"
        })

      }
    })
})
document.getElementById("iconoCarrito").addEventListener("click", async e => { //el async y await es como decir: espera a que temrine la operacion 
  e.preventDefault();
  const res = await fetch("../../sesion/controlExistenciaUsuario.php");
  const { success } = await res.json();
  if (success) location.href = "../carrito/carrito.html";
});

document.getElementById("iconoLogin").addEventListener("click", async e => { //el async y await es como decir: espera a que temrine la operacion 
  e.preventDefault();
  const res = await fetch("../../sesion/controlExistenciaUsuario.php");
  const { success } = await res.json();
  if (!success){ location.href = "../../sesion/login.html"

  }else{
      location.href = "../perfil/perfil.html"
  }
});

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas

cargarMenu();
$datosMenu="";
function cargarMenu() {
    fetch('datos.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
              $datosMenu=data;
                data.success.forEach(element => {
                    const card = document.createElement("div");
                    card.classList.add("menu-card");
                    card.innerHTML = `
                        <h2 class='menu-card-title'>${element.nombrePlato}</h2>
                        <img src="../../IMG/fotosPlatos/${element.ID_plato}"alt='fotoPlato'>
                        <div class="menu-card-content">
                            <p class='menu-card-price'>Precio: ${element.precio}$ </p>
                            <p class='tiempo-preparacion'>Preparación: ${element.tiempoPreparacion} minutos</p>
                            <a href="menugrande.html">
                                <button class="menu-card-btn">Ver más</button>
                            </a>
                            <button class="menu-card-btn" onclick="agregarAlCarrito(${element})">Agregar al carrito</button>
                            <button onclick="favoritos(${element.ID_plato})" class="menu-card-btn-fav">Agregar a fav</button>
                        </div>
                    `;
                    menu.appendChild(card);
                });
            } else {
                menu.innerHTML = `<h1>No hay platos en este momento</h1>`;
            }
        });
}

function agregarAlCarrito(plato) {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    carrito.push(plato);
    localStorage.setItem("carrito", JSON.stringify(carrito));
}

document.getElementById("btnDescarga").addEventListener("click", () => {
   window.open("descarga.php", "_blank");
});

function favoritos(id){
  fetch('agregarFavoritos.php?id='+id) //el ?id es el q depsues se pone en GET[id]
  .then(res=>res.json())
  .then(data=>{
    if(data.session){
      Swal.fire({
            icon: 'warning',
            title: 'Antención',
            text: 'Debe estar logueado para tener favoritos',
            confirmButtonText: 'Entendido'
          });

    }else if(data.session){
      Swal.fire({
            icon: 'success',
            title: 'Exito',
            text: 'Plato agregado a favoritos',
            confirmButtonText: 'Entendido'
          });

    }else{
      Swal.fire({
            icon: 'warning',
            title: 'Error',
            text: $data.error,
            confirmButtonText: 'Entendido'
          });

    }
  })
}