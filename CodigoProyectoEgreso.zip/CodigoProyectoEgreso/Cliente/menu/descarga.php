<?php
require('../../FPDF/fpdf.php');
require('../sesion/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',12);

// Encabezados
$pdf->Cell(10,10,'ID',1);
$pdf->Cell(40,10,'Nombre',1);
$pdf->Cell(40,10,'Temporada',1);
$pdf->Cell(30,10,'Tiempo Prep.',1);
$pdf->Cell(30,10,'Precio',1);
$pdf->Ln();
$pdf->Cell(150,10,'Descripcion',1);
$pdf->Ln();

$stmt = $con->query("SELECT * FROM Plato");
$platos = $stmt->fetchAll(PDO::FETCH_ASSOC);

if(!$platos || count($platos) === 0){
    $pdf->Cell(0,10,'No hay platos registrados.',0,1,'C');
} else {
    foreach($platos as $fila){
        $pdf->Cell(10,10,$fila['ID_plato'],1);
        $pdf->Cell(40,10,utf8_decode($fila['nombrePlato']),1);
        $pdf->Cell(40,10,utf8_decode($fila['temporada']),1);
        $pdf->Cell(30,10,$fila['tiempoPreparacion'].' min',1);
        $pdf->Cell(30,10,'$'.$fila['precio'],1);
        $pdf->Ln();

        $pdf->MultiCell(150,10,utf8_decode($fila['descripcion']),1);
        $pdf->Ln(2);

        $rutaImg = "../../IMG/fotosPlatos/".$fila['ID_plato'].".png";
        if(file_exists($rutaImg)){
            $x = $pdf->GetX();
            $y = $pdf->GetY();
            $pdf->Image($rutaImg, $x, $y, 40, 40);
            $pdf->Ln(42);
        } else {
            $pdf->Cell(40,10,"(sin imagen)");
            $pdf->Ln();
        }

        $pdf->Ln(5);
    }
}

// ¡IMPORTANTE! fuera del foreach
$pdf->Output('D', 'menu.pdf'); 
