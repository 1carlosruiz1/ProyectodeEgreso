<?php
session_start();
require "../sesion/conexion.php";

if(!$_SESSION['usuario']['tipo']==='Cliente'){
    echo json_encode(["session"=>"Debe estar logueado para tener favoritos"])
    exit;
}
    $ID_plato=$_GET["id"];
try{
    $stmt=$con->prepare("INSERT INTO Favorito (ID_cliente, ID_plato) VALUES (?, ?)");
    $stmt->execute($_SESSION['usuario']['ID'], $ID_plato);
    echo json_encode(["success"=>"Agregado"])
    
}catch(PDOException $e){
    echo json_encode(["error"=>$e->getMessage()])
    
}