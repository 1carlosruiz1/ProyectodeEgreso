<?php
require "../sesion/conexion.php";

// Leer JSON del POST
$input = json_decode(file_get_contents("php://input"), true);
$fechaHoraInicio = $input["fechaHoraInicio"] ?? null; // "2025-09-25 18:30:00"
$fechaHoraFin = $input["fechaHoraFin"] ?? null;       // "2025-09-25 20:30:00"

if (!$fechaHoraInicio || !$fechaHoraFin) {
    echo json_encode([
        "error" => "Faltan datos de fecha/hora"
    ]);
    exit;
}

// Separar fecha y hora
$fechaInicio = date("Y-m-d", strtotime($fechaHoraInicio));
$horaInicio = date("H:i:s", strtotime($fechaHoraInicio));
$fechaFin = date("Y-m-d", strtotime($fechaHoraFin));
$horaFin = date("H:i:s", strtotime($fechaHoraFin));

try {
    // Selecciona mesas libres: ninguna reserva existente que se solape con el rango indicado
    $sql = "
        SELECT *
        FROM Mesa m
        WHERE m.ID_mesa NOT IN (
            SELECT r.ID_mesa
            FROM Reserva r
            WHERE r.cancelado = 0
              AND r.fechaReserva = ?
              AND (r.horaInicio < ? AND r.horaFin > ?)
        )
        ORDER BY m.numeroMesa
    ";

    $stmt = $con->prepare($sql);
    $stmt->execute([$fechaInicio, $horaFin, $horaInicio]);

    $mesas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($mesas && count($mesas) > 0) {
        echo json_encode([
            "success" => true,
            "datos" => $mesas
        ]);
    } else {
        echo json_encode([
            "vacio" => "No hay mesas disponibles en ese rango"
        ]);
    }

} catch (PDOException $e) {
    echo json_encode([
        "error" => $e->getMessage()
    ]);
}
