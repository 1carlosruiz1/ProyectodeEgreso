<?php
require "../sesion/conexion.php";
$id=$_GET["id"];
try {
    $stmt=$con->prepare("DELETE FROM Favorito WHERE ID_plato = ?");
    $stmt->execute([$id]);
    echo json_encode(["success"=> "Plato eliminao de favoritos"]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}