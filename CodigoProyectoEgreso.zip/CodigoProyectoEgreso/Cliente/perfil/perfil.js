const menu = document.getElementById('menu-container');
const iconoLogin = document.querySelector('.IconoLogin');
let nombreUsuario = "";
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        // Si está logueado 
        dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
        const misReservas = dropdown.appendChild(crearOpcion("Mis Reservas"));
        const favortiosIr = dropdown.appendChild(crearOpcion("Favoritos"));
        const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
        nombreUsuario = data.usuario.nombre;
        //para cerrar sesion (el li creado antes 2
        cerrarSesion.addEventListener("click", function (event) {
          event.preventDefault()
          fetch('../sesion/cerrarSesion.php')
            .then(res => res.json())
            .then(data => {
              if (data.success) {
                window.location.href = "../index/index.html"
              } else {
                Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
              }
            })
        })
        favortiosIr.addEventListener("click", function (event) {
          window.location.href = "../perfil/index.html"
        })
        //para ver las reservas (usando el boton creade en el logueo)
        misReservas.addEventListener("click", function (event) {
          window.location.href = "../SistemaDeReservas/MisReservas.html"
        })

      } else {
        window.location.href = "../index/index.html"
      }
    })
})
document.getElementById("iconoCarrito").addEventListener("click", async e => { //el async y await es como decir: espera a que temrine la operacion 
  e.preventDefault();
  const res = await fetch("../../sesion/controlExistenciaUsuario.php");
  const { success } = await res.json();
  if (success) location.href = "../carrito/carrito.html";
});

document.getElementById("iconoLogin").addEventListener("click", async e => { //el async y await es como decir: espera a que temrine la operacion 
  e.preventDefault();
  const res = await fetch("../../sesion/controlExistenciaUsuario.php");
  const { success } = await res.json();
  if (!success) {
    location.href = "../../sesion/login.html"

  } else {
    location.href = "../perfil/perfil.html"
  }
});

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas


//mandar nuevos datos
const form = document.getElementById("perfil-form");

form.addEventListener("submit", function (datos) {
  datos.preventDefault();
  const formdata = new FormData(form);
  fetch('nuevoPerfil.php', {
    method: "POST",
    body: formdata
  })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        Swal.fire({
          icon: "success",
          title: "Exito",
          text: data.success,
          confirmButtonText: 'Entendido'
        })
          .then(() => {
            location.reload();
          })
      } else if (data.vacio) {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: data.vacio,
          confirmButtonText: 'Entendido'
        })
      } else if(data.email){
        Swal.fire({
          icon: "warning",
          title: "Error",
          text: data.email,
          confirmButtonText: 'Entendido'
        })
      }else if(data.sinCambios){
        Swal.fire({
          icon: "warning",
          title: "Atención",
          text: data.sinCambios,
          confirmButtonText: 'Entendido'
        })
      }else {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: data.error,
          confirmButtonText: 'Entendido'
        })
      }
    })
})

//para ver los datos del suuari
verDatos()
function verDatos() {
  fetch('../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {

      if (data.success) {

        document.getElementById("nombre").value = data.usuario.nombre;
        document.getElementById("apellido").value = data.usuario.apellido;
        document.getElementById("email").value = data.usuario.email;
      } else {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: data,
          confirmButtonText: 'Entendido'
        })
          .then(() => {
            window.location.href = "../index/index.html";
          })
      }
    })
}

fetch('favoritos.php')
  .then(res => res.json())
  .then(favoritos => {

    const container = document.getElementById('favoritosContainer');
    container.innerHTML = ""; // limpio antes de renderizar

    if (favoritos.success) {

      favoritos.platos.forEach(plato => {
        const item = document.createElement('div');
        item.classList.add('favorito-item');
        item.innerHTML = `
          <img src="../../IMG/fotosPlatos/${plato.ID_plato}.png" class="favorito-img">
          <div class="favorito-info">
              <h3 class="favorito-nombre">${plato.nombrePlato}</h3>
              <p class="favorito-desc">${plato.descripcion}</p>
              <div class="favorito-botones">
                  <button class="favorito-btn agregar-carrito" onclick="agregarAlCarrito(${plato.ID_plato})">Agregar al carrito</button>
                  <button class="favorito-btn quitar-favorito" onclick="quitarFavorito(${plato.ID_plato})">Quitar de favoritos</button>
                  <button class="favorito-btn ver-mas" onclick="verMas(${plato.ID_plato})">Ver más</button>
              </div>
          </div>
        `;
        container.appendChild(item);
      });

    } else if (favoritos.vacio) {
      const item = document.createElement('div');
      item.classList.add('favorito-item');
      item.innerHTML = `
        <div class="favorito-info">
          <h1>No tiene platos favoritos</h1>
        </div>
      `;
      container.appendChild(item);

    } else if (favoritos.error) {
      Swal.fire({
        icon: "error",
        title: "Error",
        text: favoritos.error
      });
    }
  })

function agregarAlCarrito(idPlato) {
  if (nombreUsuario) {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

    let item = carrito.find(producto => producto.idPlato === idPlato);

    if (item) {
      item.cantidad++;
    } else {
      carrito.push({ idPlato: idPlato, cantidad: 1 });
    }

    localStorage.setItem("carrito", JSON.stringify(carrito));

    Swal.fire({
      icon: "success",
      title: "Comida agregada",
      text: "Comida agregada al carrito",
      confirmButtonText: 'Entendido'
    });
  } else {
    Swal.fire({
      icon: "warning",
      title: "Atencion",
      text: "Debe de estar logueado para hacer compras",
      confirmButtonText: 'Entendido'
    });
  }
}

function quitarFavorito(ID_plato) {
  fetch("eliminarFavorito.php?id=" + ID_plato)
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        Swal.fire({
          icon: "success",
          title: "Exito",
          text: "Plato eliminado",
          confirmButtonText: 'Entendido'
        })
        .then(()=>{
          location.reload();
        })
              } else {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: "Error: "+data.error,
          confirmButtonText: 'Entendido'
        });
      }
    })
}