<?php
include "../sesion/conexion.php";
session_start();
try {
    $stmt = $con->prepare("UPDATE Usuario SET estado = FALSE WHERE email = ?");
    $stmt->execute([$_SESSION["usuario"]["email"]]);
    session_destroy();
    echo json_encode(["success" => "Eliminacion exitosa"]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}