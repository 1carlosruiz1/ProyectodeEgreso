<?php
header("Content-Type: application/json; charset=utf-8");
include "../sesion/conexion.php";
session_start();

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$email = $_POST['email'];
$ID = $_SESSION['usuario']['ID'];

if (empty($nombre) || empty($apellido) || empty($email)) {
    echo json_encode(["vacio" => "Todos los campos deben de tener datos"]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["email" => "El email no es válido"]);
    exit;
}
$datosActuales = $_SESSION['usuario'];
if (
    $nombre === $datosActuales['nombre'] &&
    $apellido === $datosActuales['apellido'] &&
    $email === $datosActuales['email']
) {
    echo json_encode(["sinCambios" => "No hay modificaciones"]);
    exit;
}

try {
    $stmt = $con->prepare("UPDATE Usuario SET nombre=?, apellido=?, email=? WHERE ID_usuario=?");
    $stmt->execute([$nombre, $apellido, $email, $ID]);

    // Actualizar la sesión solo si hubo cambios
    $_SESSION['usuario'] = [
        "nombre"   => $nombre,
        "apellido" => $apellido,
        "email"    => $email,
        "ID"       => $ID,
        "tipo"     => $_SESSION['usuario']['tipo'] ?? "Cliente"
    ];

    echo json_encode(["success" => "Datos actualizados exitosamente"]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
