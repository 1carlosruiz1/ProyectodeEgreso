<?php
header("Content-Type: application/json; charset=utf-8");
include "../sesion/conexion.php";
session_start();

$response = [];
$ID = $_SESSION['usuario']['ID'];
$nombre   = $_POST['nombre'] ?? '';
$apellido = $_POST['apellido'] ?? '';
$email    = $_POST['email'] ?? '';

if (empty($nombre) || empty($apellido) || empty($email)) {
    echo json_encode(["vacio" => "Todos los campos deben tener datos"]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["email" => "El email no es válido"]);
    exit;
}

$datosActuales = $_SESSION['usuario'];
$soloDatosIguales = (
    $nombre === $datosActuales['nombre'] &&
    $apellido === $datosActuales['apellido'] &&
    $email === $datosActuales['email']
);

$hayImagenNueva = isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK;

if ($soloDatosIguales && !$hayImagenNueva) {
    echo json_encode(["sinCambios" => "No hay modificaciones"]);
    exit;
}

try {
    $stmt = $con->prepare("UPDATE Usuario SET nombre=?, apellido=?, email=? WHERE ID_usuario=?");
    $stmt->execute([$nombre, $apellido, $email, $ID]);

    $_SESSION['usuario']['nombre'] = $nombre;
    $_SESSION['usuario']['apellido'] = $apellido;
    $_SESSION['usuario']['email'] = $email;

    $response['success'] = "Datos actualizados exitosamente";
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
    exit;
}

// === 2. Procesar imagen (si fue enviada) ===
if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
    $archivo = $_FILES['imagen'];
    $tmpName = $archivo['tmp_name'];

    // Ruta donde se guardará la foto del usuario (ajusta si querés)
    $destino = "../../IMG/perfiles/" . $ID . ".png";

    $info = getimagesize($tmpName);
    if ($info === false) {
        $response['fotoError'] = "El archivo no es una imagen válida.";
    } else {
        $tipo = $info[2];
        switch ($tipo) {
            case IMAGETYPE_JPEG:
                $img = imagecreatefromjpeg($tmpName);
                break;
            case IMAGETYPE_PNG:
                $img = imagecreatefrompng($tmpName);
                break;
            case IMAGETYPE_GIF:
                $img = imagecreatefromgif($tmpName);
                break;
            default:
                $img = false;
                $response['fotoError'] = "Formato de imagen no soportado.";
        }

        if ($img !== false) {
            if (imagepng($img, $destino)) {
                $response['fotoSuccess'] = $destino;
            } else {
                $response['fotoError'] = "Error al guardar la imagen.";
            }
            imagedestroy($img);
        }
    }
}

echo json_encode($response);
