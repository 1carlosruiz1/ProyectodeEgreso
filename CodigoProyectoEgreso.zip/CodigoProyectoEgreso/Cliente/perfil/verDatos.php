<?php
// require "../sesion/conexion.php";
// session_start();
// header('Content-Type: application/json; charset=utf-8');
// try{
//     $stmt=$con->prepare("SELECT * FROM Usuario WHERE ID_usuario=?");
//     $stmt->execute([$_SESSION['usuario']['ID']]);
//     $res=$stmt->fetch(PDO::FETCH_ASSOC);

//     echo json_encode(["success"=>$_SESSION['usuario']['ID']]);

// }catch(PDOException $e){
//     echo json_encode(["error"=>$e->getMessage()]);
// }
