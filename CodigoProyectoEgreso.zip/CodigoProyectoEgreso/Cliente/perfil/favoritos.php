<?php
require "../sesion/conexion.php";
session_start();
$ID = $_SESSION['ID']; 
try{
    $stmt = $con->prepare("
    SELECT * FROM Plato WHERE ID_plato=?");
    $stmt->execute([$ID]);
    $result = $stmt->fetchAll();
    echo json_encode(["success"=>$result]);

}catch(PDOException $e){
    echo json_encode(["error"=>$e->getMessage()]);
}

