<?php
header('Content-Type: application/json; charset=utf-8');
require "../sesion/conexion.php";
session_start();
$ID = $_SESSION['usuario']['ID'];

try {
    $stmt = $con->prepare("SELECT ID_plato FROM Favorito WHERE ID_cliente=?");
    $stmt->execute([$ID]);
    $fav = $stmt->fetchAll(PDO::FETCH_COLUMN); 

    $resultadoFinal = [];
    if ($fav) {
        foreach ($fav as $ID_plato) {
            $stmt = $con->prepare("SELECT * FROM Plato WHERE ID_plato = ?");
            $stmt->execute([$ID_plato]);
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $resultadoFinal = array_merge($resultadoFinal, $result);
        }
        echo json_encode([
            "success" => true,
            "platos" => $resultadoFinal
        ]);
    } else {
        echo json_encode(["vacio" => "no hay favoritos"]);
    }

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
