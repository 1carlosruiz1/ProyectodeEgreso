<?php
header('Content-Type: application/json; charset=utf-8');
require "../sesion/conexion.php";
session_start();
$ID = $_SESSION['usuario']['ID']; 
try{
    $stmt = $con->prepare(" SELECT ID_plato FROM Favorito WHERE ID_cliente=?");
    $stmt->execute([$ID]);
    $fav = $stmt->fetchAll(PDO::FETCH_COLUMN); //el fetch all es pq agarro TODOS los adetos, sino uso FETCHASSOC, el column solo agatta los ID comoa rray plano

    //ahora saco el palto
    if($fav){
    $stmt = $con->prepare(" SELECT * FROM Plato WHERE ID_plato=?");
    $stmt->execute([$ID]);
    $result = $stmt->fetchAll();
    echo json_encode(["success"=>$result]);
    }else{
        echo json_encode(["vacio"=> "No tiene ningún favorito"]);
    }

}catch(PDOException $e){
    echo json_encode(["error"=>$e->getMessage()]);
}

