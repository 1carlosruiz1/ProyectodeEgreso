const iconoLogin = document.querySelector('.IconoLogin');

document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        // Si está logueado 
        dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
        const misReservas = dropdown.appendChild(crearOpcion("Mis Reservas"));
        dropdown.appendChild(crearOpcion("Favoritos"));
        const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
        const historialCompras = dropdown.appendChild(crearOpcion("Historial "));

        historialCompras.addEventListener("click", function (event) {
          window.location.href = "/CodigoProyectoEgreso/Cliente/historial/historial.html"
        })
        //para cerrar sesion (el li creado antes 2
        cerrarSesion.addEventListener("click", function (event) {
          event.preventDefault()
          fetch('../sesion/cerrarSesion.php')
            .then(res => res.json())
            .then(data => {
              if (data.success) {
                window.location.href = "../index/index.html"
              } else {
                Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
              }
            })
        })

        misReservas.addEventListener("click", function (event) {
          window.location.href = "../SistemaDeReservas/MisReservas.html"
        })
      } else {
        // No logueado
        Swal.fire("No hay anda para ver si no está logueado").then(() => {
          window.location.href = "../index/index.html";
        });
      } //fin del else q es por si no hay usuario registrado
    })
})


// Ejecutar al cargar la página
document.getElementById("iconoCarrito").addEventListener("click", async e => { //el async y await es como decir: espera a que temrine la operacion 
  e.preventDefault();
  const res = await fetch("../../sesion/controlExistenciaUsuario.php");
  const { success } = await res.json();
  if (success) location.href = "../carrito/carrito.html";
});

document.getElementById("iconoLogin").addEventListener("click", async e => { //el async y await es como decir: espera a que temrine la operacion 
  e.preventDefault();
  const res = await fetch("../../sesion/controlExistenciaUsuario.php");
  const { success } = await res.json();
  if (!success) {
    location.href = "../../sesion/login.html"

  } else {
    location.href = "../perfil/perfil.html"
  }
});


const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas


// carrito.js
cargarCarrito()
function cargarCarrito() {
  const lista = document.getElementById("carritoLista");
  const totalSpan = document.getElementById("totalValor");
  const form = document.getElementById("formCarrito");
  lista.innerHTML = "";

  let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
  let total = 0;

  // limpiar inputs hidden previos
  document.querySelectorAll(".input-plato").forEach(e => e.remove());

  if (carrito.length === 0) {
    lista.innerHTML = "<h1>El carrito está vacío</h1>";
    totalSpan.textContent = "0.00";
    return;
  }

  carrito.forEach(item => {
    const div = document.createElement("div");
    div.classList.add("carrito-item");

    fetch("verPlatos.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: item.idPlato })
    })
      .then(res => res.json())
      .then(data => {
        if (data.success && data.plato) {
          const plato = data.plato;

          const precioOriginal = parseFloat(plato.precio);
          const promocion = parseFloat(plato.promocion) || 0;

          const precioFinal = precioOriginal - (precioOriginal * promocion / 100);
          const subtotal = precioFinal * item.cantidad;
          total += subtotal;

          const promoTexto = precioFinal < precioOriginal
            ? `<div class="carrito-promocion">🔥 PROMOCIÓN - ${promocion}% OFF</div>`
            : "";

          div.innerHTML = `
          <img src="../../IMG/fotosPlatos/${plato.ID_plato}.png" alt="Plato" class="carrito-img">
          <div class="carrito-info">
            <div class="carrito-nombre">${plato.nombrePlato}</div>
            <div class="carrito-desc">${plato.descripcion}</div>
            ${promoTexto}
            <div class="carrito-precio">
              Precio: 
              ${precioFinal < precioOriginal
              ? `<span class="precio-original">$${precioOriginal.toFixed(2)}</span> <span class="precio-descuento">$${precioFinal.toFixed(2)}</span>`
              : `$${precioOriginal.toFixed(2)}`
            }
            </div>
            <div class="carrito-cantidad">Cantidad: ${item.cantidad}</div>
            <div class="carrito-subtotal">Subtotal: $${subtotal.toFixed(2)}</div>
          </div>
          <div class="carrito-acciones">
            <button class="carrito-btn eliminar" onclick="eliminarDelCarrito(${plato.ID_plato})">Eliminar</button>
          </div>
        `;

          lista.appendChild(div);

          // input hidden para este plato
          const input = document.createElement("input");
          input.type = "hidden";
          input.name = "idplato[]";
          input.value = plato.ID_plato;
          input.classList.add("input-plato");
          form.appendChild(input);

          totalSpan.textContent = total.toFixed(2);
        }
      });
  });
}




function eliminarDelCarrito(idPlato) {
  let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

  let index = carrito.findIndex(producto => producto.idPlato === idPlato);

  if (index !== -1) {
    if (carrito[index].cantidad > 1) {
      // Si hay más de 1, reducir la cantidad
      carrito[index].cantidad--;
    } else {
      // Si solo hay 1, eliminar el producto del carrito
      carrito.splice(index, 1);
    }
  }

  // Guardar el carrito actualizado
  localStorage.setItem("carrito", JSON.stringify(carrito));

  cargarCarrito();
}


document.getElementById("formCarrito").addEventListener("submit", function (e) {
  e.preventDefault();

  const formData = new FormData(document.getElementById("formCarrito"));

  fetch("comprar.php", {
    method: "POST",
    body: formData
  })
    .then(res => res.json())
    .then(data => {

      if (data.success) {
        Swal.fire({
          icon: "success",
          title: "Exito",
          text: "Pedido comprado, pase por el restaurante a la hora que indicó",
          confirmButtonText: 'Entendido'
        });
        localStorage.removeItem("carrito");
        cargarCarrito();
      } else if (data.tiempo) {
        Swal.fire({
          icon: "warning",
          title: "warning",
          text: data.tiempo,
          confirmButtonText: 'Entendido'
        });
      } else if (data.vacio) {
        Swal.fire({
          icon: "warning",
          title: "warning",
          text: data.vacio,
          confirmButtonText: 'Entendido'
        });
      } else if(data.horario){
        Swal.fire({
          icon: "warning",
          title: "warning",
          text: data.horario,
          confirmButtonText: 'Entendido'
        });
      }else {
        Swal.fire({
          icon: "error",
          title: "error",
          text: "Error: " + data.error,
          confirmButtonText: 'Entendido'
        });
      }
    })
});


