<?php
require "../sesion/conexion.php";
session_start();

$comentario = $_POST['comentario'] ?? '';
$platos = $_POST['idplato']?? [];
$fechaEsperada = $_POST["fechaEsperada"];
$fechaIngreso = date("Y-m-d H:i:s");
$puntos = count($platos) * 10;
if (empty($platos)) {
    echo json_encode(['vacio' => "no hay platos"]);
    exit;
}
$inicio = strtotime($fechaEsperada);
$limiteInicio = strtotime("13:30");
$limiteFin = strtotime("22:30");
if ($inicio < $limiteInicio || $inicio > $limiteFin) {
    echo json_encode(["horario" => "El pedido puede entregarse desde 13:30-22:30"]);
    exit;
}
    $ingreso = new DateTime($fechaIngreso);
    $esperada = new DateTime($fechaEsperada);

    $diferencia = $ingreso->diff($esperada);
    $minutos = ($diferencia->days * 24 * 60) + ($diferencia->h * 60) + $diferencia->i;

    if ($esperada <= $ingreso || $minutos < 45) {
        echo json_encode(['tiempo' => 'Debe darnos al menos 45 minutos para hacer el pedido.']);
        exit;
    }

try {
    $stmt = $con->prepare("INSERT INTO Pedido (fechaPedido, especificaciones, puntosCompra, fechaEsperada, ID_cliente) 
        VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$fechaIngreso, $comentario, $puntos, $fechaEsperada, $_SESSION['usuario']['ID']]);
    $ID_pedido = $con->lastInsertId();

    $conteo = array_count_values($platos);

    foreach ($conteo as $id => $cantidad) {
        $stmt = $con->prepare("INSERT INTO SeCompone (ID_pedido, ID_plato, cantidad)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE cantidad = cantidad + VALUES(cantidad)");
        $stmt->execute([$ID_pedido, $id, $cantidad]);
    }

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
