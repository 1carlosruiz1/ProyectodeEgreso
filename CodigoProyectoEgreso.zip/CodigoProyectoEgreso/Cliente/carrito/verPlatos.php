<?php
include '../sesion/conexion.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = $data["id"] ?? null;

try {
    $sql = "SELECT * FROM Plato WHERE ID_plato = ?";
    $stmt = $con->prepare($sql);
    $stmt->execute([$id]);
    $plato = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($plato) {
        echo json_encode([
            "success" => true,
            "plato" => $plato
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "error" => "Plato no encontrado"
        ]);
    }
} catch (PDOException $e) {
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage()
    ]);
}
