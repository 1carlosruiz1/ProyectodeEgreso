<?php
session_start();
require_once("../sesion/conexion.php");

$id_cliente = $_SESSION['usuario']['ID'];
try {
    $stmt = $con->prepare("SELECT ID_pedido, fechaPedido, especificaciones, puntosCompra, fechaEsperada FROM Pedido WHERE ID_cliente = ? ORDER BY fechaPedido DESC");
    $stmt->execute([$id_cliente]);
    $pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Para cada pedido, obtener los platos
    foreach ($pedidos as &$pedido) {
        $stmtPlatos = $con->prepare(
            "SELECT Plato.ID_plato, Plato.nombrePlato, SeCompone.cantidad
             FROM SeCompone
             INNER JOIN Plato ON SeCompone.ID_plato = Plato.ID_plato
             WHERE SeCompone.ID_pedido = ?"
        );
        $stmtPlatos->execute([$pedido['ID_pedido']]);
        $pedido['platos'] = $stmtPlatos->fetchAll(PDO::FETCH_ASSOC);
    }

    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'pedidos' => $pedidos]);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
