const menu = document.getElementById('menu-container');
const iconoLogin = document.querySelector('.IconoLogin');
let nombreUsuario = "";
document.addEventListener("DOMContentLoaded", function (data) {
    fetch('../sesion/controlExistenciaUsuario.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {

                if (data.usuario.tipo == "Cliente") {
                    // Si está logueado
                    dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
                    const misReservas = dropdown.appendChild(crearOpcion("Mis Reservas"));
                    const favoritos = dropdown.appendChild(crearOpcion("Favoritos"));
                    const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
                    const historialCompras = dropdown.appendChild(crearOpcion("Historial "));

                    historialCompras.addEventListener("click", function (event) {
                        window.location.href = "/CodigoProyectoEgreso/Cliente/historial/historial.html"
                    })
                    //para cerrar sesion (usando el boton creade en el logueo)

                    cerrarSesion.addEventListener("click", function (event) {
                        event.preventDefault()
                        fetch('../sesion/cerrarSesion.php')
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    window.location.href = "../index/index.html"
                                } else {
                                    Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                                }
                            })
                    })
                    //para ver las reservas (usando el boton creade en el logueo)
                    misReservas.addEventListener("click", function (event) {
                        window.location.href = "MisReservas.html"
                    })
                } else {
                    Swal.fire("No se pueden hacer reservas sin estar logueado").then(() => {
                        window.location.href = "../index/index.html";
                    });
                }
            } else {
                Swal.fire("No se pueden hacer reservas sin estar logueado").then(() => {
                    window.location.href = "../index/index.html";
                });
            }
        })
})
document.getElementById("iconoCarrito").addEventListener("click", async e => { //el async y await es como decir: espera a que temrine la operacion 
    e.preventDefault();
    const res = await fetch("../../sesion/controlExistenciaUsuario.php");
    const { success } = await res.json();
    if (success) location.href = "../carrito/carrito.html";
});

document.getElementById("iconoLogin").addEventListener("click", async e => { //el async y await es como decir: espera a que temrine la operacion 
    e.preventDefault();
    const res = await fetch("../../sesion/controlExistenciaUsuario.php");
    const { success } = await res.json();
    if (!success) {
        location.href = "../../sesion/login.html"

    } else {
        location.href = "../perfil/perfil.html"
    }
});

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
    clearTimeout(hideTimeout);
    dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
    hideTimeout = setTimeout(() => {
        dropdown.style.display = 'none';
    }, 120);
});

dropdown.addEventListener('mouseenter', () => {
    clearTimeout(hideTimeout);
    dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
    dropdown.style.display = 'none';
});

function crearOpcion(texto) {
    const li = document.createElement('li');
    li.textContent = texto;
    li.classList.add('dropdown-opcion');

    li.addEventListener('mouseenter', () => {
        li.classList.add('dropdown-opcion-hover');
    });

    li.addEventListener('mouseleave', () => {
        li.classList.remove('dropdown-opcion-hover');
    });

    return li;
}
//hasta acá lo q va en todas las paginas


document.addEventListener('DOMContentLoaded', function () {
    const contenedor = document.querySelector('.historial-lista');
    fetch('historial.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (data.pedidos.length < 1) {
                    contenedor.innerHTML = "<h1>No tienes pedidos realizados.</h1>";
                    return;
                }

                let html = '';
                data.pedidos.forEach(p => {
                    // Armar la lista de platos
                    let platosHtml = '';
                    if (p.platos && p.platos.length > 0) {
                        platosHtml = '<ul class="historial-platos-list">';
                        p.platos.forEach(plato => {
                            platosHtml += `<li>${plato.nombrePlato} <span class="cantidad">x${plato.cantidad}</span></li>`;
                        });
                        platosHtml += '</ul>';
                    } else {
                        platosHtml = '<span class="historial-nombre">Sin platos</span>';
                    }

                    html += `
                    <div class="historial-item">
                        <div class="historial-info">
                            <div class="historial-fecha">Realizado el ${p.fechaPedido}</div>
                            <div class="historial-platos">
                                ${platosHtml}
                                <span class="historial-desc">${p.especificaciones || ''}</span>
                            </div>
                            <div class="historial-total">Puntos: ${p.puntosCompra || 0} — Fecha esperada: ${p.fechaEsperada || '-'}</div>
                        </div>
                        <div class="historial-acciones">
                            <button class="historial-btn volver" onclick="agregarAlCarritoVarios('${encodeURIComponent(JSON.stringify(p.platos))}')">Agregar al carrito</button>
                        </div>
                    </div>
                `;
                });

                contenedor.innerHTML = html;
            } else {
                contenedor.innerHTML = `<h3>Error: ${data.error}</h3>`;
            }

        })
});
function agregarAlCarritoVarios(platosStr) {
    const platos = JSON.parse(decodeURIComponent(platosStr));
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

    platos.forEach(element => {
        let item = carrito.find(producto => producto.idPlato === element.ID_plato);

        if (item) {
            item.cantidad += element.cantidad;
        } else {
            carrito.push({ idPlato: element.ID_plato, cantidad: element.cantidad });
        }
    });

    localStorage.setItem("carrito", JSON.stringify(carrito));
    Swal.fire({
        icon: "success",
        title: "Comidas agregadas",
        text: "Todos los platos fueron agregados al carrito",
        confirmButtonText: 'Entendido'
    });
}
function cargarTitulo() {
    fetch("../../cargarDatos.php")
        .then(res => res.json())
        .then(data => {
            console.log(data);

            if (data.success) {
                const tituloDiv = document.querySelector(".TituloP h1");
                if (tituloDiv) {
                    tituloDiv.textContent = data.success.nombre;
                }
                const telefono = document.querySelector(".footer-phone-number");
                if (telefono) { telefono.textContent = data.success.telefono; }
            }
        })
}
cargarTitulo()