text = document.getElementById('text');
button = document.getElementById('button');

button.addEventListener("click", function(){

});