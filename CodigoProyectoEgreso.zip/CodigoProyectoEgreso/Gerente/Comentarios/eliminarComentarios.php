<?php
require "../sesion/conexion.php";
if(!isset($_GET["id"])){
    exit;
}
$ID=$_GET["id"];
try{
    $stmt=$con->prepare("DELETE FROM Comentario WHERE ID_comentario = ?");
    $stmt->execute([$ID]);
    echo json_encode(["success"=>"Comentario eliminado"]);
}catch(PDOException $e){
    echo json_encode(["error"=>$e->getMessage()]);
}