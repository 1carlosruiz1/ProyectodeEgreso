function verComentarios() {
  fetch('verComentarios.php')
    .then(res => res.json())
    .then(data => {

      const divComentario = document.getElementById("divComentario");
      divComentario.innerHTML = "";

      if (data.success) {
        data.success.forEach(element => {
          divComentario.innerHTML += `
            <div class="comentario-item">
              <div class="comentario-header">
                <span class="puntaje">${element.puntaje}/10</span>
                <span class="usuario-fecha">${element.nombreUsuario} - ${element.fechaComentario}</span>
              </div>
              <p class="comentario-texto">${element.infoComentario}</p>
              <button class="btnEliminar" onclick="eliminarComentario(${element.ID_comentario})">Eliminar comentario</button>
            </div>
          `;
        });
      } else if (data.vacio) {
        divComentario.innerHTML += `
          <div class="comentario-item">
            <h1>${data.vacio}</h1>
          </div>
        `;
      } else {
        divComentario.innerHTML += `
          <div class="comentario-item">
            <h1>${data.error}</h1>
          </div>
        `;
      }
    })
}
verComentarios();
function eliminarComentario(ID) {
  Swal.fire({
    icon: "warning",
    title: "Atencion",
    text: "Eliminar comentario definitivamente?",
    showCancelButton: true,
    confirmButtonText: "Sí, continuar",
    cancelButtonText: "Cancelar"
  })
    .then((result) => {
      if (result.isConfirmed) {
        fetch(`eliminarComentarios.php?id=${ID}`)
          .then(res => res.json())
          .then(data => {

            if (data.success) {
              Swal.fire({
                icon: "info",
                title: "Atencion",
                text: "Comentario eliminado permanenetemente",
                confirmButtonText: "Entendido",
              })
              verComentarios();
            } else {
              Swal.fire({
                icon: "error",
                title: "Atencion",
                text: data.error,
                confirmButtonText: "Entendido",
              })
            }
          })
      }
    })
}

function cargarTitulo() {
  fetch("../../cargarDatos.php")
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {
        const tituloDiv = document.querySelector(".TituloP h1");
        if (tituloDiv) {
          tituloDiv.textContent = data.success.nombre;
        }
      }
    })
}
cargarTitulo()
const menu = document.getElementById('menu-container');
const iconoLogin = document.querySelector('.IconoLogin');
let nombreUsuario = "";
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        if (data.usuario.tipo === "Gerente") {
          // Si está logueado 
          dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
          const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
          //para cerrar sesion (el li creado antes 2
          cerrarSesion.addEventListener("click", function (event) {
            event.preventDefault()
            fetch('../sesion/cerrarSesion.php')
              .then(res => res.json())
              .then(data => {
                if (data.success) {
                  window.location.href = "../../Cliente/index/index.html"
                } else {
                  Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                }
              })
          })

        } else {
          window.location.href = "../../Cliente/index/index.html"
        }
      } else {
          window.location.href = "../../Cliente/index/index.html"
        }

    })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas