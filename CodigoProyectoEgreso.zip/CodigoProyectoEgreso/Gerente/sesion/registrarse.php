<?php
header("Content-Type: application/json; charset=utf-8");
require "conexion.php";

$nombre = $_POST["nombre"] ?? '';
$apellido = $_POST["apellido"] ?? '';
$email = $_POST["emailReg"] ?? '';
$pass = $_POST["passReg"] ?? '';
$passHasheada = password_hash($pass, PASSWORD_DEFAULT);
$tipo=$_POST["tipo"];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      echo json_encode(["emailInvalido"=>"El email no es valido"]);
} 

    //insert de usuario
    try {
    $sql = "SELECT * FROM usuario WHERE email = ?";
    $stmt = $con->prepare($sql);
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        echo json_encode(["email" => "El email ya está registrado"]);
        exit;
    }

    $sql = "INSERT INTO usuario (email, contraseña, nombre, apellido) VALUES (?, ?, ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->execute([$email, $passHasheada, $nombre, $apellido]);

    $idUsuario = $con->lastInsertId();
    
    $sql = "INSERT INTO Empleado (ID_empleado, tipo) VALUES (?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->execute([$idUsuario, $tipo]);
    echo json_encode ([
        "success"=> true, 
      ]);

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}