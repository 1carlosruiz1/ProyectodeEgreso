function verUsuarios(){
  fetch("verUsuarios.php")
    .then(res => res.json())
    .then(data => {
      if (data.success) {

        const contenedor = document.getElementById("empleados");

        // Limpiamos cualquier contenido previo
        contenedor.innerHTML = "";

        // Creamos la tabla
        const tabla = document.createElement("table");
        tabla.style.width = "100%";
        tabla.style.borderCollapse = "collapse";

        // Encabezado
        const thead = document.createElement("thead");
        thead.innerHTML = `
        <tr class="tabla-header">
          <th>ID Empleado</th>
          <th>Nombre</th>
          <th>Apellido</th>
          <th>Email</th>
          <th>Tipo</th>
          <th>Estado</th>
          <th>Acciones</th>
        </tr>
      `;
        tabla.appendChild(thead);

        // Cuerpo
        const tbody = document.createElement("tbody");

        data.success.forEach(element => {
          const tr = document.createElement("tr");

          tr.innerHTML = `
        <td>${element.ID_empleado}</td>
        <td>${element.nombre}</td>
        <td>${element.apellido}</td>
        <td>${element.email}</td>
        <td>${element.tipo}</td>
        <td>${element.estado ? "Activo" : "Inactivo"}</td>
        <td>
          <button class="btn-bloquear" onclick="EliminarEmpleado(${element.ID_empleado})">
            Eliminar
          </button>
        </td>
      `;

          tbody.appendChild(tr);
        });

        tabla.appendChild(tbody);

        // Agregamos la tabla al div
        contenedor.appendChild(tabla);
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Error:' + data.error,
          confirmButtonText: 'Entendido'
        });
      }
    })
}
verUsuarios();

function EliminarEmpleado(ID) {
  Swal.fire({
    icon: "warning",
    title: "Atencion",
    text: "Eliminar cliente definitivamente?",
    showCancelButton: true,
    confirmButtonText: "Sí, continuar",
    cancelButtonText: "Cancelar"
  })
    .then((result) => {
      fetch(`../Estadisticas/eliminar.php?id=${ID}`)
        .then(res => res.json())
        .then(data => {

          if (data.success) {
            Swal.fire({
              icon: "success",
              title: "Atención",
              text: "Empleado desabilitado correctamente",
              confirmButtonText: "Entendido"
            });
            verUsuarios();
          } else {
            Swal.fire({
              icon: "error",
              title: "Atención",
              text: data.error,
              confirmButtonText: "Entendido"
            });
          }

        })
    })

}

const formRegistro = document.getElementById("formRegistro");
const formLogin = document.getElementById("formLogin");

//registro
formRegistro.addEventListener("submit", function (event) {
  event.preventDefault();
  var passReg = document.getElementById("passReg").value;
  var repeatpasswordReg = document.getElementById("repeatPassReg").value;

  if (passReg == repeatpasswordReg) {
    formData = new FormData(formRegistro);
    fetch('registrarse.php', {
      method: 'POST',
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          Swal.fire({
            icon: 'success',
            title: 'Exito',
            text: 'Empleado ingresado',
            confirmButtonText: 'Entendido'
          });
        } else if (data.email) { //emailInvalido
          Swal.fire({
            icon: 'warning',
            title: 'Email incorrecto',
            text: 'Ese mail ya está en uso',
            confirmButtonText: 'Entendido'
          });
        } else if (data.emailInvalido) {
          Swal.fire({
            icon: 'warning',
            title: 'Email incorrecto',
            text: 'El email no es valido',
            confirmButtonText: 'Entendido'
          });
        } else {
          Swal.fire({
            icon: "warning",
            title: "Error:",
            text: data.error
          });
        }

      })

  } else {
    Swal.fire({
      icon: 'warning',
      title: 'Contraseña incorrecta',
      text: 'Ambas contraseñas deben ser iguales',
      confirmButtonText: 'Entendido'
    });
  }
});

const iconoLogin = document.querySelector('.IconoLogin');
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        if (data.usuario.tipo === "Gerente") {
          // Si está logueado 
          dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
          const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
          //para cerrar sesion (el li creado antes 2
          cerrarSesion.addEventListener("click", function (event) {
            event.preventDefault()
            fetch('cerrarSesion.php')
              .then(res => res.json())
              .then(data => {
                if (data.success) {
                  window.location.href = "../../Cliente/index/index.html"
                } else {
                  Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                }
              })
          })
        } else {
          window.location.href = "../../Cliente/index/index.html"
        }
      } else {
        window.location.href = "../../Cliente/index/index.html"
      }
    })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas
function cargarTitulo(){
  fetch("../../cargarDatos.php")
  .then(res => res.json())
  .then(data => {
    console.log(data);
    
    if (data.success) {
      const tituloDiv = document.querySelector(".TituloP h1");
      if (tituloDiv) {
        tituloDiv.textContent = data.success.nombre;
      }
    }
  })
}
cargarTitulo()