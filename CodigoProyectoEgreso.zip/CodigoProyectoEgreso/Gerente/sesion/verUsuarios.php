<?php
require "conexion.php";
try {
    $stmt = $con->prepare("SELECT * FROM Usuario JOIN Empleado E on Usuario.ID_usuario=E.ID_empleado where Usuario.estado=TRUE");
    $stmt->execute();
    $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(["success" => $res]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}