<?php
header('Content-Type: application/json');
include '../sesion/conexion.php'; 

if (!isset($_POST['nombre']) || !isset($_POST['historia']) || !isset($_POST['horarios']) || 
    !isset($_POST['mision']) || !isset($_POST['vision']) || !isset($_POST['valores']) || 
    !isset($_POST['telefono'])) {
    
    echo json_encode(['vacio' => 'Faltan uno o más campos requeridos']);
    exit;
}

$nombre   = $_POST['nombre'];
$historia = $_POST['historia'];
$horarios = $_POST['horarios'];
$mision   = $_POST['mision'];
$vision   = $_POST['vision'];
$valores  = $_POST['valores'];
$telefono = $_POST['telefono'];

try {
    $sql = "UPDATE Restaurante SET 
        nombre = :nombre,
        historia = :historia,
        horarios = :horarios,
        mision = :mision,
        vision = :vision,
        valores = :valores,
        telefono = :telefono
        WHERE ID_restaurante = 1";

    $stmt = $con->prepare($sql);

    $stmt->bindValue(':nombre', $nombre);
    $stmt->bindValue(':historia', $historia);
    $stmt->bindValue(':horarios', $horarios);
    $stmt->bindValue(':mision', $mision);
    $stmt->bindValue(':vision', $vision);
    $stmt->bindValue(':valores', $valores);
    $stmt->bindValue(':telefono', $telefono);

    $stmt->execute();

    echo json_encode(['success' => 'Datos del restaurante actualizados correctamente']);

} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}