<?php
$response = [];
$idPlato = "logoRestaurante"; // o el ID que quieras, si es solo 1 logo

if (isset($_FILES['imagen'])) {
    $archivo = $_FILES['imagen'];
    $tmpName = $archivo['tmp_name'];
    $destino = '../../IMG/fotosPlatos/' . $idPlato . '.png'; // siempre PNG

    $info = getimagesize($tmpName);
    if ($info === false) {
        $response['fotoError'] = "El archivo no es una imagen válida.";
    } else {
        $tipo = $info[2]; // tipo de imagen
        switch ($tipo) {
            case IMAGETYPE_JPEG:
                $img = imagecreatefromjpeg($tmpName);
                break;
            case IMAGETYPE_PNG:
                $img = imagecreatefrompng($tmpName);
                break;
            case IMAGETYPE_GIF:
                $img = imagecreatefromgif($tmpName);
                break;
            default:
                $img = false;
                $response['fotoError'] = "Formato de imagen no soportado.";
        }

        if ($img !== false) {
            if (imagepng($img, $destino)) {
                $response['fotoSuccess'] = $destino;
            } else {
                $response['fotoError'] = "Error al guardar la imagen como PNG.";
            }
            imagedestroy($img);
        }
    }
} else {
    $response['fotoError'] = "No se recibió ningún archivo.";
}

echo json_encode($response);
?>