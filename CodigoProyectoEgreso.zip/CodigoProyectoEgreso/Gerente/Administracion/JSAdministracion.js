const menu = document.getElementById('menu-container');
const iconoLogin = document.querySelector('.IconoLogin');
let nombreUsuario = "";
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        if (data.usuario.tipo === "Gerente") {
          // Si está logueado 
          dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
          const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
          //para cerrar sesion (el li creado antes 2
          cerrarSesion.addEventListener("click", function (event) {
            event.preventDefault()
            fetch('../sesion/cerrarSesion.php')
              .then(res => res.json())
              .then(data => {
                if (data.success) {
                  window.location.href = "../../Cliente/index/index.html"
                } else {
                  Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                }
              })
          })

        } else {
          window.location.href = "../../Cliente/index/index.html"
        }

      }else {
          window.location.href = "../../Cliente/index/index.html"
        }
    })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas

const input = document.getElementById('inputLogo');
const logoActual = document.getElementById('logoRestaurante');
const nombreArchivo = document.getElementById('nombreArchivo');

input.addEventListener('change', () => {
  const file = input.files[0];
  if (file) {
    nombreArchivo.textContent = file.name;

    const reader = new FileReader();
    reader.onload = function (e) {
      // Reemplaza directamente el logo
      logoActual.src = e.target.result;
    }
    reader.readAsDataURL(file);
  } else {
    nombreArchivo.textContent = "Ningún archivo seleccionado";
    logoActual.src = "../../IMG/Logo.png";
  }
});

// Subida al servidor
document.getElementById('formLogo').addEventListener('submit', function (e) {
  e.preventDefault();
  if (input.files.length === 0) return;

  const formData = new FormData();
  formData.append('imagen', input.files[0]);

  fetch('subirLogo.php', {
    method: 'POST',
    body: formData
  })
    .then(res => res.json())
    .then(data => {
      if (data.fotoSuccess) {
        alert('Logo actualizado correctamente');
        // Forzar recarga del logo desde el servidor (evitar cache)
        logoActual.src = data.fotoSuccess + '?t=' + Date.now();
      } else if (data.fotoError) {
        Swal.fire({ icon: 'error', title: 'Error', text: data.fotoError });
      } else {
        alert(data.fotoError || 'Error al subir la imagen');
      }
    })
    .catch(err => {
      console.error(err);
      alert('Error al conectar con el servidor');
    });
});

cargarDatos();
function cargarDatos() {
  fetch("cargarDatos.php")
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        const restaurante = data.success;

        // Logo (si tuvieras un logo aparte)
        const logo = document.getElementById("logoRestaurante");
        if (logo && restaurante.logo) {
          logo.src = restaurante.logo;
        }

        // Título
        const nombreInput = document.getElementById("nombre");
        const cardTitulo = document.getElementById("tituloRestaurante");
        if (nombreInput && cardTitulo) {
          nombreInput.value = restaurante.nombre;
          cardTitulo.textContent = restaurante.nombre;
        }

        // Teléfono
        const telefonoInput = document.getElementById("telefono");
        if (telefonoInput) {
          telefonoInput.value = restaurante.telefono;
        }

        // Historia
        const historiaTextarea = document.getElementById("historia");
        if (historiaTextarea) {
          historiaTextarea.value = restaurante.historia;
        }

        // Horarios
        const horariosTextarea = document.getElementById("horarios");
        if (horariosTextarea) {
          horariosTextarea.value = restaurante.horarios;
        }

        // Misión
        const misionTextarea = document.getElementById("mision");
        if (misionTextarea) {
          misionTextarea.value = restaurante.mision;
        }

        // Visión
        const visionTextarea = document.getElementById("vision");
        if (visionTextarea) {
          visionTextarea.value = restaurante.vision;
        }

        // Valores
        const valoresTextarea = document.getElementById("valores");
        if (valoresTextarea) {
          valoresTextarea.value = restaurante.valores;
        }
      }
    })
    .catch(err => {
      console.error("Error al cargar los datos:", err);
    });
}

// Enviar todos los datos del form al PHP
document.getElementById("formDatos").addEventListener("submit", function (e) {
  e.preventDefault();

  const form = e.target;
  const formData = new FormData(form);

  fetch("actualizarDatos.php", {
    method: "POST",
    body: formData
  })
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {
        Swal.fire({
          icon: "success",
          title: "Éxito",
          text: data.success,
          confirmButtonText: "Entendido"
        }).then(data => {
          location.reload();
        })

      } else if (data.error) {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: data.error,
          confirmButtonText: "Entendido"
        });
      } else if (data.vacio) {
        Swal.fire({
          icon: "info",
          title: "Atención",
          text: data.vacio,
          confirmButtonText: "Entendido"
        });
      }
    })

});
function cargarTitulo() {
  fetch("../../cargarDatos.php")
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {
        const tituloDiv = document.querySelector(".TituloP h1");
        if (tituloDiv) {
          tituloDiv.textContent = data.success.nombre;
        }
      }
    })
}
cargarTitulo()


