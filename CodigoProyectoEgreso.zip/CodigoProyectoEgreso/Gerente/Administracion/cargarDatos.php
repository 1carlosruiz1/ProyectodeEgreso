<?php
require "../sesion/conexion.php";
try {
    $stmt = $con->prepare("SELECT * from Restaurante");
    $stmt->execute();
    $res = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode(["success" => $res]);
} catch (PDOException $e) {
    echo json_encode(["success" => $e->getMessage()]);
}