<?php
require "../sesion/conexion.php";

try {
    $stmt = $con->prepare(" SELECT 
    R.ID_reserva,
    CONCAT(U.nombre, ' ', U.apellido) AS nombreCliente,
    M.numeroMesa AS mesa,
    R.fechaReserva,
    R.horaInicio,
    R.horaFin,
        R.fechaRealizacion
    FROM Reserva R
    JOIN Cliente C ON R.ID_cliente = C.ID_cliente
    JOIN Usuario U ON C.ID_cliente = U.ID_usuario
    JOIN Mesa M ON R.ID_mesa = M.ID_mesa
    WHERE R.cancelado = FALSE");
    $stmt->execute();
    $comentarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($comentarios && count($comentarios) > 0) {
        echo json_encode(["success" => $comentarios]);
    } else {
        echo json_encode(["vacio" => "No hay reservas todavía :("]);
    }

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
