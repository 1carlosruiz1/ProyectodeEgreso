<?php
require "../sesion/conexion.php";
if(!isset($_GET["id"])){
    exit;
}
$ID=$_GET["id"];
try{
    $stmt=$con->prepare("UPDATE Reserva SET cancelado = TRUE WHERE ID_reserva = ?");
    $stmt->execute([$ID]);
    echo json_encode(["success"=>"Reserva eliminada"]);
}catch(PDOException $e){
    echo json_encode(["error"=>$e->getMessage()]);
}