<?php
require "../sesion/conexion.php";
$fechaInicio = $_POST['inicioGanancias'];
$fechaFin = $_POST['finGanancias'];

if (!isset($fechaInicio) || !isset($fechaFin)) {
    echo json_encode(["vacio" => "Ingrese ambas fechas"]);
    exit();
}
if ($fechaInicio > $fechaFin) {
    echo json_encode(["fecha" => "La fecha de inicio no puede ser mayor a la fecha fin"]);
    exit();
}
try {
    $sqlWeb = $con->prepare("
        SELECT P.precio
        FROM seCompone sC
        JOIN plato P ON sC.ID_plato = P.ID_plato
        JOIN pedido Ped ON sC.ID_pedido = Ped.ID_pedido
        WHERE Ped.fechaEsperada BETWEEN :fechaInicio AND :fechaFin
    ");
    $sqlWeb->execute([':fechaInicio' => $fechaInicio, ':fechaFin' => $fechaFin]);
    $web = $sqlWeb->fetchAll(PDO::FETCH_ASSOC);
    $

} catch (PDOException $e) {
    echo json_encode(["error" => "Error en la base de datos: " . $e->getMessage()]);
}