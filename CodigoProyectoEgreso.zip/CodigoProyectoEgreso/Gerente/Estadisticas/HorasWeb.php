<?php
require "../sesion/conexion.php";
try {
    $stmt = $con->prepare("SELECT fechaEsperada FROM Pedido");
    $stmt->execute();
    $times = $stmt->fetchAll(PDO::FETCH_COLUMN); // Fetches ALL 'fechaEsperada' as an array of strings

    $totalSeconds = 0;
    $count = 0;

    foreach ($times as $timeString) {
        // Explode the H:i:s string into parts
        list($hours, $minutes, $seconds) = explode(':', $timeString);

        // Convert the time to total seconds
        $currentSeconds = ($hours * 3600) + ($minutes * 60) + $seconds;

        // Add to the running total
        $totalSeconds += $currentSeconds;
        $count++;
    }

    $tiempoTotal_seconds = $totalSeconds;
    $contador = $count;

    // 3. Calculate the average time in seconds
    $averageSeconds = ($count > 0) ? round($tiempoTotal_seconds / $count) : 0;

    // 4. Convert the total and average seconds back to H:i:s format

    // Function to convert seconds back to H:i:s format
    function secondsToHms($seconds) {
        $h = floor($seconds / 3600);
        $m = floor(($seconds % 3600) / 60);
        $s = $seconds % 60;
        // Ensure two digits for minutes and seconds
        return sprintf('%02d:%02d:%02d', $h, $m, $s);
    }

    $tiempoTotal_hms = secondsToHms($tiempoTotal_seconds);
    $tiempoPromedio_hms = secondsToHms($averageSeconds);

    echo "Total number of orders (Contador): " . $contador . "\n";
    echo "Total accumulated time (H:i:s): " . $tiempoTotal_hms . "\n";
    echo "Average expected time (H:i:s): " . $tiempoPromedio_hms . "\n";

} catch (PDOException $e) {
    // Handle any database errors
    echo "Error: " . $e->getMessage();
}

?>