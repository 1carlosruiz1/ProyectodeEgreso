<?php
require "../sesion/conexion.php";
$fechaInicio = $_POST['fechaInicioHora'] ?? null;
$fechaFin = $_POST['fechaFinHora'] ?? null;

if (!isset($fechaInicio) || !isset($fechaFin)) {
    echo json_encode([
        "vacio" => "Ingrese ambas fechas",
        "valores" => [$fechaInicio, $fechaFin]
    ]);
    exit();
}
if ($fechaInicio > $fechaFin) {
    echo json_encode(["fecha" => "La fecha de inicio no puede ser mayor a la fecha fin"]);
    exit();
}

try {
    $stmt = $con->prepare("SELECT fechaEsperada FROM Pedido WHERE fechaEsperada between :horaInicio AND :horaFin");
    $stmt->execute(['horaInicio' => $fechaInicio, 'horaFin' => $fechaFin]);
    $res = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $arrayHora = [];
    $arrayOrdenado = [];
    foreach ($res as $timeString) {
        $fecha = explode(' ', $timeString);
        $hora = intval($fecha[1]);
        array_push($arrayHora, $hora);
        $arrayOrdenado = array_count_values($arrayHora);
    }
    arsort($arrayOrdenado);
    echo json_encode(["success" => $arrayOrdenado]);
} catch (PDOException $e) {
    echo json_encode(['error' . $e->getMessage()]);
}
