<?php
require "../sesion/conexion.php";
$fechaInicio=$_POST['fechaInicio'];
$fechaFin=$_POST['fechaFin'];

if(!isset($fechaInicio) || !isset($fechaFin)){
    echo json_encode(["vacio" => "Ingrese ambas fechas"]);
    exit();
}
if ($fechaInicio > $fechaFin) {
    echo json_encode(["fecha" => "La fecha de inicio no puede ser mayor a la fecha fin"]);
    exit();
}
try {
    $sql = $con->prepare("SELECT sC.ID_pedido, sC.ID_plato, sC.cantidad, P.nombrePlato FROM seCompone sC
     JOIN plato P ON sC.ID_plato = P.ID_plato JOIN pedido Ped ON sC.ID_pedido = Ped.ID_pedido
      WHERE Ped.fechaEsperada BETWEEN :fechaInicio AND :fechaFin");
    $sql->execute([':fechaInicio' => $fechaInicio, ':fechaFin' => $fechaFin]);
    $platos = $sql->fetchAll(PDO::FETCH_ASSOC);
    $cantidadPlatos = [];
    foreach ($platos as &$plato) {
        $ID_plato = $plato['ID_plato'];
        $cantidad = $plato['cantidad'];
        if (isset($cantidadPlatos[$ID_plato])) {
            $cantidadPlatos[$ID_plato]['cantidad'] += $cantidad;
        } else {
            $cantidadPlatos[$ID_plato] = [
                'ID_plato' => $ID_plato,
                'nombrePlato' => $plato['nombrePlato'],
                'cantidad' => $cantidad
            ];
        }

    }
    usort($cantidadPlatos, function ($a, $b) {
        return $b['cantidad'] - $a['cantidad']; // descendente
    });

    echo json_encode(["success" => $cantidadPlatos]);



} catch (PDOException $e) {
    echo json_encode(["Error: " . $e->getMessage()]);

}
