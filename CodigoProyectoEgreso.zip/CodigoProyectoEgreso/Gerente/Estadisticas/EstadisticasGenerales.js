function PlatosMasVendidos() {
    fetch("verPlatos.php")
        .then(response => response.json())
        .then(data => {
            
            var tabla=document.getElementById("div");
            var contenidoTabla=document.getElementById("tabla");
            if(data.success){ 

                data.success.forEach(element => {
                    contenidoTabla.innerHTML+=`<tr>
                    <td>${element.nombrePlato}</td>
                    <td><p>Ventas</p>${element.cantidad}</td>
                    </tr>`;
                    tabla.appendChild(contenidoTabla);
                });

            }else{
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: data.error,
                });
            }
          
        })
}
PlatosMasVendidos();

function horaPicoPromedioWeb() {
fetch("HorasWeb.php")
.then(res=>res.json())
.then(data=>{
    if(data.success){
        
    }else{
    }
})

}

function horaPicoPromedioRestaurante() {


}
function ticketPromedio() {

}