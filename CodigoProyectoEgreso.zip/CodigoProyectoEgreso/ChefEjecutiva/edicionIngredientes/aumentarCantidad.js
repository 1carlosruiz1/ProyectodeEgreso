const params = new URLSearchParams(window.location.search);
const id = params.get("id");
const nombre = params.get("nombre");
const tipo = params.get("tipo");
const h2 = document.querySelector("#formIngrediente label");

document.getElementById("idIngrediente").value = id;
h2.textContent = `Editar ${nombre}  (en ${tipo})`;

document.getElementById("formIngrediente").addEventListener("submit", function(event){
    event.preventDefault()
    formData = new FormData(document.getElementById("formIngrediente"))
    fetch("stock.php",{
        method:"POST",
        body:formData
    })
    .then(res=>res.json())
    .then(data=>{
        if(data.success){
            Swal.fire({
                    icon: "success",
                    title: "exito",
                    text: "Cantidad total actual: "+ data.datos,
                    confirmButtonText: 'Entendido'
                })
        }else if(data.error){
            Swal.fire({
                    icon: "error",
                    title: "error",
                    text: data.error,
                    confirmButtonText: 'Entendido'
                })
        }
    })
})