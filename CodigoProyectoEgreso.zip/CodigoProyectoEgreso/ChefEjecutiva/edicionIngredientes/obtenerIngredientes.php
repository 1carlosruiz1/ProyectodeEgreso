<?php
include '../../sesion/conexion.php';

try {
    $sql = "SELECT i.ID_ingrediente, i.nombreIngrediente, i.unidadMedida, 
                   s.stock, s.fechaIngreso, s.fechaVencimiento
            FROM Ingrediente i
            LEFT JOIN Stock s ON i.ID_ingrediente = s.ID_ingrediente
            ORDER BY i.nombreIngrediente ASC";
    
    $stmt = $con->prepare($sql);
    $stmt->execute();
    $ingredientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($ingredientes);

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}

