<?php
include '../sesion/conexion.php';

$ingrediente = $_POST['ingrediente'];
$unidad = $_POST["unidad"];
$cantidad = $_POST["cantidad"];
$fechaIngreso = date("Y-m-d");
$fechaVencimiento=$_POST["fecha"]; 

try {
    $sql = "SELECT * FROM Ingrediente WHERE nombreIngrediente = ?";
    $stmt = $con->prepare($sql);
    $stmt->execute([$ingrediente]);
    $existe = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existe) {
        echo json_encode(["duplicado" => "Ese ingrediente ya existe"]);
        exit;
    } else {
        $sql = "INSERT INTO Ingrediente (nombreIngrediente, unidadMedida) VALUES (?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->execute([$ingrediente, $unidad]);
        $resultado=$con->lastInsertId();
        
        if(isset($cantidad)){
        $sqlInsert = "INSERT INTO Stock (stock, ID_ingrediente, fechaIngreso, fechaVencimiento) VALUES (?, ?, ?, ?)";
        $stmtInsert = $con->prepare($sqlInsert);
        $stmtInsert->execute([$cantidad, $resultado, $fechaIngreso, $fechaVencimiento]);
        }

        
        echo json_encode(["success" => true]);
    }
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
