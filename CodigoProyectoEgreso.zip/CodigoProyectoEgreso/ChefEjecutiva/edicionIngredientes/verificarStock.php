<?php
header('Content-Type: application/json');
include '../sesion/conexion.php';

try {
    $sql = "SELECT 
                I.ID_ingrediente,
                I.nombreIngrediente,
                I.unidadMedida,
                S.stock,
                S.fechaIngreso,
                S.fechaVencimiento,
                DATEDIFF(S.fechaVencimiento, CURDATE()) AS diasRestantes
            FROM Stock S
            JOIN Ingrediente I ON S.ID_ingrediente = I.ID_ingrediente
            WHERE DATEDIFF(S.fechaVencimiento, CURDATE()) <= 7
            ORDER BY S.fechaVencimiento ASC";

    $stmt = $con->prepare($sql);
    $stmt->execute();

    $datos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(["success" => true, "productos" => $datos]);

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
