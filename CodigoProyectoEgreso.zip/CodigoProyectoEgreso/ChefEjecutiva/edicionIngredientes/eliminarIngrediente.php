<?php
include '../../sesion/conexion.php';

if (isset($_POST['id'])) {
    $id = intval($_POST['id']);

    try {
        $sql = "DELETE FROM Ingrediente WHERE ID_ingrediente = :id";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();

        echo json_encode(["success" => true]);
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "error" => $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "error" => "ID no recibido"]);
}
