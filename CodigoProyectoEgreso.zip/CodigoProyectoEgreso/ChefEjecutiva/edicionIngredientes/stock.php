<?php
include '../../sesion/conexion.php';

$ingrediente = $_POST['idIngrediente']; // ID del ingrediente
$cantidad = $_POST['cantidad'];
$fechaVencimiento = $_POST['vencimiento'];
date_default_timezone_set('America/Montevideo');
$fechaIngreso = date("Y-m-d");

try {
    $sql = "SELECT stock, fechaVencimiento FROM Stock WHERE ID_ingrediente = ?";
    $stmt = $con->prepare($sql);
    $stmt->execute([$ingrediente]);
    $stockExistente = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($stockExistente) {
        $nuevoStock = $stockExistente['stock'] + $cantidad;
        // Fecha vencimiento más lejana
        $nuevaFechaVencimiento = max($stockExistente['fechaVencimiento'], $fechaVencimiento);

        $sqlUpdate = "UPDATE Stock SET stock = ?, fechaIngreso = ?, fechaVencimiento = ? WHERE ID_ingrediente = ?";
        $stmtUpdate = $con->prepare($sqlUpdate);
        $stmtUpdate->execute([$nuevoStock, $fechaIngreso, $nuevaFechaVencimiento, $ingrediente]);
         echo json_encode([
        "success" => true,
        "datos" => $nuevoStock
    ]);
    } else {
        $sqlInsert = "INSERT INTO Stock (stock, ID_ingrediente, fechaIngreso, fechaVencimiento) VALUES (?, ?, ?, ?)";
        $stmtInsert = $con->prepare($sqlInsert);
        $stmtInsert->execute([$cantidad, $ingrediente, $fechaIngreso, $fechaVencimiento]);
         echo json_encode([
        "success" => true,
        "datos" => $cantidad
    ]);
    }

   

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
