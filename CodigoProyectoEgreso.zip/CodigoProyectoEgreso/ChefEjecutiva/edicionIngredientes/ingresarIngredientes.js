const iconoLogin = document.querySelector('.IconoLogin');
document.addEventListener("DOMContentLoaded", function (data) {
    data.preventDefault();
    fetch('../sesion/controlExistenciaUsuario.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {

                if (data.usuario.tipo == "ChefEjecutiva") {
                    dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
                    const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
                    cerrarSesion.addEventListener("click", function (event) {
                        event.preventDefault()
                        fetch('../sesion/cerrarSesion.php')
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    window.location.href = "../../Cliente/index/index.html"
                                } else {
                                    Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                                }
                            })
                    })
                } else {
                    window.location.href = "../../Cliente/index/index.html"
                }
            } else {
                window.location.href = "../../Cliente/index/index.html"
            }
        })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
    clearTimeout(hideTimeout);
    dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
    hideTimeout = setTimeout(() => {
        dropdown.style.display = 'none';
    }, 120);
});

dropdown.addEventListener('mouseenter', () => {
    clearTimeout(hideTimeout);
    dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
    dropdown.style.display = 'none';
});

function crearOpcion(texto) {
    const li = document.createElement('li');
    li.textContent = texto;
    li.classList.add('dropdown-opcion');

    li.addEventListener('mouseenter', () => {
        li.classList.add('dropdown-opcion-hover');
    });

    li.addEventListener('mouseleave', () => {
        li.classList.remove('dropdown-opcion-hover');
    });

    return li;
}
const cantidad = document.getElementById('cantidad');
const fechaInput = document.getElementById('fecha');

const hoy = new Date();


cantidad.addEventListener('input', () => {
    fecha.required = cantidad.value.trim() !== '';
});
document.getElementById("formIngrediente").addEventListener("submit", function (event) {
    event.preventDefault();
    const fechaForm = new Date(fechaInput.value);

    hoy.setHours(0, 0, 0, 0);
    fechaForm.setHours(0, 0, 0, 0);
    if (fechaForm < hoy) {
        Swal.fire({
            icon: "info",
            title: "Atención",
            text: "Fecha inválida",
            confirmButtonText: 'Entendido'
        })
        return;
    }
    formData = new FormData(document.getElementById("formIngrediente"))

    fetch("ingresarIngredientes.php", {
        method: "POST",
        body: formData
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    icon: "success",
                    title: "Éxito",
                    text: "Ingrediente agregado",
                    confirmButtonText: 'Entendido'
                })
                verIngredientes()
            } else if (data.error) {
                Swal.fire({
                    icon: "error",
                    title: "error",
                    text: "Error: " + data.error,
                    confirmButtonText: 'Entendido'
                })
            } else if (data.duplicado) {
                Swal.fire({
                    icon: "info",
                    title: "Atención",
                    text: data.duplicado,
                    confirmButtonText: 'Entendido'
                })
            }
        })
})
const lista = document.getElementById("listaIngredientesExistentes");
verIngredientes()
function verIngredientes() {
  fetch("obtenerIngredientes.php")
    .then(res => res.json())
    .then(data => {
      const lista = document.getElementById("listaIngredientes");
      const controles = document.getElementById("controlesPaginacion");
      lista.innerHTML = "";
      controles.innerHTML = "";

      if (data.error) {
        lista.innerHTML = `<li style="color:red;">Error: ${data.error}</li>`;
        return;
      }

      if (data.length === 0) {
        lista.innerHTML = `<li>No hay ingredientes cargados.</li>`;
        return;
      }

      // Variables para paginación
      let paginaActual = 1;
      const porPagina = 5;
      const totalPaginas = Math.ceil(data.length / porPagina);

      // Función para mostrar una página
      function mostrarPagina(pagina) {
        lista.innerHTML = "";
        const inicio = (pagina - 1) * porPagina;
        const fin = inicio + porPagina;
        const ingredientesPagina = data.slice(inicio, fin);

        ingredientesPagina.forEach(ing => {
          const li = document.createElement("li");
          li.classList.add("claseMenu");
          li.innerHTML = `
            <h3>${ing.nombreIngrediente}<br><br></h3> 
            <span><strong>Cantidad disponible: ${ing.stock ?? 0} (${ing.unidadMedida})</strong></span>
            <span>Ingresada el ${ing.fechaIngreso ?? "-"}, Vence el ${ing.fechaVencimiento ?? "-"}</span>
            <a href="aumentarCantidad.html?id=${ing.ID_ingrediente}&nombre=${ing.nombreIngrediente}&tipo=${ing.unidadMedida}" class="btnEditar">Editar</a>
            <button class="btnEliminar" data-id="${ing.ID_ingrediente}">X</button>
          `;
          lista.appendChild(li);
        });

        actualizarControles();
      }

      // Función para actualizar los botones de paginación
      function actualizarControles() {
        controles.innerHTML = `
          <button id="btnAnterior" ${paginaActual === 1 ? "disabled" : ""}>Anterior</button>
          <span>Página ${paginaActual} de ${totalPaginas}</span>
          <button id="btnSiguiente" ${paginaActual === totalPaginas ? "disabled" : ""}>Siguiente</button>
        `;

        document.getElementById("btnAnterior").addEventListener("click", () => {
          if (paginaActual > 1) {
            paginaActual--;
            mostrarPagina(paginaActual);
          }
        });

        document.getElementById("btnSiguiente").addEventListener("click", () => {
          if (paginaActual < totalPaginas) {
            paginaActual++;
            mostrarPagina(paginaActual);
          }
        });
      }

      // Mostrar la primera página
      mostrarPagina(paginaActual);
    })
    .catch(err => {
      console.error("Error:", err);
    });
}

// preguntar torres el if
lista.addEventListener("click", function (e) {
    if (e.target.classList.contains("btnEliminar")) {
        const id = e.target.getAttribute("data-id");
        Swal.fire({
            icon: "warning",
            title: "Atencion",
            text: "Eliminar ingrediente definitivamente?",
            showCancelButton: true,
            confirmButtonText: "Sí, continuar",
            cancelButtonText: "Cancelar"
        })
            .then((result) => {
                if (result.isConfirmed) {
                    fetch("eliminarIngrediente.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: "id=" + encodeURIComponent(id)
                    })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                e.target.parentElement.remove(); // borra del DOM
                            } else {
                                alert("Error al eliminar: " + data.error);
                            }
                        })
                }
            })
    }
});

function cargarTitulo(){
  fetch("../../cargarDatos.php")
  .then(res => res.json())
  .then(data => {
    console.log(data);
    
    if (data.success) {
      const tituloDiv = document.querySelector(".TituloP h1");
      if (tituloDiv) {
        tituloDiv.textContent = data.success.nombre;
      }
    }
  })
}
cargarTitulo()

function confirmarProductos() {
  fetch("verificarStock.php")
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.error(data.error);
        Swal.fire({
          icon: "error",
          title: "Error al verificar stock",
          text: data.error,
        });
        return;
      }

      if (!data.productos || data.productos.length === 0) {
        Swal.fire({
          icon: "success",
          title: "Todo en orden",
          text: "No hay productos próximos a vencer.",
          timer: 2500,
          showConfirmButton: false,
        });
        return;
      }

      // Filtramos vencidos y por vencer
      const vencidos = data.productos.filter((p) => p.diasRestantes <= 0);
      const proximos = data.productos.filter(
        (p) => p.diasRestantes > 0 && p.diasRestantes <= 7
      );

      // Si hay vencidos
      if (vencidos.length > 0) {
        let listaVencidos = vencidos
          .map(
            (p) =>
              `<li><strong>${p.nombreIngrediente}</strong> (${p.stock} ${p.unidadMedida}) - Vencido el ${p.fechaVencimiento}</li>`
          )
          .join("");

        Swal.fire({
          icon: "error",
          title: "Productos VENCIDOS",
          html: `<ul style="text-align:left">${listaVencidos}</ul>`,
          confirmButtonText: "Entendido",
          confirmButtonColor: "#d33",
        });
      }

      // Si hay productos próximos a vencer
      if (proximos.length > 0) {
        let listaProximos = proximos
          .map(
            (p) =>
              `<li><strong>${p.nombreIngrediente}</strong> (${p.stock} ${p.unidadMedida}) - Vence en ${p.diasRestantes} días (${p.fechaVencimiento})</li>`
          )
          .join("");

        Swal.fire({
          icon: "warning",
          title: "Productos próximos a vencer",
          html: `<ul style="text-align:left">${listaProximos}</ul>`,
          confirmButtonText: "Entendido",
          confirmButtonColor: "#f39c12",
        });
      }

      // Si no hay ni vencidos ni próximos
      if (vencidos.length === 0 && proximos.length === 0) {
        Swal.fire({
          icon: "success",
          title: "Todo en orden",
          text: "No hay productos vencidos ni próximos a vencer.",
          timer: 2500,
          showConfirmButton: false,
        });
      }
    })
    .catch((err) => {
      console.error("Error:", err);
      Swal.fire({
        icon: "error",
        title: "Error inesperado",
        text: "No se pudo conectar con el servidor.",
      });
    });
}

// Ejecutar al cargar la página
window.onload = confirmarProductos;

document.getElementById("verVencidos").addEventListener("submit", function(e){
    e.preventDefault();
    confirmarProductos();
})