const iconoLogin = document.querySelector('.IconoLogin');
document.addEventListener("DOMContentLoaded", function (data) {
    fetch('../../sesion/controlExistenciaUsuario.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (data.usuario.tipo === "ChefEjecutiva") {
                    // Si está logueado 
                    dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
                    const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
                    //para cerrar sesion (el li creado antes 2
                    cerrarSesion.addEventListener("click", function (event) {
                        event.preventDefault()
                        fetch('../sesion/cerrarSesion.php')
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    window.location.href = "../../Cliente/index/index.html"
                                } else {
                                    Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                                }
                            })
                    })
                } else {
                    window.location.href = "../../Cliente/index/index.html"
                }
            } else {
                window.location.href = "../../Cliente/index/index.html"
            }
        })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
    clearTimeout(hideTimeout);
    dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
    hideTimeout = setTimeout(() => {
        dropdown.style.display = 'none';
    }, 120);
});

dropdown.addEventListener('mouseenter', () => {
    clearTimeout(hideTimeout);
    dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
    dropdown.style.display = 'none';
});

function crearOpcion(texto) {
    const li = document.createElement('li');
    li.textContent = texto;
    li.classList.add('dropdown-opcion');

    li.addEventListener('mouseenter', () => {
        li.classList.add('dropdown-opcion-hover');
    });

    li.addEventListener('mouseleave', () => {
        li.classList.remove('dropdown-opcion-hover');
    });

    return li;
}
//hasta acá lo q va en todas las paginas

document.getElementById("formIngrediente").addEventListener("submit", function (event) {
    event.preventDefault();
    formData = new FormData(document.getElementById("formIngrediente"))

    fetch("ingresarIngredientes.php", {
        method: "POST",
        body: formData
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    icon: "success",
                    title: "exito",
                    text: "Ingrediente agregado",
                    confirmButtonText: 'Entendido'
                })
                verIngredientes()
            } else if (data.error) {
                Swal.fire({
                    icon: "error",
                    title: "error",
                    text: "Error: " + data.error,
                    confirmButtonText: 'Entendido'
                })
            } else if (data.duplicado) {
                Swal.fire({
                    icon: "warning",
                    title: "error",
                    text: data.duplicado,
                    confirmButtonText: 'Entendido'
                })
            }
        })
})
const lista = document.getElementById("listaIngredientesExistentes");
verIngredientes()
function verIngredientes() {
    fetch("obtenerIngredientes.php")
        .then(res => res.json())
        .then(data => {

            lista.innerHTML = "";

            if (data.error) {
                lista.innerHTML = `<li style="color:red;">Error: ${data.error}</li>`;
            } else if (data.length === 0) {
                lista.innerHTML = `<li>No hay ingredientes cargados.</li>`;
            } else {
                data.forEach(ing => {
                    const li = document.createElement("li");
                    li.innerHTML = `
                ${ing.nombreIngrediente} 
                <span>Cantidad disponible: ${ing.stock} (${ing.unidadMedida})</span>
                <a href="aumentarCantidad.html?id=${ing.ID_ingrediente}&nombre=${(ing.nombreIngrediente)}&tipo=${(ing.unidadMedida)}" class="btnEditar">Editar</a>
                 <button class="btnEliminar" data-id="${ing.ID_ingrediente}">X</button>
                    `;
                    lista.appendChild(li);
                });
            }
        })
}
// preguntar torres el if
lista.addEventListener("click", function (e) {
    if (e.target.classList.contains("btnEliminar")) {
        const id = e.target.getAttribute("data-id");
        Swal.fire({
            icon: "warning",
            title: "Atencion",
            text: "Eliminar ingrediente definitivamente?",
            showCancelButton: true,
            confirmButtonText: "Sí, continuar",
            cancelButtonText: "Cancelar"
        })
            .then((result) => {
                if (result.isConfirmed) {
                    fetch("eliminarIngrediente.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: "id=" + encodeURIComponent(id)
                    })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                e.target.parentElement.remove(); // borra del DOM
                            } else {
                                alert("Error al eliminar: " + data.error);
                            }
                        })
                }
            })
    }
});