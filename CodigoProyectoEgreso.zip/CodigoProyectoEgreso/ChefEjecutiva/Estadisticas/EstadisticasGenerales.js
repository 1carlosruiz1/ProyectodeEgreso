const iconoLogin = document.querySelector('.IconoLogin');
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        if (data.usuario.tipo === "ChefEjecutiva") {
          // Si está logueado 
          dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
          const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
          //para cerrar sesion (el li creado antes 2
          cerrarSesion.addEventListener("click", function (event) {
            event.preventDefault()
            fetch('../sesion/cerrarSesion.php')
              .then(res => res.json())
              .then(data => {
                if (data.success) {
                  window.location.href = "../../Cliente/index/index.html"
                } else {
                  Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                }
              })
          })
        } else {
          window.location.href = "../../Cliente/index/index.html"
        }
      } else {
        window.location.href = "../../Cliente/index/index.html"
      }
    })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas

function pedidosPorHora(info) {
  fetch("HorasWeb.php", {
    method: "POST",
    body: info
  })
    .then(res => res.json())
    .then(data => {
      if (data.vacio) {
        Swal.fire({
          icon: "warning",
          title: "Atención",
          text: data.vacio,
        });
        return;
      } else if (data.fecha) {
        Swal.fire({
          icon: "info",
          title: "Información",
          text: data.fecha,
        });
        return;
      }
      const contenedor = document.getElementById("infoPedidosHora");
      contenedor.innerHTML = ""; // Limpiamos cualquier contenido anterior

      if (!data.success || Object.keys(data.success).length === 0) {
        contenedor.innerHTML = '<h2>No hay pedidos en el rango seleccionado.</h2>';
        return;
      }

      // Creamos el canvas dinámicamente
      const canvas = document.createElement("canvas");
      canvas.id = "HorasPedidosCanvas";
      contenedor.appendChild(canvas);

      const horas = Object.keys(data.success);
      const cantidades = Object.values(data.success);

      if (window.graficoHoras) {
        window.graficoHoras.destroy();
      }

      const colores = [
        "rgba(46, 204, 113, 0.7)", "rgba(52, 152, 219, 0.7)",
        "rgba(231, 76, 60, 0.7)", "rgba(241, 196, 15, 0.7)",
        "rgba(155, 89, 182, 0.7)", "rgba(230, 126, 34, 0.7)",
        "rgba(26, 188, 156, 0.7)"
      ];
      const coloresBorde = colores.map(c => c.replace("0.7", "1"));

      const ctx = canvas.getContext("2d");
      window.graficoHoras = new Chart(ctx, {
        type: "pie",
        data: {
          labels: horas,
          datasets: [{
            label: "Pedidos por hora",
            data: cantidades,
            backgroundColor: colores.slice(0, horas.length),
            borderColor: coloresBorde.slice(0, horas.length),
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: { position: "top" },
            title: { display: true, text: "Promedio de Pedidos por Hora" },
            tooltip: {
              callbacks: {
                label: function (context) {
                  return `Hora: ${context.label} — Pedidos: ${context.parsed}`;
                }
              }
            }
          }
        }
      });
    })
    .catch(err => console.error(err));
}


function platosMasVendidos(info) {
  fetch("verPlatos.php", {
    method: "POST",
    body: info
  })
    .then(res => res.json())
    .then(data => {
      const cuerpo = document.getElementById("tablaCuerpo");
      cuerpo.innerHTML = "";
      if (data.success && data.success.length < 1) {
        const filaEncabezado = '<h2>No hay platos con ventas en el rango seleccionado.</h2>';
        cuerpo.innerHTML += filaEncabezado;
        return;
      };
      if (data.success) {
        data.success.forEach(plato => {
          const fila = `
            <tr>
              <td>${plato.nombrePlato}</td>
              <td>${plato.cantidad}</td>
            </tr>`;
          cuerpo.innerHTML += fila;
        });
      } else if (data.vacio) {
        Swal.fire({
          icon: "warning",
          title: "Atención",
          text: data.vacio,
        });
      } else if (data.fecha) {
        Swal.fire({
          icon: "info",
          title: "Información",
          text: data.fecha,
        });
      } else {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: data.error,
        });
      }
    });
}


function ocupacionPromedio(info) {
  fetch("ocupacionPromedio.php", {
    method: "POST",
    body: info
  })
    .then(res => res.json())
    .then(data => {

      const cuerpo = document.getElementById("infoOcupacion");
      cuerpo.innerHTML = "";
      if (data.success === 0) {
        cuerpo.innerHTML = "<h2>No ha habido reservas en el rango seleccionado.</h2>";
        return;
      }
      if (data.success) {
        cuerpo.innerHTML = `<p>Tiempo de ocupación promedio: ${data.success}h<br><p>Cantidad de reservas realizadas: ${data.total ?? 0}</p>`;
      } else if (data.vacio) {
        Swal.fire({
          icon: "warning",
          title: "Atención",
          text: data.vacio,
        });
      } else if (data.fecha) {
        Swal.fire({
          icon: "info",
          title: "Información",
          text: data.fecha,
        });
      } else if (data.error) {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: data.error,
        });
      }
    });
}


document.getElementById("fromPlatos").addEventListener("submit", function (e) {
  e.preventDefault();
  const fromPlatos = new FormData(this);
  platosMasVendidos(fromPlatos);
});
document.getElementById("formPedidosHora").addEventListener("submit", function (e) {
  e.preventDefault();
  const formPedidosHora = new FormData(this);
  pedidosPorHora(formPedidosHora);
});
document.getElementById("formTiempoPromedio").addEventListener("submit", function (e) {
  e.preventDefault();
  const formTiempoPromedio = new FormData(this);
  ocupacionPromedio(formTiempoPromedio);
});
var formEtiquetas;


function cargarTitulo(){
  fetch("../../cargarDatos.php")
  .then(res => res.json())
  .then(data => {
    console.log(data);
    
    if (data.success) {
      const tituloDiv = document.querySelector(".TituloP h1");
      if (tituloDiv) {
        tituloDiv.textContent = data.success.nombre;
      }
    }
  })
}
cargarTitulo()