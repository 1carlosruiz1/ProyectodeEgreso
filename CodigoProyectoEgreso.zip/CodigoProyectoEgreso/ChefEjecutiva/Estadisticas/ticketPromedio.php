<?php
require "../sesion/conexion.php";
$fechaInicio=$_POST['fechaInicioTickets'];
$fechaFin=$_POST['fechaFinTickets'];

if(!isset($fechaInicio) || !isset($fechaFin)){
    echo json_encode(["vacio" => "Ingrese ambas fechas"]);
    exit();
}
if ($fechaInicio > $fechaFin) {
    echo json_encode(["fecha" => "La fecha de inicio no puede ser mayor a la fecha fin"]);
    exit();
}

try {
    $sqlWeb = $con->prepare("
        SELECT P.precio
        FROM seCompone sC
        JOIN plato P ON sC.ID_plato = P.ID_plato
        JOIN pedido Ped ON sC.ID_pedido = Ped.ID_pedido
        WHERE Ped.fechaEsperada BETWEEN :fechaInicio AND :fechaFin
          AND Ped.fechaEsperada IS NOT NULL
    ");
    $sqlWeb->execute([':fechaInicio' => $fechaInicio, ':fechaFin' => $fechaFin]);
    $web = $sqlWeb->fetchAll(PDO::FETCH_ASSOC);

    $sqlLocal = $con->prepare("
        SELECT P.precio
        FROM seCompone sC
        JOIN plato P ON sC.ID_plato = P.ID_plato
        JOIN pedido Ped ON sC.ID_pedido = Ped.ID_pedido
        WHERE Ped.fechaPedido BETWEEN :fechaInicio AND :fechaFin
          AND Ped.ID_mesa IS NOT NULL
    ");
    $sqlLocal->execute([':fechaInicio' => $fechaInicio, ':fechaFin' => $fechaFin]);
    $local = $sqlLocal->fetchAll(PDO::FETCH_ASSOC);


    function promedio($lista) {
        $n = count($lista);
        if ($n == 0) return 0;
        $suma = 0;
        foreach ($lista as $x) $suma += $x['precio'];
        return $suma / $n;
    }

    $promWeb = promedio($web);
    $promLocal = promedio($local);
    $gananciasTotales=array_sum(array_column($web, 'precio'));
    $gananciasTotales+=array_sum(array_column($local, 'precio'));
    echo json_encode([
        "success" => true,
        "promedioWeb" => $promWeb,
        "cantidadVentasWeb" => count($web),
        "promedioLocal" => $promLocal,
        "cantidadVentasLocal" => count($local),
        "gananciasTotales" => $gananciasTotales
    ]);

} catch (Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
