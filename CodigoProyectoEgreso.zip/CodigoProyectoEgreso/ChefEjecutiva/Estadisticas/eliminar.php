<?php
include "../sesion/conexion.php";

if(!isset($_GET["id"])){
    exit;
}

$ID=$_GET["id"];
try {
    $stmt = $con->prepare("UPDATE Usuario SET estado = FALSE WHERE ID_usuario = ?");
    $stmt->execute([$ID]);
    echo json_encode(["success" => "Eliminacion exitosa"]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}