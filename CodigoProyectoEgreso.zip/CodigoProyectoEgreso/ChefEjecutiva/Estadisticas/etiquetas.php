<?php
require "../sesion/conexion.php";
$fechaInicio = $_POST['inicioEtiquetas'] ?? null;
$fechaFin = $_POST['finEtiquetas'] ?? null;

if (!isset($fechaInicio) || !isset($fechaFin)) {
    echo json_encode([
        "vacio" => "Ingrese ambas fechas",
        "valores" => [$fechaInicio, $fechaFin]
    ]);
    exit();
}
if ($fechaInicio > $fechaFin) {
    echo json_encode(["fecha" => "La fecha de inicio no puede ser mayor a la fecha fin"]);
    exit();
}
try {
    $stmt = $con->prepare("SELECT * FROM Etiqueta JOIN Cliente on Etiqueta.ID_cliente=Cliente.ID_cliente JOIN Usuario on Cliente.ID_cliente=Usuario.ID_usuario WHERE fecha between :horaInicio AND :horaFin AND Usuario.estado = TRUE");
    $stmt->execute(['horaInicio' => $fechaInicio, 'horaFin' => $fechaFin]);
    $res = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $etiquetas = count($res);

    $stmt = $con->prepare("SELECT COUNT(*) AS total FROM Cliente JOIN Usuario ON Cliente.ID_cliente = Usuario.ID_usuario WHERE Usuario.estado = TRUE");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC); // solo una fila
    $total = $result['total'];

    $stmt = $con->prepare("SELECT U.ID_usuario, U.email, U.nombre, U.apellido, E.fecha, E.comentario, E.tipo
    FROM Usuario U
    JOIN Cliente C ON U.ID_usuario = C.ID_cliente
    JOIN Etiqueta E ON C.ID_cliente = E.ID_cliente
    WHERE U.estado = TRUE
    ORDER BY U.nombre ASC;
");
    $stmt->execute();
    $Clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "success" => $etiquetas,
        "total" => $total,
        "Clientes" => $Clientes
    ]);
} catch (PDOException $e) {
    echo json_encode(['error' . $e->getMessage()]);
}