<?php
require "../sesion/conexion.php";
$fechaInicio = $_POST['inicioTiempoPromedio'];
$fechaFin = $_POST['finTiempoPromedio'];

if (!isset($fechaInicio) || !isset($fechaFin)) {
    echo json_encode(["vacio" => "Ingrese ambas fechas"]);
    exit();
}
if ($fechaInicio > $fechaFin) {
    echo json_encode(["fecha" => "La fecha de inicio no puede ser mayor a la fecha fin"]);
    exit();
}
try {
    $stmt = $con->prepare("SELECT horaInicio, horaFin 
                       FROM Reserva 
                       WHERE fechaRealizacion BETWEEN :fechaInicio AND :fechaFin");
    $stmt->execute([
        ':fechaInicio' => $fechaInicio,
        ':fechaFin' => $fechaFin
    ]);
    $reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $totalresevas = count($reservas);
    if (count($reservas) === 0) {
        echo json_encode(["success" => 0]);
        exit();
    }

    $totalSegundos = 0;

    foreach ($reservas as $r) {
        // Convertir ambas horas a segundos
        list($h1, $m1, $s1) = explode(':', $r['horaInicio']);
        list($h2, $m2, $s2) = explode(':', $r['horaFin']);

        $inicioSeg = ($h1 * 3600) + ($m1 * 60) + $s1;
        $finSeg = ($h2 * 3600) + ($m2 * 60) + $s2;

        // Diferencia en segundos
        $duracion = $finSeg - $inicioSeg;

        // Evitar negativos por errores en los datos
        if ($duracion > 0) {
            $totalSegundos += $duracion;
        }
    }
    // Promedio
    $promedioSegundos = $totalSegundos / count($reservas);

    // Convertir a formato horas:minutos
    $hProm = floor($promedioSegundos / 3600);
    $mProm = floor(($promedioSegundos % 3600) / 60);

    $tiempoPromedio = sprintf('%02d:%02d', $hProm, $mProm);

    echo json_encode([
        "success" => $tiempoPromedio,
        "total" => $totalresevas
    ]);

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
    exit();
}