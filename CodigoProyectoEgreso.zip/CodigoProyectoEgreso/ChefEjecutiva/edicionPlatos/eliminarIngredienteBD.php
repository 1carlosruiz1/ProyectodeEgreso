<?php
require_once('../../sesion/conexion.php');
header('Content-Type: application/json');

if (!isset($_GET['idIngrediente'])|| !isset($_GET["idPlato"])) {
    echo json_encode(['error' => 'ID no proporcionado']);
    exit;
}

$idIngrediente = $_GET['idIngrediente'];
$idPlato = $_GET["idPlato"];

try {
    $stmt = $con->prepare("DELETE FROM Necesita WHERE (ID_plato, ID_ingrediente) = (?, ?)");
    $stmt->execute([$idPlato, $idIngrediente]);

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
