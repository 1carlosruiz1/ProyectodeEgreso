<?php
include '../conexion.php';

$response = [];

$nombre = $_POST['Nombre'] ?? '';
$precio = $_POST['Precio'] ?? '';
$temporada = $_POST['Temporada'] ?? '';
$tiempoPreparacion = $_POST['tiempoPreparacion'] ?? '';
$descripcionPlato = $_POST['DescripcionPlato'] ?? '';
$promocion = $_POST['promocion'] ?? '';
$receta = $_POST['receta'] ?? '';

$ingredientes = $_POST['ingredientes'] ?? [];
$cantidades = $_POST['cantidades'] ?? [];
if ($nombre !== '' && $precio !== '' && $temporada !== '' && $tiempoPreparacion !== '' && $descripcionPlato !== '' && $receta !== '' && count($ingredientes) > 0) {
    try {
        $sql = "INSERT INTO Plato (nombrePlato, descripcion, precio, temporada, tiempoPreparacion, promocion, receta) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->execute([$nombre, $descripcionPlato, $precio, $temporada, $tiempoPreparacion, $promocion, $receta]);
        $idPlato = $con->lastInsertId();

        $sqlNecesita = "INSERT INTO Necesita (ID_plato, ID_ingrediente, cantidad) VALUES (?, ?, ?)";
        $stmtNecesita = $con->prepare($sqlNecesita);

        foreach ($ingredientes as $index => $idIngrediente) {
            $cantidad = $cantidades[$index] ?? 1;
            $stmtNecesita->execute([$idPlato, $idIngrediente, $cantidad]);
        }
        if (isset($_FILES['imagen'])) {
            $archivo = $_FILES['imagen'];
            $tmpName = $archivo['tmp_name'];
            $destino = '../../IMG/fotosPlatos/' . $idPlato . '.png'; // siempre .png

            //todoa lo de imagen
            $info = getimagesize($tmpName);
            if ($info === false) {
                $response['fotoError'] = "El archivo no es una imagen válida.";
            } else {
                $tipo = $info[2]; // tipo de imagen
                switch ($tipo) {
                    case IMAGETYPE_JPEG:
                        $img = imagecreatefromjpeg($tmpName);
                        break;
                    case IMAGETYPE_PNG:
                        $img = imagecreatefrompng($tmpName);
                        break;
                    case IMAGETYPE_GIF:
                        $img = imagecreatefromgif($tmpName);
                        break;
                    default:
                        $img = false;
                        $response['fotoError'] = "Formato de imagen no soportado.";
                }

                if ($img !== false) {
                    // Guardar como PNG
                    if (imagepng($img, $destino)) {
                        $response['fotoSuccess'] = $destino;
                    } else {
                        $response['fotoError'] = "Error al guardar la imagen como PNG.";
                    }
                    imagedestroy($img); // liberar memoria
                }
            }
        }


        $response['success'] = true;
        $response['idPlato'] = $idPlato;

    } catch (PDOException $e) {
        $response['error'] = $e->getMessage();
    }
} else {
    $response['vacio'] = "Todos los campos deben estar llenos o diferentes de 0";
}

echo json_encode($response);
