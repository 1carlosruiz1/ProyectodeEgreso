<?php
include '../../sesion/conexion.php';

$response = [];

$nombre = $_POST['Nombre'] ?? '';
$precio = $_POST['Precio'] ?? '';
$temporada = $_POST['Temporada'] ?? '';
$tiempoPreparacion = $_POST['tiempoPreparacion'] ?? '';
$descripcionPlato = $_POST['DescripcionPlato'] ?? '';
$promocion = $_POST['promocion'] ?? '';
$receta = $_POST['receta'] ?? '';

$ingredientes = $_POST['ingredientes'] ?? [];
$cantidades = $_POST['cantidades'] ?? [];

if ($nombre && $precio && $temporada && $tiempoPreparacion && $descripcionPlato && $receta && count($ingredientes) > 0) {
    try {
        $sql = "INSERT INTO Plato (nombrePlato, descripcion, precio, temporada, tiempoPreparacion, promocion, receta) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->execute([$nombre, $descripcionPlato, $precio, $temporada, $tiempoPreparacion, $promocion, $receta]);
        $idPlato = $con->lastInsertId();

        $sqlNecesita = "INSERT INTO Necesita (ID_plato, ID_ingrediente, cantidad) VALUES (?, ?, ?)";
        $stmtNecesita = $con->prepare($sqlNecesita);

        foreach ($ingredientes as $index => $idIngrediente) {
            $cantidad = $cantidades[$index] ?? 1;
            $stmtNecesita->execute([$idPlato, $idIngrediente, $cantidad]);
        }

        $response['success'] = true;
        $response['idPlato'] = $idPlato;

    } catch (PDOException $e) {
        $response['error'] = $e->getMessage();
    }
} else {
    $response['vacio'] = "Todos los campos deben estar llenos o diferentes de 0";
}

echo json_encode($response);
