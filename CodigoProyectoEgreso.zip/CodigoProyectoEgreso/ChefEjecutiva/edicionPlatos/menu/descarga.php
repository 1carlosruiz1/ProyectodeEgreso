<?php
require('../../../FPDF/fpdf.php');
require('../../sesion/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Menu del Restaurante',0,1,'C');
$pdf->Ln(5);

$stmt = $con->query("SELECT * FROM Plato order by nombrePlato");
$platos = $stmt->fetchAll(PDO::FETCH_ASSOC);

if(!$platos || count($platos) === 0){
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,10,'No hay platos registrados.',0,1,'C');
} else {
    foreach($platos as $fila){
        $pdf->SetFont('Arial','B',13);
        $pdf->MultiCell(0,8,utf8_decode($fila['nombrePlato']),0,'L');
        
        $pdf->SetFont('Arial','',11);
        $pdf->MultiCell(0,7,
            "Temporada: " . utf8_decode($fila['temporada']) . "\n" .
            "Tiempo de preparacion: " . $fila['tiempoPreparacion'] . " min\n" .
            "Precio: $" . $fila['precio'],
            0, 'L'
        );
        
        $pdf->SetFont('Arial','I',10);
        $pdf->MultiCell(0,7,"Descripcion: " . utf8_decode($fila['descripcion']),0,'L');
        
        $pdf->Ln(5);
        $pdf->SetDrawColor(200,200,200);
        $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY()); // línea divisoria
        $pdf->Ln(5);
    }
}

$pdf->Output('D', 'menu.pdf');
