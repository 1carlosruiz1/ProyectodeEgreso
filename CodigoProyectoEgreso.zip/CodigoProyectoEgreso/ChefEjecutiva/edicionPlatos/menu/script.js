const iconoLogin = document.querySelector('.IconoLogin');
document.addEventListener("DOMContentLoaded", function (data) {
  data.preventDefault();
  fetch('../../../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {

        if (data.usuario.tipo === "ChefEjecutiva") {
          dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
          const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
          cerrarSesion.addEventListener("click", function (event) {
            event.preventDefault()
            fetch('../../cerrarSesion.php')
              .then(res => res.json())
              .then(data => {
                if (data.success) {
                  window.location.href = "../../../Cliente/index/index.html"
                } else {
                  Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                }
              })
          })
        } else {
          window.location.href = "../../../Cliente/index/index.html"
        }
      } else {
        window.location.href = "../../../Cliente/index/index.html"
      }
    })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}

cargarMenu()
var card = document.getElementById("menu-container");
function cargarMenu() {
  fetch('datos.php')
    .then(res => res.json())
    .then(data => {

      if (data.vacio) {
        card.innerHTML = `<h1>No hay platos disponibles en este momento</h1>`;
      } else if (data.success) {
        card.innerHTML = '';
        data.platos.forEach(element => {
          const precioFinal = element.precio - (element.precio * element.promocion / 100);

          // Verificamos si hay promoción
          const promoTexto = precioFinal < element.precio
            ? `<p class='promo-texto'>🔥 PROMOCIÓN - ${element.promocion}% OFF</p>`
            : "";

          // el : de arriba es como un "si no" tipo else, se llama operador ternario
          card.innerHTML += `
    <div class="menu-card">
      <h2 class='menu-card-title'>${element.nombrePlato}</h2>
      <img src="../../../IMG/fotosPlatos/${element.ID_plato}.png" alt='fotoPlato'>
      <div class="menu-card-content">
        ${promoTexto}
        <p class='menu-card-price'>Precio: $${precioFinal.toFixed(2)}</p>
        <p class='tiempo-preparacion'>Preparación: ${element.tiempoPreparacion} minutos</p>
        <a href="menuGrande.html?id=${element.ID_plato}">
          <button class="menu-card-btn">Ver más</button>
          </a>
          <button class="menu-card-btn" onclick="editar(${element.ID_plato})">Editar</button>
          <button class="menu-card-btn" onclick="eliminar(${element.ID_plato})">Eliminar</button>
      </div>
    </div>
  `;
        });

      } else {
        card.innerHTML = `<h1>Error: ${data.error}</h1>`;
      }
    });
}


function agregarAlCarrito(idPlato) {
  if (nombreUsuario) {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

    let item = carrito.find(producto => producto.idPlato === idPlato);

    if (item) {
      item.cantidad++;
    } else {
      carrito.push({ idPlato: idPlato, cantidad: 1 });
    }

    localStorage.setItem("carrito", JSON.stringify(carrito));

    Swal.fire({
      icon: "success",
      title: "Comida agregada",
      text: "Comida agregada al carrito",
      confirmButtonText: 'Entendido'
    });
  } else {
    Swal.fire({
      icon: "warning",
      title: "Atencion",
      text: "Debe de estar logueado para hacer compras",
      confirmButtonText: 'Entendido'
    });
  }

}

function eliminar(idPlato) {
  Swal.fire({
    title: "¿Eliminar este plato?",
    text: "Esta acción no se puede deshacer.",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      fetch(`eliminarPlato.php?id=${idPlato}`)
        .then(response => response.json())

        .then(data => {
          console.log(data);

          if (data.success) {
            Swal.fire({
              title: "Eliminado",
              text: "El plato fue eliminado correctamente.",
              icon: "success",
              confirmButtonText: "Entendido"
            });
            cargarMenu();
          } else {
            Swal.fire({
              title: "Error",
              text: "hubo un error: " + data.error,
              icon: "error"
            });
          }
        })
    }
  });
}

function editar(ID) {
  window.location.href = `../edicionPlatos.html?id=${ID}`;
}


document.getElementById("btnDescarga").addEventListener("click", () => {
  window.open("descarga.php", "_blank");
});

function favoritos(id) {
  fetch('agregarFavoritos.php?id=' + id) //el ?id es el q depsues se pone en GET[id]
    .then(res => res.json())
    .then(data => {

      if (data.session) {
        Swal.fire({
          icon: 'warning',
          title: 'Antención',
          text: 'Debe estar logueado para tener favoritos',
          confirmButtonText: 'Entendido'
        });

      } else if (data.success) {
        Swal.fire({
          icon: 'success',
          title: 'Exito',
          text: 'Plato agregado a favoritos',
          confirmButtonText: 'Entendido'
        });

      } else {
        Swal.fire({
          icon: 'warning',
          title: 'Atención',
          text: data.error,
          confirmButtonText: 'Entendido'
        });

      }
    })
}

const busqueda = document.getElementById('busqueda');
var divBusqueda = document.getElementById("divBusqueda");

busqueda.addEventListener('keypress', (event) => {
  const palabra = busqueda.value;
  fetch("busquedaMenu.php?b=" + palabra)
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        card.innerHTML = '  ';
        data.success.forEach(element => {
          const precioFinal = element.precio - (element.precio * element.promocion / 100);

          // Verificamos si hay promoción
          const promoTexto = precioFinal < element.precio
            ? `<p class='promo-texto'>🔥 PROMOCIÓN - ${element.promocion}% OFF</p>`
            : "";

          // el : de arriba es como un "si no" tipo else, se llama operador ternario
          card.innerHTML += `
    <div class="menu-card">
      <h2 class='menu-card-title'>${element.nombrePlato}</h2>
      <img src="../../IMG/fotosPlatos/${element.ID_plato}.png" alt='fotoPlato'>
      <div class="menu-card-content">
        ${promoTexto}
        <p class='menu-card-price'>Precio: $${precioFinal.toFixed(2)}</p>
        <p class='tiempo-preparacion'>Preparación: ${element.tiempoPreparacion} minutos</p>
        <a href="menuGrande.html?id=${element.ID_plato}">
          <button class="menu-card-btn">Ver más</button>
        </a>
        <button class="menu-card-btn" onclick="agregarAlCarrito(${element.ID_plato})">Agregar al carrito</button>
        <button onclick="favoritos(${element.ID_plato})" class="menu-card-btn">Agregar a fav</button>
      </div>
    </div>
  `;
        });
      }
    })
});

function cargarTitulo(){
  fetch("../../../cargarDatos.php")
  .then(res => res.json())
  .then(data => {
    console.log(data);
    
    if (data.success) {
      const tituloDiv = document.querySelector(".TituloP h1");
      if (tituloDiv) {
        tituloDiv.textContent = data.success.nombre;
      }
    }
  })
}
cargarTitulo()