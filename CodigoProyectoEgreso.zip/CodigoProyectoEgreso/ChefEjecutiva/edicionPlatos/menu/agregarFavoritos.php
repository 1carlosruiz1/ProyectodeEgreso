<?php
require "../../sesion/conexion.php";
session_start();
$ID_plato = $_GET["id"];
if (!isset($_SESSION['usuario'])) {
    echo json_encode(["session" => true]);
    exit;
}
try {
    $stmt = $con->prepare("INSERT INTO Favorito (ID_cliente, ID_plato) VALUES (?, ?)");
    $stmt->execute([$_SESSION['usuario']['ID'], $ID_plato]);
    echo json_encode(["success" => true]);
} catch (PDOException $e) {
    $errorCode = $e->getCode();

    // Obtener más información del error (array con [SQLSTATE, código del driver, mensaje])
    $errorInfo = $e->errorInfo;

    if ($errorCode == 23000) {
        // 23000 es el código SQLSTATE para violación de integridad, que incluye clave duplicada
        echo json_encode(["error" => "Ya tiene ese plato en favorito"]);
        exit;
    }
    echo json_encode(["error" => $e->getMessage()]);
}
