<?php
include '../../sesion/conexion.php';

$id_plato = $_POST['id'];

try {
    $sql = "SELECT * FROM Plato WHERE ID_plato = ?";
    $stmt = $con->prepare($sql);
    $stmt->execute([$id_plato]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$res) {
        echo json_encode(["vacio" => "no hay datos del plato",
    "numero"=> $id_plato]);
    } else {
        $sql = "SELECT i.nombreIngrediente 
        FROM Ingrediente i
        INNER JOIN Necesita n ON i.ID_ingrediente = n.ID_ingrediente
        WHERE n.ID_plato = ?";
        $stmt = $con->prepare($sql);
        $stmt->execute([$id_plato]);
        $ingredientes = $stmt->fetchAll(PDO::FETCH_COLUMN); // solo la columna de nombre

        echo json_encode([
            "success" => true,
            "plato" => $res,
            "ingredientes" => $ingredientes
        ]);
    }
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
