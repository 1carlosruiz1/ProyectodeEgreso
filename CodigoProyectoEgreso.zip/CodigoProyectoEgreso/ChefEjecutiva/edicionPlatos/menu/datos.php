<?php
require '../../sesion/conexion.php';
try {
       $sql = "SELECT * FROM Plato";
       $stmt = $con->prepare($sql);
       $stmt->execute();
       $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
       if (!$res) {
              echo json_encode(["vacio" => "no hay platos"]);
       }
              echo json_encode([
                     "success" => true,
                     "platos" => $res,
              ]);
       }
 catch (PDOException $e) {
       echo json_encode(["error" => $e->getmessage()]);
}