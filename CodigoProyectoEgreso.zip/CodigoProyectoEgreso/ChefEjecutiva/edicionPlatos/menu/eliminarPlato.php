
<?php
require "../../sesion/conexion.php";

$ID = $_GET["id"];

try{
$stmt=$con->prepare("DELETE FROM Plato WHERE ID_plato = ?");
$stmt->execute([$ID]);
echo json_encode(["success"=>"Platos eliminado del sistema"]);
}catch(PDOException $e){
    echo json_encode(["error"=> $e->getMessage()]);
}