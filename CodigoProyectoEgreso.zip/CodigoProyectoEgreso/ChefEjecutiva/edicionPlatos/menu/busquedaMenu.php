<?php
require "../../sesion/conexion.php";
session_start();
$palabra = $_GET["b"];

try {
    $sql = "SELECT * FROM Plato WHERE nombrePlato LIKE ?";
    $stmt = $con->prepare($sql);
    $stmt->execute(['%' . $palabra . '%']);
    $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(["success" => $resultado]);

} catch (PDOException $e) {
    echo json_encode(["error" => $e]);
}
