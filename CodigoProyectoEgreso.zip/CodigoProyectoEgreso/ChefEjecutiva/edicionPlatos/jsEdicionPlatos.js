const lista = document.getElementById("listaIngredientesExistentes");
const seleccionados = document.getElementById("ingredientesSeleccionados");
const formMenu = document.getElementById("formMenu");
const archivoInput = document.getElementById('imagen');

formMenu.addEventListener("submit", function (event) {
  event.preventDefault();

  const tiempoPreparacion = parseInt(document.getElementById("tiempoPreparacion").value);
  const precio = parseFloat(document.getElementById("Precio").value);
  const promocion = parseFloat(document.getElementById("promocion").value);

  if (isNaN(precio) || precio <= 0) {
    Swal.fire("No nos podemos permitir tantas pérdidas chef");
    return;
  }
  if (isNaN(tiempoPreparacion) || tiempoPreparacion <= 0) {
    Swal.fire("El tiempo debe estar en cantidad de minutos");
    return;
  }
  if (isNaN(promocion) || promocion < 0 || promocion > 100) {
    Swal.fire("La promoción debe ser un número válido (0 - 100)");
    return;
  }

  const formData = new FormData(formMenu);

  fetch('phpEdicionPlatos.php', {
    method: 'POST',
    body: formData
  })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        Swal.fire("Comida agregada al menú");

      } else if (data.vacio) {
        Swal.fire("Error: " + data.vacio)
      } else if (data.extension) {
       Swal.fire({
            icon: "warning",
            title: "Atencion",
            text: data.extension,
            confirmButtonText: "Sí, continuar"
        })
      }
    });
});

archivoInput.addEventListener("change", function (event) { //preguntar torres como dunciona
  const archivo = event.target.files[0];
  if (archivo) {
    const lector = new FileReader();
    lector.onload = function (e) {
      document.getElementById("foto").src = e.target.result;
    };
    lector.readAsDataURL(archivo); // convierte la imagen en base64 para mostrarla
  }
});

verIngredientes();
function verIngredientes() {
  fetch("../edicionIngredientes/obtenerIngredientes.php")
    .then(res => res.json())
    .then(data => {
      lista.innerHTML = "";

      if (data.error) {
        lista.innerHTML = `<li style="color:red;">Error: ${data.error}</li>`;
      } else if (data.length === 0) {
        lista.innerHTML = `<li>No hay ingredientes cargados.</li>`;
      } else {
        data.forEach(ing => {
          const li = document.createElement("li");
          li.innerHTML = `
                        ${ing.nombreIngrediente}  
                        <button type="button" class="btnAgregar" 
                            data-id="${ing.ID_ingrediente}" 
                            data-nombre="${ing.nombreIngrediente}"
                            data-unidad="${ing.unidadMedida}">
                            Agregar
                        </button>
                    `;
          lista.appendChild(li);
        });
      }
    });
}


// Delegación: manejar clicks tanto para agregar como para eliminar
lista.addEventListener("click", function (e) {
  // ---------- AGREGAR ----------
  if (e.target.classList.contains("btnAgregar")) {
    e.preventDefault(); // evita submit si el botón está dentro de un form
    const id = e.target.getAttribute("data-id");
    const nombre = e.target.getAttribute("data-nombre");
    const unidad = e.target.getAttribute("data-unidad");

    // debug
    console.log("Agregar ingrediente:", id, nombre, unidad);

    // evitar duplicados revisando hidden inputs
    if (!document.querySelector(`input[name='ingredientes[]'][value='${id}']`)) {

      // Crear item en la lista de seleccionados
      const li = document.createElement("li");
      li.setAttribute("data-id", id); // identificador directo
      li.innerHTML = `
          <span class="ing-nombre">${nombre}</span>
          <input type="number" 
                 name="cantidades[${id}]" 
                 class="cantidadIngrediente" 
                 value="" 
                 placeholder="Cantidad" 
                 required 
                 min="0.01" step="0.01">
          <span>(${unidad})</span>
          <button type="button" class="btnEliminar">Eliminar</button>
        `;
      seleccionados.appendChild(li);

      // Hidden solo para el ID (se usa para enviar al backend)
      const hidden = document.createElement("input");
      hidden.type = "hidden";
      hidden.name = "ingredientes[]";
      hidden.value = id;
      formMenu.appendChild(hidden);
    }
  }
});

// Delegación para los botones Eliminar que estarán dentro de "seleccionados"
seleccionados.addEventListener("click", function (e) {
  if (e.target.classList.contains("btnEliminar")) {
    e.preventDefault(); // solo por seguridad (el button es type=button)
    const li = e.target.closest("li");
    if (!li) return;
    const id = li.getAttribute("data-id");
    // eliminar el li (vista)
    li.remove();

    // eliminar el hidden correspondiente en el form
    const hidden = document.querySelector(`input[name='ingredientes[]'][value='${id}']`);
    if (hidden) hidden.remove();
  }
});

// --- Opcional: debug para ver los elementos creados dinámicamente ---
// console.log(lista, seleccionados, formMenu, archivoInput);




const iconoLogin = document.querySelector('.IconoLogin');
document.addEventListener("DOMContentLoaded", function (data) {
  fetch('../../sesion/controlExistenciaUsuario.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        if (data.usuario.tipo === "ChefEjecutiva") {
          // Si está logueado 
          dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
          const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
          //para cerrar sesion (el li creado antes 2
          cerrarSesion.addEventListener("click", function (event) {
            event.preventDefault()
            fetch('../sesion/cerrarSesion.php')
              .then(res => res.json())
              .then(data => {
                if (data.success) {
                  window.location.href = "../../Cliente/index/index.html"
                } else {
                  Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                }
              })
          })
        } else {
          window.location.href = "../../Cliente/index/index.html"
        }
      } else {
        window.location.href = "../../Cliente/index/index.html"
      }
    })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
  hideTimeout = setTimeout(() => {
    dropdown.style.display = 'none';
  }, 120);
});

dropdown.addEventListener('mouseenter', () => {
  clearTimeout(hideTimeout);
  dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
  dropdown.style.display = 'none';
});

function crearOpcion(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  li.classList.add('dropdown-opcion');

  li.addEventListener('mouseenter', () => {
    li.classList.add('dropdown-opcion-hover');
  });

  li.addEventListener('mouseleave', () => {
    li.classList.remove('dropdown-opcion-hover');
  });

  return li;
}
//hasta acá lo q va en todas las paginas


//por si vienen de menú/////////////////////////////////

document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const idPlato = params.get("id");
  if (!idPlato) return;

  fetch(`obtenerPlato.php?id=${idPlato}`)
    .then(res => res.json())
    .then(data => {

      if (!data.success) {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: data.error || "No se pudo cargar el plato."
        });
        return;
      }

      const plato = data.plato;
      // ------ Rellenar campos ------
      document.querySelector("input[name='Nombre']").value = plato.nombrePlato;
      document.querySelector("input[name='Precio']").value = plato.precio;
      document.querySelector("select[name='Temporada']").value = plato.temporada;
      document.querySelector("input[name='tiempoPreparacion']").value = plato.tiempoPreparacion;
      document.querySelector("input[name='promocion']").value = plato.promocion;
      document.querySelector("textarea[name='DescripcionPlato']").value = plato.descripcion;
      document.querySelector("textarea[name='receta']").value = plato.receta;

      // ------ Imagen ------
      const foto = document.getElementById("foto");
      foto.src = `../../IMG/fotosPlatos/${plato.ID_plato}.png`;

      // ------ Ingredientes ------
      const seleccionados = document.getElementById("ingredientesSeleccionados");
      const formMenu = document.getElementById("formMenu");

      data.ingredientes.forEach(ingrediente => {
        // crear <li> igual que al agregar manualmente
        const li = document.createElement("li");
        li.setAttribute("data-id", ingrediente.ID_ingrediente);
        li.innerHTML = `
          <span class="ing-nombre">${ingrediente.nombreIngrediente}</span>
          <input type="number" 
                 name="cantidades[${ingrediente.ID_ingrediente}]" 
                 value="${ingrediente.cantidad}" 
                 class="cantidadIngrediente" 
                 placeholder="Cantidad" 
                 required 
                 min="0.01" step="0.01">
          <span>(${ingrediente.unidadMedida})</span>
          <button type="button" class="btnEliminar" onclick="eliminardeBD(${plato.ID_plato}, ${ingrediente.ID_ingrediente})">Eliminar</button>
        `;
        seleccionados.appendChild(li);

        // crear input hidden
        const hidden = document.createElement("input");
        hidden.type = "hidden";
        hidden.name = "ingredientes[]";
        hidden.value = ingrediente.ID_ingrediente;
        formMenu.appendChild(hidden);
      });
    })
    .catch(err => console.error("Error en fetch:", err));
});

function eliminardeBD(idPlato, idIngrediente) {
  console.log(idPlato);

  fetch(`eliminarIngredienteBD.php?idPlato=${idPlato}&idIngrediente=${idIngrediente}`)
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {

        const li = document.querySelector(`#ingredientesSeleccionados li[data-id='${idIngrediente}']`);
        if (li) li.remove();

        // Eliminar el input hidden
        const hidden = document.querySelector(`input[name='ingredientes[]'][value='${idIngrediente}']`);
        if (hidden) hidden.remove();

        Swal.fire({
          icon: "success",
          title: "Ingrediente eliminado",
          text: "Se eliminó correctamente de la base de datos."
        });
      } else {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: data.error || "No se pudo eliminar el ingrediente."
        });
      }
    })
    .catch(err => {
      console.error("Error al eliminar ingrediente:", err);
      Swal.fire({
        icon: "error",
        title: "Error de conexión",
        text: "No se pudo comunicar con el servidor."
      });
    });
}

function cargarTitulo() {
  fetch("../../cargarDatos.php")
    .then(res => res.json())
    .then(data => {
      console.log(data);

      if (data.success) {
        const tituloDiv = document.querySelector(".TituloP h1");
        if (tituloDiv) {
          tituloDiv.textContent = data.success.nombre;
        }
      }
    })
}
cargarTitulo()