const lista = document.getElementById("listaIngredientesExistentes");
const seleccionados = document.getElementById("ingredientesSeleccionados");
const formMenu = document.getElementById("formMenu");
const archivoInput = document.getElementById('imagen');

formMenu.addEventListener("submit", function (event) {
    event.preventDefault();

    const tiempoPreparacion = parseInt(document.getElementById("tiempoPreparacion").value);
    const precio = parseFloat(document.getElementById("Precio").value);
    const promocion = parseFloat(document.getElementById("promocion").value);

    if (isNaN(precio) || precio <= 0) {
        Swal.fire("No nos podemos permitir tantas pérdidas chef");
        return;
    }
    if (isNaN(tiempoPreparacion) || tiempoPreparacion <= 0) {
        Swal.fire("El tiempo debe estar en cantidad de minutos");
        return;
    }
    if (isNaN(promocion) || promocion < 0 || promocion > 100) {
        Swal.fire("La promoción debe ser un número válido (0 - 100)");
        return;
    }

    const formData = new FormData(formMenu);

    fetch('phpEdicionPlatos.php', {
        method: 'POST',
        body: formData
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                    Swal.fire("Comida agregada al menú");
                
            } else if (data.vacio) {
                Swal.fire("Error: " + data.vacio)
            } else {
                Swal.fire("Error: " + data.error)
            }
        });
});

archivoInput.addEventListener("change", function (event) { //preguntar torres como dunciona
    const archivo = event.target.files[0];
    if (archivo) {
        const lector = new FileReader();
        lector.onload = function (e) {
            document.getElementById("foto").src = e.target.result;
        };
        lector.readAsDataURL(archivo); // convierte la imagen en base64 para mostrarla
    }
});

verIngredientes();
function verIngredientes() {
    fetch("../edicionIngredientes/obtenerIngredientes.php")
        .then(res => res.json())
        .then(data => {
            lista.innerHTML = "";

            if (data.error) {
                lista.innerHTML = `<li style="color:red;">Error: ${data.error}</li>`;
            } else if (data.length === 0) {
                lista.innerHTML = `<li>No hay ingredientes cargados.</li>`;
            } else {
                data.forEach(ing => {
                    const li = document.createElement("li");
                    li.innerHTML = `
                        ${ing.nombreIngrediente}  
                        <button type="button" class="btnAgregar" 
                            data-id="${ing.ID_ingrediente}" 
                            data-nombre="${ing.nombreIngrediente}"
                            data-unidad="${ing.unidadMedida}">
                            Agregar
                        </button>
                    `;
                    lista.appendChild(li);
                });
            }
        });
}

lista.addEventListener("click", function (e) {
    if (e.target.classList.contains("btnAgregar")) {
        const id = e.target.getAttribute("data-id");
        const nombre = e.target.getAttribute("data-nombre");
        const unidad = e.target.getAttribute("data-unidad");

        // evitar duplicados revisando hidden inputs
        if (!document.querySelector(`input[name='ingredientes[]'][value='${id}']`)) {

            // Crear item en la lista de seleccionados
            const li = document.createElement("li");
            li.innerHTML = `
            <br>
                ${nombre}
                <input type="number" 
                       name="cantidades[${id}]" 
                       class="cantidadIngrediente" 
                       placeholder="Cantidad" 
                       required 
                       min="0.01" step="0.01">
                <span>(${unidad})</span>
            `;
            seleccionados.appendChild(li);

            // Hidden solo para el ID
            const hidden = document.createElement("input");
            hidden.type = "hidden";
            hidden.name = "ingredientes[]";
            hidden.value = id;
            formMenu.appendChild(hidden);
        }
    }
});

const iconoLogin = document.querySelector('.IconoLogin');
document.addEventListener("DOMContentLoaded", function (data) {
    fetch('../../sesion/controlExistenciaUsuario.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (data.usuario.tipo === "ChefEjecutiva") {
                    // Si está logueado 
                    dropdown.appendChild(crearOpcion(`Hola, ${data.usuario.nombre}`));
                    const cerrarSesion = dropdown.appendChild(crearOpcion("Cerrar sesión"));
                    //para cerrar sesion (el li creado antes 2
                    cerrarSesion.addEventListener("click", function (event) {
                        event.preventDefault()
                        fetch('../sesion/cerrarSesion.php')
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    window.location.href = "../../Cliente/index/index.html"
                                } else {
                                    Swal.fire("No se pudo cerrar la sesion, estamos trabajando en ello, lo lamentamos");
                                }
                            })
                    })
                } else {
                    window.location.href = "../../Cliente/index/index.html"
                }
            } else {
                window.location.href = "../../Cliente/index/index.html"
            }
        })
})

const dropdown = document.createElement('ul');
dropdown.classList.add('dropdown-menu');
iconoLogin.appendChild(dropdown);

let hideTimeout = null;

iconoLogin.addEventListener('mouseenter', () => {
    clearTimeout(hideTimeout);
    dropdown.style.display = 'block';
});

iconoLogin.addEventListener('mouseleave', () => {
    hideTimeout = setTimeout(() => {
        dropdown.style.display = 'none';
    }, 120);
});

dropdown.addEventListener('mouseenter', () => {
    clearTimeout(hideTimeout);
    dropdown.style.display = 'block';
});

dropdown.addEventListener('mouseleave', () => {
    dropdown.style.display = 'none';
});

function crearOpcion(texto) {
    const li = document.createElement('li');
    li.textContent = texto;
    li.classList.add('dropdown-opcion');

    li.addEventListener('mouseenter', () => {
        li.classList.add('dropdown-opcion-hover');
    });

    li.addEventListener('mouseleave', () => {
        li.classList.remove('dropdown-opcion-hover');
    });

    return li;
}
//hasta acá lo q va en todas las paginas
