<?php
header('Content-Type: application/json');
require_once('../../sesion/conexion.php');

if (!isset($_GET['id'])) {
    echo json_encode(['success' => false, 'error' => 'ID no proporcionado']);
    exit;
}

try {
    $ID = $_GET["id"];

    // Obtener los datos del plato
    $stmt = $con->prepare("SELECT * FROM Plato WHERE ID_plato = ?");
    $stmt->execute([$ID]);
    $plato = $stmt->fetch(PDO::FETCH_ASSOC); // fetch(), no fetchAll()

    $sql = "SELECT 
                N.cantidad, 
                I.ID_ingrediente, 
                I.nombreIngrediente, 
                I.unidadMedida
            FROM 
                Necesita N
            INNER JOIN Ingrediente I ON N.ID_ingrediente = I.ID_ingrediente
            WHERE 
                N.ID_plato = ?";
    $stmt = $con->prepare($sql);
    $stmt->execute([$ID]);
    $ingredientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'plato' => $plato,
        'ingredientes' => $ingredientes
    ]);

} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
