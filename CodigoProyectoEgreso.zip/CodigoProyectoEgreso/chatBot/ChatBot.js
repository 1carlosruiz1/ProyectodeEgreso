function toggleChatbot() {
    const body = document.getElementById('chatbot-body');
    const toggle = document.getElementById('chatbot-toggle');
    if (body.style.display === 'none') {
        body.style.display = 'block';
        toggle.textContent = '▲';
    } else {
        body.style.display = 'none';
        toggle.textContent = '▼';
    }
}

document.getElementById('chatbot-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const question = document.getElementById('chatbot-question').value;
    document.getElementById('chatbot-response').textContent = "Pensando...";
    try {
        const res = await fetch('http://localhost:3001/ask', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ question })
        });
        const data = await res.json();
        document.getElementById('chatbot-response').innerHTML = data.answer;
        const responseDiv = document.getElementById('chatbot-response');
        responseDiv.scrollTop = responseDiv.scrollHeight;
    } catch (err) {
        document.getElementById('chatbot-response').textContent = "Estamos solucionando un problema de conexión, disculpas.";
    }
});