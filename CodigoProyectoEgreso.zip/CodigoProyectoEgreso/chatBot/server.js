const express = require('express');
const cors = require('cors');
const axios = require('axios');
const fs = require('fs');
const pdfParse = require('pdf-parse');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.post('/ask', async (req, res) => {
    try {
        const { question } = req.body;
        const pdfBuffer = fs.readFileSync('documento.pdf');
        const pdfData = await pdfParse(pdfBuffer);
        const pdfText = pdfData.text;

        const prompt = `
Eres un asistente virtual de ayuda para clientes. Responde de forma clara y amable usando solo la información del siguiente documento. 
Si no encuentras la respuesta, di: "Lo siento, no tengo información sobre eso en este momento."

Documento:
${pdfText}

Pregunta del cliente: ${question}
`;

        const ollamaResponse = await axios.post('http://localhost:11434/api/generate', {
            model: 'llama3',
            prompt: prompt,
            stream: false
        });

        res.json({ answer: ollamaResponse.data.response });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

app.listen(3001, () => {
    console.log('Servidor chatbot escuchando en http://localhost:3001');
});

